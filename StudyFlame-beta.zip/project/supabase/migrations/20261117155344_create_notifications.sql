/*
# Notifications

1. New Tables
- `notifications`: one row per event addressed to a student.
  - `id`, `user_id` (recipient, defaults to caller), `type` ('comment' | 'reply' | 'like' |
    'message' | 'interaction'), `actor_name` (who did it, denormalized label),
    `body` (short text), `link_view` (which screen to open), `is_read`, `created_at`.

2. Functions
- `notify(p_target_user, p_type, p_actor_name, p_body, p_link_view)`: inserts a notification,
  respecting the recipient's preferences (notify_comments, notify_likes, notify_messages).
  Skips silently when the recipient disabled that category or when the actor IS the recipient.

3. Security
- RLS enabled; students read and update (mark read) only their own notifications, and can
  delete their own. `type`, `actor_name`, `body`, `link_view` are not client-writable on
  update: only `is_read` can be changed by the owner.

4. Notes
- Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('comment', 'reply', 'like', 'message', 'interaction')),
  actor_name text NOT NULL DEFAULT '' CHECK (char_length(actor_name) <= 40),
  body text NOT NULL DEFAULT '' CHECK (char_length(body) <= 300),
  link_view text NOT NULL DEFAULT 'communaute' CHECK (char_length(link_view) <= 40),
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications (user_id, created_at DESC);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

GRANT SELECT, UPDATE (is_read), DELETE ON notifications TO authenticated;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (user_id = auth.uid());

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE
  TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION notify(
  p_target_user uuid,
  p_type text,
  p_actor_name text,
  p_body text,
  p_link_view text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_allowed boolean;
BEGIN
  IF p_target_user IS NULL OR p_target_user = auth.uid() THEN
    RETURN;
  END IF;

  SELECT CASE p_type
    WHEN 'like' THEN notify_likes
    WHEN 'message' THEN notify_messages
    ELSE notify_comments
  END INTO v_allowed
  FROM profiles WHERE id = p_target_user;

  IF coalesce(v_allowed, false) THEN
    INSERT INTO notifications (user_id, type, actor_name, body, link_view)
    VALUES (p_target_user, p_type, left(coalesce(p_actor_name, ''), 40), left(coalesce(p_body, ''), 300), left(p_link_view, 40));
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION notify(uuid, text, text, text, text) FROM PUBLIC, anon, authenticated;
