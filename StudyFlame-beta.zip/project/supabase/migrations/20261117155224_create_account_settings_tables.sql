/*
# Account settings: avatar, preferences, blocks, sign-in history

1. Modified Tables
- `profiles`: new columns
  - `avatar_path` (text, path in the private `avatars` bucket, null = no photo)
  - `theme_mode` (text: 'light', 'dark' or 'auto', default 'auto')
  - `notify_comments`, `notify_likes`, `notify_messages` (booleans, default true)
  - `is_private_profile` (boolean, default false)
  Students can update ONLY these columns; `role`, `premium_until`, `flames`, `xp` stay protected.
  `avatar_path` is filled through a server-side function so a student cannot point their
  avatar at another student's file.

2. New Tables
- `account_blocks`: a student blocks another student. Unique pair, no self-block.
- `signin_history`: one row per sign-in (time, device description). Students can read their
  own rows only; rows are written by the database on each session.

3. Functions
- `set_avatar_path(p_path)`: verifies the path is inside the caller's own avatar folder
  before writing it.

4. Security
- RLS enabled on the two new tables.
- Blocks: each student manages their own list; blocked pairs are invisible to others.
- Sign-in history: read-only for students, written by a definer trigger on auth.
- Storage: `avatars` bucket is PRIVATE; students upload only inside their own folder.

5. Notes
- No data is changed or removed. Safe to re-run.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'avatar_path') THEN
    ALTER TABLE profiles ADD COLUMN avatar_path text CHECK (char_length(avatar_path) <= 200);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'theme_mode') THEN
    ALTER TABLE profiles ADD COLUMN theme_mode text NOT NULL DEFAULT 'auto' CHECK (theme_mode IN ('light', 'dark', 'auto'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'notify_comments') THEN
    ALTER TABLE profiles ADD COLUMN notify_comments boolean NOT NULL DEFAULT true;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'notify_likes') THEN
    ALTER TABLE profiles ADD COLUMN notify_likes boolean NOT NULL DEFAULT true;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'notify_messages') THEN
    ALTER TABLE profiles ADD COLUMN notify_messages boolean NOT NULL DEFAULT true;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'is_private_profile') THEN
    ALTER TABLE profiles ADD COLUMN is_private_profile boolean NOT NULL DEFAULT false;
  END IF;
END;
$$;

REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (display_name, level, objective, theme_mode, notify_comments, notify_likes, notify_messages, is_private_profile) ON profiles TO authenticated;

CREATE TABLE IF NOT EXISTS account_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);

ALTER TABLE account_blocks ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON account_blocks TO authenticated;

DROP POLICY IF EXISTS "select_own_blocks" ON account_blocks;
CREATE POLICY "select_own_blocks" ON account_blocks FOR SELECT
  TO authenticated USING (blocker_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_blocks" ON account_blocks;
CREATE POLICY "insert_own_blocks" ON account_blocks FOR INSERT
  TO authenticated WITH CHECK (blocker_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_blocks" ON account_blocks;
CREATE POLICY "delete_own_blocks" ON account_blocks FOR DELETE
  TO authenticated USING (blocker_id = auth.uid());

CREATE TABLE IF NOT EXISTS signin_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  signed_in_at timestamptz NOT NULL DEFAULT now(),
  device text NOT NULL DEFAULT 'inconnu' CHECK (char_length(device) <= 200)
);

CREATE INDEX IF NOT EXISTS signin_history_user_idx ON signin_history (user_id, signed_in_at DESC);

ALTER TABLE signin_history ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON signin_history TO authenticated;

DROP POLICY IF EXISTS "select_own_signin_history" ON signin_history;
CREATE POLICY "select_own_signin_history" ON signin_history FOR SELECT
  TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION set_avatar_path(p_path text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF p_path IS NOT NULL AND (storage.foldername(p_path))[1] <> auth.uid()::text THEN
    RAISE EXCEPTION 'not_authorized' USING ERRCODE = 'insufficient_privilege';
  END IF;

  UPDATE profiles SET avatar_path = p_path WHERE id = auth.uid();
END;
$$;

REVOKE EXECUTE ON FUNCTION set_avatar_path(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_avatar_path(text) TO authenticated;

DROP POLICY IF EXISTS "avatars_insert_own_folder" ON storage.objects;
CREATE POLICY "avatars_insert_own_folder" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
    AND (lower(name) LIKE '%.jpg' OR lower(name) LIKE '%.jpeg' OR lower(name) LIKE '%.png' OR lower(name) LIKE '%.webp')
  );

DROP POLICY IF EXISTS "avatars_delete_own" ON storage.objects;
CREATE POLICY "avatars_delete_own" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'avatars'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
