/*
# Create profiles table

1. New Tables
- `profiles`: one row per StudyFlame student account.
  - `id` (uuid, primary key, same as the auth account id)
  - `display_name` (text, first name or pseudonym, 1 to 40 characters)
  - `level` (text, school level: P1 to P6 for primary, S1 to S6 for secondary)
  - `objective` (text, learning goal chosen at sign up)
  - `consent_at` (timestamptz, when the student accepted the terms and parental consent notice)
  - `flames` (integer, daily streak counter, starts at 0)
  - `xp` (integer, experience points, starts at 0)
  - `created_at` (timestamptz)

2. Security
- Row level security enabled on `profiles`.
- Only signed-in users can access the table, and only their own row.
- Policies: select, insert, update and delete are each restricted to `auth.uid() = id`.
- Grants: authenticated users may select, insert and update. Deletion is not granted.
- Writes to `flames` and `xp` are kept to the owner for now; progress logic will be reviewed when it is built.

3. Notes
- No rows are deleted or altered by this migration.
- The table is created only if it does not already exist, so the migration can be re-run safely.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 1 AND 40),
  level text NOT NULL CHECK (level IN ('P1','P2','P3','P4','P5','P6','S1','S2','S3','S4','S5','S6')),
  objective text NOT NULL CHECK (char_length(objective) BETWEEN 1 AND 200),
  consent_at timestamptz NOT NULL DEFAULT now(),
  flames integer NOT NULL DEFAULT 0 CHECK (flames >= 0),
  xp integer NOT NULL DEFAULT 0 CHECK (xp >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON profiles TO authenticated;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
