/*
# Account deletion and sign-in history recording

1. New Functions
- `delete_own_account()`: lets a signed-in student delete their own account for good.
  Everything linked to the student is removed by the existing cascade rules
  (profile, posts, replies, notes, messages, history...). The auth account itself is
  removed by the same function through the admin API only if available; otherwise the
  database rows are deleted and the auth account is soft-disabled by signing the user out.
  To keep this self-contained without extra secrets, the function deletes all owned rows
  and marks the profile gone; the auth user row is deleted via the service role by the
  caller (Supabase client signs out). Cascade rules handle the rest.
- `record_sign_in()`: trigger on auth.users events is not available in SQL alone; instead
  the function is called by the app right after a successful sign-in and stores a row
  with a short device description taken from the browser, validated server-side.

2. Security
- `delete_own_account` runs as definer so it can delete across tables the student cannot
  touch directly, but it only ever deletes the CALLER's own data (auth.uid()).
- `record_sign_in` accepts a device string up to 200 characters and stores it with the
  caller's id only.

3. Notes
- Safe to re-run.
*/

CREATE OR REPLACE FUNCTION delete_own_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  DELETE FROM help_replies WHERE user_id = v_user;
  DELETE FROM help_posts WHERE user_id = v_user;
  DELETE FROM community_comments WHERE user_id = v_user;
  DELETE FROM community_posts WHERE user_id = v_user;

  DELETE FROM auth.users WHERE id = v_user;
END;
$$;

REVOKE EXECUTE ON FUNCTION delete_own_account() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION delete_own_account() TO authenticated;

CREATE OR REPLACE FUNCTION record_sign_in(p_device text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_device text := left(coalesce(p_device, 'inconnu'), 200);
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM signin_history
    WHERE user_id = auth.uid()
      AND signed_in_at > now() - interval '1 hour'
  ) THEN
    INSERT INTO signin_history (user_id, device) VALUES (auth.uid(), v_device);
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION record_sign_in(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION record_sign_in(text) TO authenticated;
