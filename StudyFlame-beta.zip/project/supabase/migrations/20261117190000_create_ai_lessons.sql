/*
# Personalised AI lessons, server-side grading, XP and flames

1. New Tables
- `lessons`: one row per lesson generated for a student.
  - `content` (jsonb): title, intro, sections, key points and quiz questions WITHOUT answers.
  - `solutions` (jsonb): correct answer index and explanation for every question.
    Students cannot read this column; it is only used by `submit_lesson`.
  - `status` ('new' or 'done'), `score`, `total`, `xp_awarded`, `completed_at`.

2. Modified Tables
- `profiles`: new `last_activity_on` date used to compute the daily flame streak.

3. New Functions
- `submit_lesson(p_lesson_id, p_answers)`: grades the answers on the server, awards XP once,
  updates the flame streak (Europe/Brussels day) and returns the score with the solutions.

4. Security
- RLS on `lessons`: students see and delete only their own rows.
- Students have NO insert/update grant: lessons are created by the `generate-lesson` Edge
  Function (service role) and completed through `submit_lesson` (definer function).
- Column-level SELECT grant hides `solutions` until the lesson is done.

5. Notes
- Safe to re-run.
*/

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_activity_on date;

CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  subject_id text NOT NULL CHECK (char_length(subject_id) BETWEEN 1 AND 40),
  level text NOT NULL CHECK (level IN ('P1','P2','P3','P4','P5','P6','S1','S2','S3','S4','S5','S6')),
  topic text NOT NULL CHECK (char_length(topic) BETWEEN 1 AND 160),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
  content jsonb NOT NULL,
  solutions jsonb NOT NULL,
  total integer NOT NULL CHECK (total BETWEEN 1 AND 12),
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'done')),
  score integer CHECK (score >= 0),
  xp_awarded integer NOT NULL DEFAULT 0 CHECK (xp_awarded >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

CREATE INDEX IF NOT EXISTS lessons_user_created_idx ON lessons (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS lessons_user_subject_idx ON lessons (user_id, subject_id);

ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON lessons FROM authenticated, anon;
GRANT SELECT (id, user_id, subject_id, level, topic, title, content, total, status, score, xp_awarded, created_at, completed_at)
  ON lessons TO authenticated;
GRANT DELETE ON lessons TO authenticated;

DROP POLICY IF EXISTS "select_own_lessons" ON lessons;
CREATE POLICY "select_own_lessons" ON lessons FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_lessons" ON lessons;
CREATE POLICY "delete_own_lessons" ON lessons FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION submit_lesson(p_lesson_id uuid, p_answers integer[])
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_lesson lessons%ROWTYPE;
  v_score integer := 0;
  v_xp integer;
  v_today date := (now() AT TIME ZONE 'Europe/Brussels')::date;
  v_last date;
  v_flames integer;
  v_results jsonb := '[]'::jsonb;
  v_i integer;
  v_correct integer;
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  SELECT * INTO v_lesson FROM lessons WHERE id = p_lesson_id AND user_id = v_user FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'lesson_not_found' USING ERRCODE = 'no_data_found';
  END IF;
  IF v_lesson.status = 'done' THEN
    RAISE EXCEPTION 'lesson_already_done' USING ERRCODE = 'unique_violation';
  END IF;
  IF p_answers IS NULL OR coalesce(array_length(p_answers, 1), 0) <> v_lesson.total THEN
    RAISE EXCEPTION 'invalid_answers' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  FOR v_i IN 0 .. v_lesson.total - 1 LOOP
    v_correct := (v_lesson.solutions -> v_i ->> 'answer_index')::integer;
    v_results := v_results || jsonb_build_object(
      'answer_index', v_correct,
      'explanation', v_lesson.solutions -> v_i ->> 'explanation',
      'correct', p_answers[v_i + 1] = v_correct
    );
    IF p_answers[v_i + 1] = v_correct THEN
      v_score := v_score + 1;
    END IF;
  END LOOP;

  -- 20 XP for finishing the lesson + 10 XP per correct answer.
  v_xp := 20 + v_score * 10;

  UPDATE lessons
  SET status = 'done', score = v_score, xp_awarded = v_xp, completed_at = now()
  WHERE id = v_lesson.id;

  SELECT last_activity_on, flames INTO v_last, v_flames FROM profiles WHERE id = v_user FOR UPDATE;
  IF v_last = v_today THEN
    NULL; -- already counted today
  ELSIF v_last = v_today - 1 THEN
    v_flames := v_flames + 1;
  ELSE
    v_flames := 1;
  END IF;

  UPDATE profiles
  SET xp = xp + v_xp, flames = v_flames, last_activity_on = v_today
  WHERE id = v_user;

  RETURN jsonb_build_object('score', v_score, 'total', v_lesson.total, 'xp', v_xp, 'flames', v_flames, 'results', v_results);
END;
$$;

REVOKE ALL ON FUNCTION submit_lesson(uuid, integer[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION submit_lesson(uuid, integer[]) TO authenticated;
