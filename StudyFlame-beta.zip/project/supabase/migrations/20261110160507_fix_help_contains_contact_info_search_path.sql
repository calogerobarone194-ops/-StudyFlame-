/*
# Pin search path on the contact detection helper

1. Modified Functions
- `help_contains_contact_info(text)`: now runs with a fixed search path.

2. Security
- Prevents the function from resolving names through a caller-controlled search path.

3. Notes
- No data is changed. Safe to re-run.
*/

CREATE OR REPLACE FUNCTION help_contains_contact_info(p_text text)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT
    p_text ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}'
    OR p_text ~* 'https?://|www\.'
    OR p_text ~* '(^|[^0-9])(\+33|0033|0)[1-9]([ .-]?[0-9]{2}){4}'
    OR p_text ~* '\m(snapchat|snap|instagram|insta|whatsapp|discord|telegram|tiktok|messenger)\M';
$$;
