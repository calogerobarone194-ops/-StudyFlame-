/*
# Create notifications automatically and show conversation partner names

1. Problem
- `notify()` existed but nothing called it, so the Notifications tab stayed empty.
- Profiles are readable only by their owner, so the Messages tab could not show who a conversation is with.

2. New Functions
- Trigger functions (SECURITY DEFINER, so they may call `notify()`):
  - new community comment -> notifies the post author ('comment') and the parent comment author ('reply').
  - new community like -> notifies the post author ('like').
  - new direct message -> notifies the recipient ('message').
  - new help-forum reply -> notifies the question author ('reply').
  `notify()` already ignores self-notifications and respects each student's notification settings.
- `get_conversation_names(p_ids)`: returns the pseudonym (display_name) ONLY of students who exchanged a
  direct message with the caller. Nothing else about them is exposed.

3. Notes
- Safe to re-run.
*/

CREATE OR REPLACE FUNCTION trg_notify_community_comment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner uuid;
  v_parent_author uuid;
BEGIN
  SELECT user_id INTO v_owner FROM community_posts WHERE id = NEW.post_id;
  PERFORM notify(v_owner, 'comment', NEW.author_name, left(NEW.body, 120), 'communaute');
  IF NEW.parent_comment_id IS NOT NULL THEN
    SELECT user_id INTO v_parent_author FROM community_comments WHERE id = NEW.parent_comment_id;
    IF v_parent_author IS DISTINCT FROM v_owner THEN
      PERFORM notify(v_parent_author, 'reply', NEW.author_name, left(NEW.body, 120), 'communaute');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION trg_notify_community_like()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner uuid;
  v_name text;
BEGIN
  SELECT user_id INTO v_owner FROM community_posts WHERE id = NEW.post_id;
  SELECT display_name INTO v_name FROM profiles WHERE id = NEW.user_id;
  PERFORM notify(v_owner, 'like', v_name, '', 'communaute');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION trg_notify_direct_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text;
BEGIN
  SELECT display_name INTO v_name FROM profiles WHERE id = NEW.sender_id;
  PERFORM notify(NEW.recipient_id, 'message', v_name, '', 'messages');
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION trg_notify_help_reply()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner uuid;
BEGIN
  SELECT user_id INTO v_owner FROM help_posts WHERE id = NEW.post_id;
  PERFORM notify(v_owner, 'reply', NEW.author_name, left(NEW.body, 120), 'cours');
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION trg_notify_community_comment() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION trg_notify_community_like() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION trg_notify_direct_message() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION trg_notify_help_reply() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS notify_after_community_comment ON community_comments;
CREATE TRIGGER notify_after_community_comment AFTER INSERT ON community_comments
  FOR EACH ROW EXECUTE FUNCTION trg_notify_community_comment();

DROP TRIGGER IF EXISTS notify_after_community_like ON community_likes;
CREATE TRIGGER notify_after_community_like AFTER INSERT ON community_likes
  FOR EACH ROW EXECUTE FUNCTION trg_notify_community_like();

DROP TRIGGER IF EXISTS notify_after_direct_message ON direct_messages;
CREATE TRIGGER notify_after_direct_message AFTER INSERT ON direct_messages
  FOR EACH ROW EXECUTE FUNCTION trg_notify_direct_message();

DROP TRIGGER IF EXISTS notify_after_help_reply ON help_replies;
CREATE TRIGGER notify_after_help_reply AFTER INSERT ON help_replies
  FOR EACH ROW EXECUTE FUNCTION trg_notify_help_reply();

CREATE OR REPLACE FUNCTION get_conversation_names(p_ids uuid[])
RETURNS TABLE (id uuid, display_name text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.display_name
  FROM profiles p
  WHERE auth.uid() IS NOT NULL
    AND p.id = ANY (p_ids)
    AND EXISTS (
      SELECT 1 FROM direct_messages m
      WHERE (m.sender_id = auth.uid() AND m.recipient_id = p.id)
         OR (m.recipient_id = auth.uid() AND m.sender_id = p.id)
    );
$$;

REVOKE ALL ON FUNCTION get_conversation_names(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_conversation_names(uuid[]) TO authenticated;
