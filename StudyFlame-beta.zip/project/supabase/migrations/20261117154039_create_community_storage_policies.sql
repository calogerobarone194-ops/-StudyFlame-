/*
# Storage policies for community photos

1. Security
- Bucket `community-photos` is PRIVATE: nothing is readable without a signed URL.
- Students upload only inside their own folder (`<user id>/...`), only images.
- Reading an object requires the caller to know its path; the app then creates a short-lived
  signed URL. Listing is not allowed, so paths stay unguessable in practice (random names).
- Size limits (5 MB) are enforced in the app's upload call.

2. Notes
- Applies to the storage API, not the SQL data API. Safe to re-run.
*/

DROP POLICY IF EXISTS "community_photos_insert_own_folder" ON storage.objects;
CREATE POLICY "community_photos_insert_own_folder" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'community-photos'
    AND (storage.foldername(name))[1] = auth.uid()::text
    AND (lower(name) LIKE '%.jpg' OR lower(name) LIKE '%.jpeg' OR lower(name) LIKE '%.png' OR lower(name) LIKE '%.webp')
  );

DROP POLICY IF EXISTS "community_photos_delete_own" ON storage.objects;
CREATE POLICY "community_photos_delete_own" ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'community-photos'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
