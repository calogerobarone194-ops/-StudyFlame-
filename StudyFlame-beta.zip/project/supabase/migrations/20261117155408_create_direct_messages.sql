/*
# Private messaging and admin visibility of hidden content

1. New Tables
- `direct_messages`: a private message between two students.
  - `id`, `sender_id` (defaults to caller), `recipient_id`, `body` (1..2000 chars),
    `is_hidden` (moderation), `created_at`.
  A conversation is read by fetching messages between the two accounts (either direction).

2. Functions
- `messages_prepare_content()`: refuses contact details (emails, phones, links, social apps)
  in private messages, same rule as the community, and fills nothing else.
- `report_direct_message(p_message_id)`: reports an abusive private message; hides it
  immediately for review once reported by the recipient.

3. Security
- RLS: students can read only conversations they are part of, only visible messages.
- Students send messages only as themselves, only to an existing account, and not to
  someone who blocked them (checked server-side).
- Messages are never editable; deletion is not granted (keeps evidence for moderation).

4. Notes
- Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS direct_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS direct_messages_pair_idx ON direct_messages (sender_id, recipient_id, created_at);
CREATE INDEX IF NOT EXISTS direct_messages_recipient_idx ON direct_messages (recipient_id, created_at DESC);

ALTER TABLE direct_messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON direct_messages TO authenticated;
GRANT INSERT (recipient_id, body) ON direct_messages TO authenticated;

DROP POLICY IF EXISTS "select_own_conversations" ON direct_messages;
CREATE POLICY "select_own_conversations" ON direct_messages FOR SELECT
  TO authenticated USING (sender_id = auth.uid() OR recipient_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_messages" ON direct_messages;
CREATE POLICY "insert_own_messages" ON direct_messages FOR INSERT
  TO authenticated WITH CHECK (
    sender_id = auth.uid()
    AND recipient_id <> auth.uid()
    AND EXISTS (SELECT 1 FROM profiles WHERE id = recipient_id)
    AND NOT EXISTS (SELECT 1 FROM account_blocks WHERE blocker_id = recipient_id AND blocked_id = auth.uid())
  );

CREATE OR REPLACE FUNCTION messages_prepare_content()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF help_contains_contact_info(NEW.body) THEN
    RAISE EXCEPTION 'contact_info_blocked' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION messages_prepare_content() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS direct_messages_prepare ON direct_messages;
CREATE TRIGGER direct_messages_prepare BEFORE INSERT ON direct_messages
  FOR EACH ROW EXECUTE FUNCTION messages_prepare_content();

CREATE OR REPLACE FUNCTION report_direct_message(p_message_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  UPDATE direct_messages
  SET is_hidden = true
  WHERE id = p_message_id
    AND (sender_id = auth.uid() OR recipient_id = auth.uid());
END;
$$;

REVOKE EXECUTE ON FUNCTION report_direct_message(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION report_direct_message(uuid) TO authenticated;
