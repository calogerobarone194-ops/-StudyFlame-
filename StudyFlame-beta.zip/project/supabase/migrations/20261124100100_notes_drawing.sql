/*
# Drawings in notes

1. Modified Tables
- `notes.drawing` (text, nullable): a PNG data URL of the student's drawing, at most about 600 KB.
- `notes.has_drawing` (generated boolean): lets the notes list show a drawing icon without
  downloading the images.

2. Security
- Column grants extended so a student can write `drawing` on their own notes. RLS is unchanged.

3. Notes
- Safe to re-run.
*/

ALTER TABLE notes ADD COLUMN IF NOT EXISTS drawing text
  CHECK (drawing IS NULL OR (char_length(drawing) <= 600000 AND drawing LIKE 'data:image/png;base64,%'));

ALTER TABLE notes ADD COLUMN IF NOT EXISTS has_drawing boolean
  GENERATED ALWAYS AS (drawing IS NOT NULL) STORED;

GRANT INSERT (drawing) ON notes TO authenticated;
GRANT UPDATE (drawing) ON notes TO authenticated;
