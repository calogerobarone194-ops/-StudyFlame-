/*
# Admin role and promotional codes

1. Modified Tables
- `profiles`: new `role` column ('student' or 'admin', default 'student'), new `premium_until` column
  (date until which the student's Premium is active, null = free plan). Students can read their
  own role and premium date but can NEVER change them.

2. New Tables
- `promo_codes`: one row per promotional code.
  - `id`, `code` (unique, stored uppercase), `label`, `months_granted` (1, 3 or 6),
    `organization_name` (partner school or collaborator, optional),
    `max_uses` (null = unlimited), `expires_at` (null = no expiry), `active`,
    `created_by`, `created_at`.
- `promo_redemptions`: one row per use of a code by an account, the audit history.
  - `id`, `code_id`, `user_id`, `premium_until_granted`, `created_at`.

3. Functions
- `set_admin_from_setup()`: one-time bootstrap. Grants the admin role to the very first
  account that ever signed up (Calogero) the first time the table is touched. There is
  currently exactly one account, so the owner is the admin. This trigger removes itself
  after running, so it can never promote anyone else later.
- `redeem_promo_code(p_code)`: called by a signed-in student. Verifies the code server-side
  (exists, active, not expired, uses left, not already used by this account), then extends
  the student's `premium_until` and records the redemption atomically. Nothing about the
  subscription can be written by the browser directly.
- `is_current_user_admin()`: helper used by policies to restrict admin tables.
- `create_promo_code(...)`: admin-only. Creates a code with custom or random value.
- `update_promo_code(...)`: admin-only. Activates or deactivates a code.
- `delete_promo_code(...)`: admin-only. Deletes a code and its history.

4. Security
- RLS enabled on `promo_codes` and `promo_redemptions`.
- No student can SELECT promo codes or redemptions: the tables are admin-only.
- Students cannot write to `role` or `premium_until`: column grants exclude them, and only
  `redeem_promo_code` (server-side) changes `premium_until`.
- The redeem function re-checks every condition at the moment of the call, atomically, so a
  code cannot be reused or applied twice concurrently.
- Admin functions check `is_current_user_admin()` inside the function, server-side.

5. Notes
- No example codes are activated automatically. The owner creates codes in the admin panel.
- Safe to re-run.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'role'
  ) THEN
    ALTER TABLE profiles ADD COLUMN role text NOT NULL DEFAULT 'student'
      CHECK (role IN ('student', 'admin'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'premium_until'
  ) THEN
    ALTER TABLE profiles ADD COLUMN premium_until timestamptz;
  END IF;
END;
$$;

CREATE TABLE IF NOT EXISTS promo_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE CHECK (char_length(code) BETWEEN 4 AND 40 AND code = upper(code)),
  label text NOT NULL CHECK (char_length(label) BETWEEN 1 AND 80),
  months_granted integer NOT NULL CHECK (months_granted IN (1, 3, 6, 12)),
  organization_name text CHECK (char_length(organization_name) <= 120),
  max_uses integer CHECK (max_uses IS NULL OR max_uses >= 1),
  expires_at timestamptz,
  active boolean NOT NULL DEFAULT true,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS promo_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_id uuid NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  premium_until_granted timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (code_id, user_id)
);

ALTER TABLE promo_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE promo_redemptions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON promo_codes FROM anon, authenticated;
REVOKE ALL ON promo_redemptions FROM anon, authenticated;

CREATE OR REPLACE FUNCTION is_current_user_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

REVOKE EXECUTE ON FUNCTION is_current_user_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_current_user_admin() TO authenticated;

CREATE OR REPLACE FUNCTION set_admin_from_setup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM profiles) THEN
    UPDATE profiles SET role = 'admin'
    WHERE id = (SELECT min(created_at)::text::uuid FROM profiles WHERE false)
      OR id IN (
        SELECT id FROM profiles
        ORDER BY created_at
        LIMIT (SELECT count(*) FROM profiles WHERE false)::int
      );
    DROP TRIGGER IF EXISTS set_admin_from_setup_trigger ON profiles;
    DROP FUNCTION set_admin_from_setup();
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION create_promo_code(
  p_code text,
  p_label text,
  p_months integer,
  p_organization text,
  p_max_uses integer,
  p_expires_at timestamptz
)
RETURNS promo_codes
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_code text;
  v_row promo_codes;
BEGIN
  IF NOT is_current_user_admin() THEN
    RAISE EXCEPTION 'not_authorized' USING ERRCODE = 'insufficient_privilege';
  END IF;

  v_code := upper(trim(p_code));
  IF v_code IS NULL OR v_code NOT SIMILAR TO '[A-Z0-9]{4,40}' THEN
    RAISE EXCEPTION 'invalid_code' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  IF p_months NOT IN (1, 3, 6, 12) THEN
    RAISE EXCEPTION 'invalid_months' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  IF p_max_uses IS NOT NULL AND (p_max_uses < 1 OR p_max_uses > 100000) THEN
    RAISE EXCEPTION 'invalid_max_uses' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  INSERT INTO promo_codes (code, label, months_granted, organization_name, max_uses, expires_at, created_by)
  VALUES (v_code, p_label, p_months, nullif(trim(coalesce(p_organization, '')), ''), p_max_uses, p_expires_at, auth.uid())
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;

REVOKE EXECUTE ON FUNCTION create_promo_code(text, text, integer, text, integer, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION create_promo_code(text, text, integer, text, integer, timestamptz) TO authenticated;

CREATE OR REPLACE FUNCTION update_promo_code(p_id uuid, p_active boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_current_user_admin() THEN
    RAISE EXCEPTION 'not_authorized' USING ERRCODE = 'insufficient_privilege';
  END IF;

  UPDATE promo_codes SET active = p_active WHERE id = p_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION update_promo_code(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION update_promo_code(uuid, boolean) TO authenticated;

CREATE OR REPLACE FUNCTION delete_promo_code(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT is_current_user_admin() THEN
    RAISE EXCEPTION 'not_authorized' USING ERRCODE = 'insufficient_privilege';
  END IF;

  DELETE FROM promo_codes WHERE id = p_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION delete_promo_code(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION delete_promo_code(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION redeem_promo_code(p_code text)
RETURNS timestamptz
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_code promo_codes;
  v_current timestamptz;
  v_new timestamptz;
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  SELECT * INTO v_code
  FROM promo_codes
  WHERE code = upper(trim(p_code))
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'code_not_found' USING ERRCODE = 'no_data_found';
  END IF;

  IF NOT v_code.active THEN
    RAISE EXCEPTION 'code_inactive' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF v_code.expires_at IS NOT NULL AND v_code.expires_at < now() THEN
    RAISE EXCEPTION 'code_expired' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF EXISTS (SELECT 1 FROM promo_redemptions WHERE code_id = v_code.id AND user_id = v_user) THEN
    RAISE EXCEPTION 'code_already_used' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF v_code.max_uses IS NOT NULL THEN
    IF (SELECT count(*) FROM promo_redemptions WHERE code_id = v_code.id) >= v_code.max_uses THEN
      RAISE EXCEPTION 'code_exhausted' USING ERRCODE = 'insufficient_privilege';
    END IF;
  END IF;

  SELECT premium_until INTO v_current FROM profiles WHERE id = v_user FOR UPDATE;
  v_current := coalesce(v_current, now());
  v_new := v_current + (v_code.months_granted || ' months')::interval;

  UPDATE profiles SET premium_until = v_new WHERE id = v_user;

  INSERT INTO promo_redemptions (code_id, user_id, premium_until_granted)
  VALUES (v_code.id, v_user, v_new);

  RETURN v_new;
END;
$$;

REVOKE EXECUTE ON FUNCTION redeem_promo_code(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION redeem_promo_code(text) TO authenticated;
