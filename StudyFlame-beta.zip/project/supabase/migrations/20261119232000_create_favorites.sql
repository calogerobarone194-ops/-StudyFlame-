/*
# Favourite subjects and lessons

1. New Tables
- `favorites`: one row per item a student starred.
  - `item_type` ('subject' or 'lesson'), `item_id` (subject id such as 'maths', or a lesson uuid as text).
  - Primary key (user_id, item_type, item_id): a student cannot star the same item twice.

2. Security
- RLS: a student reads, adds and removes only their own favourites. No update is needed.
- Column grants: only `item_type` and `item_id` can be provided on insert; `user_id` defaults to the caller.

3. Notes
- Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS favorites (
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  item_type text NOT NULL CHECK (item_type IN ('subject', 'lesson')),
  item_id text NOT NULL CHECK (char_length(item_id) BETWEEN 1 AND 64),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, item_type, item_id)
);

ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON favorites FROM authenticated, anon;
GRANT SELECT, DELETE ON favorites TO authenticated;
GRANT INSERT (item_type, item_id) ON favorites TO authenticated;

DROP POLICY IF EXISTS "select_own_favorites" ON favorites;
CREATE POLICY "select_own_favorites" ON favorites FOR SELECT TO authenticated USING (user_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_favorites" ON favorites;
CREATE POLICY "insert_own_favorites" ON favorites FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_favorites" ON favorites;
CREATE POLICY "delete_own_favorites" ON favorites FOR DELETE TO authenticated USING (user_id = auth.uid());
