/*
# Allow admin to read promo codes and usage history

1. Security
- `promo_codes` and `promo_redemptions` were completely locked (no grants, no policies),
  which blocked the admin panel from listing codes.
- Now signed-in users may SELECT both tables, but row level security only returns rows to
  the administrator. Students still cannot read any code or usage row.
- No INSERT, UPDATE or DELETE is granted: all writes stay in the server-side functions.

2. Notes
- No data is changed. Safe to re-run.
*/

GRANT SELECT ON promo_codes TO authenticated;
GRANT SELECT ON promo_redemptions TO authenticated;

DROP POLICY IF EXISTS "select_promo_codes_admin" ON promo_codes;
CREATE POLICY "select_promo_codes_admin" ON promo_codes FOR SELECT
  TO authenticated USING (is_current_user_admin());

DROP POLICY IF EXISTS "select_promo_redemptions_admin" ON promo_redemptions;
CREATE POLICY "select_promo_redemptions_admin" ON promo_redemptions FOR SELECT
  TO authenticated USING (is_current_user_admin());
