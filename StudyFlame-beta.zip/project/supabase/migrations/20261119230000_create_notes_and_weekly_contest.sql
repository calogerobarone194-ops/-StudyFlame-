/*
# Personal notes and weekly contest ranking

1. New Tables
- `notes`: private notes of a student (title, body, optional subject).

2. New Functions
- `get_weekly_leaderboard(p_limit)`: XP earned from finished lessons during the current week
  (Monday to Sunday, Europe/Brussels), ranked among students of the SAME school level as the caller.
  Returns only the pseudonym (display_name), the weekly XP and the rank. No ids, no level,
  no other personal data is exposed. The caller's own row is always included.

3. Security
- RLS on `notes`: each student reads, creates, edits and deletes only their own notes.
- The leaderboard function runs as definer so it can aggregate across students, but it returns
  nothing except the fields above.

4. Notes
- Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT '' CHECK (char_length(title) <= 120),
  body text NOT NULL DEFAULT '' CHECK (char_length(body) <= 20000),
  subject_id text CHECK (subject_id IS NULL OR char_length(subject_id) <= 40),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notes_user_updated_idx ON notes (user_id, updated_at DESC);

ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON notes FROM authenticated, anon;
GRANT SELECT, DELETE ON notes TO authenticated;
GRANT INSERT (title, body, subject_id) ON notes TO authenticated;
GRANT UPDATE (title, body, subject_id) ON notes TO authenticated;

DROP POLICY IF EXISTS "select_own_notes" ON notes;
CREATE POLICY "select_own_notes" ON notes FOR SELECT TO authenticated USING (user_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_notes" ON notes;
CREATE POLICY "insert_own_notes" ON notes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "update_own_notes" ON notes;
CREATE POLICY "update_own_notes" ON notes FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "delete_own_notes" ON notes;
CREATE POLICY "delete_own_notes" ON notes FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION notes_touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS notes_touch ON notes;
CREATE TRIGGER notes_touch BEFORE UPDATE ON notes
  FOR EACH ROW EXECUTE FUNCTION notes_touch_updated_at();

CREATE OR REPLACE FUNCTION get_weekly_leaderboard(p_limit integer DEFAULT 10)
RETURNS TABLE (rank bigint, display_name text, weekly_xp bigint, is_me boolean)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH me AS (
    SELECT level FROM profiles WHERE id = auth.uid()
  ),
  week AS (
    SELECT (date_trunc('week', now() AT TIME ZONE 'Europe/Brussels')) AT TIME ZONE 'Europe/Brussels' AS start_at
  ),
  totals AS (
    SELECT p.id, p.display_name, coalesce(sum(l.xp_awarded), 0) AS xp
    FROM profiles p
    JOIN me ON p.level = me.level
    LEFT JOIN lessons l
      ON l.user_id = p.id
     AND l.status = 'done'
     AND l.completed_at >= (SELECT start_at FROM week)
    GROUP BY p.id, p.display_name
  ),
  ranked AS (
    SELECT id, display_name, xp, rank() OVER (ORDER BY xp DESC) AS r
    FROM totals
    WHERE xp > 0
  )
  SELECT r, ranked.display_name, xp, (id = auth.uid())
  FROM ranked
  WHERE auth.uid() IS NOT NULL
    AND (r <= least(greatest(p_limit, 1), 50) OR id = auth.uid())
  ORDER BY r, ranked.display_name;
$$;

REVOKE ALL ON FUNCTION get_weekly_leaderboard(integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION get_weekly_leaderboard(integer) TO authenticated;
