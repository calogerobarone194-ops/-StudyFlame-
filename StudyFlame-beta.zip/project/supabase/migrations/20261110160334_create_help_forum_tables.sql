/*
# Create homework help board (questions, replies, reports)

1. New Tables
- `help_posts`: a homework question posted by a signed-in student.
  - `id`, `user_id` (defaults to the signed-in student), `subject_id`, `author_name` (copied from the student's first name), `title` (3 to 120 characters), `body` (3 to 2000 characters), `is_hidden`, `created_at`.
- `help_replies`: an answer to a question, same fields with `post_id` instead of `subject_id` and `title`.
- `help_reports`: one row per student and per reported item, so a student can report a given item only once.

2. Modified Tables
- None.

3. Functions
- `help_contains_contact_info(text)`: detects email addresses, French phone numbers, web links and common messaging app names.
- `help_prepare_content()`: trigger that refuses any post or reply containing contact details and fills `author_name` from the student's profile.
- `report_help_content(type, id)`: records a report and hides the post or reply once it has 3 reports from different students.

4. Security
- Row level security enabled on all three tables.
- Students can read only visible (not hidden) posts and replies.
- Students can create posts and replies only under their own account, and cannot set `author_name` or `is_hidden`.
- Students can delete only their own posts and replies.
- Reports are never readable or writable directly; they go through `report_help_content` only.
- The report function is callable by signed-in students only.

5. Notes
- Safe to re-run: tables, functions and triggers are created only if missing, and policies are replaced.
- No existing data is changed.
*/

CREATE TABLE IF NOT EXISTS help_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  subject_id text NOT NULL CHECK (char_length(subject_id) BETWEEN 1 AND 40),
  author_name text NOT NULL DEFAULT '' CHECK (char_length(author_name) <= 40),
  title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
  body text NOT NULL CHECK (char_length(body) BETWEEN 3 AND 2000),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS help_posts_subject_created_idx ON help_posts (subject_id, created_at DESC);
CREATE INDEX IF NOT EXISTS help_posts_user_idx ON help_posts (user_id);

CREATE TABLE IF NOT EXISTS help_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES help_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL DEFAULT '' CHECK (char_length(author_name) <= 40),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS help_replies_post_created_idx ON help_replies (post_id, created_at);
CREATE INDEX IF NOT EXISTS help_replies_user_idx ON help_replies (user_id);

CREATE TABLE IF NOT EXISTS help_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post', 'reply')),
  target_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reporter_id, target_type, target_id)
);

ALTER TABLE help_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE help_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE help_reports ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON help_posts TO authenticated;
GRANT INSERT (subject_id, title, body) ON help_posts TO authenticated;
GRANT DELETE ON help_posts TO authenticated;

GRANT SELECT ON help_replies TO authenticated;
GRANT INSERT (post_id, body) ON help_replies TO authenticated;
GRANT DELETE ON help_replies TO authenticated;

DROP POLICY IF EXISTS "select_visible_help_posts" ON help_posts;
CREATE POLICY "select_visible_help_posts" ON help_posts FOR SELECT
  TO authenticated USING (is_hidden = false);

DROP POLICY IF EXISTS "insert_own_help_posts" ON help_posts;
CREATE POLICY "insert_own_help_posts" ON help_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_help_posts" ON help_posts;
CREATE POLICY "delete_own_help_posts" ON help_posts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_visible_help_replies" ON help_replies;
CREATE POLICY "select_visible_help_replies" ON help_replies FOR SELECT
  TO authenticated USING (is_hidden = false);

DROP POLICY IF EXISTS "insert_own_help_replies" ON help_replies;
CREATE POLICY "insert_own_help_replies" ON help_replies FOR INSERT
  TO authenticated WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM help_posts p WHERE p.id = post_id AND p.is_hidden = false)
  );

DROP POLICY IF EXISTS "delete_own_help_replies" ON help_replies;
CREATE POLICY "delete_own_help_replies" ON help_replies FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION help_contains_contact_info(p_text text)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT
    p_text ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}'
    OR p_text ~* 'https?://|www\.'
    OR p_text ~* '(^|[^0-9])(\+33|0033|0)[1-9]([ .-]?[0-9]{2}){4}'
    OR p_text ~* '\m(snapchat|snap|instagram|insta|whatsapp|discord|telegram|tiktok|messenger)\M';
$$;

CREATE OR REPLACE FUNCTION help_prepare_content()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF help_contains_contact_info(concat_ws(' ', to_jsonb(NEW) ->> 'title', NEW.body)) THEN
    RAISE EXCEPTION 'contact_info_blocked' USING ERRCODE = 'check_violation';
  END IF;

  NEW.author_name := (SELECT display_name FROM profiles WHERE id = NEW.user_id);
  IF NEW.author_name IS NULL THEN
    RAISE EXCEPTION 'profile_required' USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION help_prepare_content() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS help_posts_prepare ON help_posts;
CREATE TRIGGER help_posts_prepare BEFORE INSERT ON help_posts
  FOR EACH ROW EXECUTE FUNCTION help_prepare_content();

DROP TRIGGER IF EXISTS help_replies_prepare ON help_replies;
CREATE TRIGGER help_replies_prepare BEFORE INSERT ON help_replies
  FOR EACH ROW EXECUTE FUNCTION help_prepare_content();

CREATE OR REPLACE FUNCTION report_help_content(p_type text, p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  report_total integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF p_type = 'post' THEN
    IF NOT EXISTS (SELECT 1 FROM help_posts WHERE id = p_id) THEN
      RAISE EXCEPTION 'not_found' USING ERRCODE = 'no_data_found';
    END IF;
  ELSIF p_type = 'reply' THEN
    IF NOT EXISTS (SELECT 1 FROM help_replies WHERE id = p_id) THEN
      RAISE EXCEPTION 'not_found' USING ERRCODE = 'no_data_found';
    END IF;
  ELSE
    RAISE EXCEPTION 'invalid_target' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  INSERT INTO help_reports (reporter_id, target_type, target_id)
  VALUES (auth.uid(), p_type, p_id)
  ON CONFLICT (reporter_id, target_type, target_id) DO NOTHING;

  SELECT count(*) INTO report_total
  FROM help_reports
  WHERE target_type = p_type AND target_id = p_id;

  IF p_type = 'post' THEN
    UPDATE help_posts SET is_hidden = (report_total >= 3) WHERE id = p_id;
  ELSE
    UPDATE help_replies SET is_hidden = (report_total >= 3) WHERE id = p_id;
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION report_help_content(text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION report_help_content(text, uuid) TO authenticated;
