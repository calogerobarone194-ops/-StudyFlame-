/*
# Beta feedback

1. New Tables
- `feedback`: messages sent by students from Settings during the beta.
  - `message` (1 to 2000 characters), `page` (where the student was), `created_at`.

2. Security
- RLS: a student can only INSERT their own feedback and cannot read it back.
  Read it from the Supabase dashboard (Table editor), which bypasses RLS.

3. Notes
- Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 2000),
  page text NOT NULL DEFAULT '' CHECK (char_length(page) <= 40),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON feedback FROM authenticated, anon;
GRANT INSERT (message, page) ON feedback TO authenticated;

DROP POLICY IF EXISTS "insert_own_feedback" ON feedback;
CREATE POLICY "insert_own_feedback" ON feedback FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
