/*
# Community: posts with photos, comments, likes, reports

1. New Tables
- `community_posts`: a post in the StudyFlame community feed.
  - `id`, `user_id` (defaults to the signed-in student), `author_name` (filled server-side from the profile),
    `body` (1 to 2000 characters), `photo_path` (optional, path in the private storage bucket),
    `is_hidden` (set by moderation), `created_at`.
- `community_comments`: a comment on a post, or a reply to another comment.
  - `id`, `post_id`, `parent_comment_id` (null for a top-level comment), `user_id`, `author_name`,
    `body` (1 to 1000 characters), `is_hidden`, `created_at`.
- `community_likes`: one like per user per post (unique).
- `community_reports`: one report per user per target, shared with the help board reports pattern.

2. Functions
- `community_prepare_content()`: trigger that fills `author_name` from the profile and refuses
  contact details (emails, phone numbers, links, social network names) in post bodies.
- `toggle_post_like(p_post_id)`: atomically adds or removes the signed-in user's like and
  returns whether it is now liked.

3. Security
- RLS enabled on all tables; students read only visible content.
- Students create posts/comments only for themselves and cannot set `author_name` or `is_hidden`.
- Students delete only their own posts/comments/likes.
- Likes and reports are written only through server-side functions, never directly.
- Photo storage is a PRIVATE bucket; read access goes through short-lived signed URLs and
  each student can only upload inside their own folder.

4. Notes
- No data is changed or removed. Safe to re-run.
*/

CREATE TABLE IF NOT EXISTS community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL DEFAULT '' CHECK (char_length(author_name) <= 40),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  photo_path text CHECK (char_length(photo_path) <= 200),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS community_posts_created_idx ON community_posts (created_at DESC);
CREATE INDEX IF NOT EXISTS community_posts_user_idx ON community_posts (user_id);

CREATE TABLE IF NOT EXISTS community_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  parent_comment_id uuid REFERENCES community_comments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL DEFAULT '' CHECK (char_length(author_name) <= 40),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 1000),
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS community_comments_post_idx ON community_comments (post_id, created_at);

CREATE TABLE IF NOT EXISTS community_likes (
  post_id uuid NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS community_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post', 'comment')),
  target_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reporter_id, target_type, target_id)
);

ALTER TABLE community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_reports ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON community_posts TO authenticated;
GRANT INSERT (body, photo_path) ON community_posts TO authenticated;
GRANT DELETE ON community_posts TO authenticated;

GRANT SELECT ON community_comments TO authenticated;
GRANT INSERT (post_id, parent_comment_id, body) ON community_comments TO authenticated;
GRANT DELETE ON community_comments TO authenticated;

GRANT SELECT ON community_likes TO authenticated;

REVOKE ALL ON community_reports FROM anon, authenticated;

DROP POLICY IF EXISTS "select_visible_community_posts" ON community_posts;
CREATE POLICY "select_visible_community_posts" ON community_posts FOR SELECT
  TO authenticated USING (is_hidden = false);

DROP POLICY IF EXISTS "insert_own_community_posts" ON community_posts;
CREATE POLICY "insert_own_community_posts" ON community_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_community_posts" ON community_posts;
CREATE POLICY "delete_own_community_posts" ON community_posts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_visible_community_comments" ON community_comments;
CREATE POLICY "select_visible_community_comments" ON community_comments FOR SELECT
  TO authenticated USING (is_hidden = false);

DROP POLICY IF EXISTS "insert_own_community_comments" ON community_comments;
CREATE POLICY "insert_own_community_comments" ON community_comments FOR INSERT
  TO authenticated WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM community_posts p WHERE p.id = post_id AND p.is_hidden = false)
  );

DROP POLICY IF EXISTS "delete_own_community_comments" ON community_comments;
CREATE POLICY "delete_own_community_comments" ON community_comments FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_community_likes" ON community_likes;
CREATE POLICY "select_community_likes" ON community_likes FOR SELECT
  TO authenticated USING (true);

CREATE OR REPLACE FUNCTION community_prepare_content()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF help_contains_contact_info(NEW.body) THEN
    RAISE EXCEPTION 'contact_info_blocked' USING ERRCODE = 'check_violation';
  END IF;

  NEW.author_name := (SELECT display_name FROM profiles WHERE id = NEW.user_id);
  IF NEW.author_name IS NULL THEN
    RAISE EXCEPTION 'profile_required' USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION community_prepare_content() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS community_posts_prepare ON community_posts;
CREATE TRIGGER community_posts_prepare BEFORE INSERT ON community_posts
  FOR EACH ROW EXECUTE FUNCTION community_prepare_content();

DROP TRIGGER IF EXISTS community_comments_prepare ON community_comments;
CREATE TRIGGER community_comments_prepare BEFORE INSERT ON community_comments
  FOR EACH ROW EXECUTE FUNCTION community_prepare_content();

CREATE OR REPLACE FUNCTION toggle_post_like(p_post_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user uuid := auth.uid();
  v_liked boolean;
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM community_posts WHERE id = p_post_id AND is_hidden = false) THEN
    RAISE EXCEPTION 'not_found' USING ERRCODE = 'no_data_found';
  END IF;

  SELECT EXISTS (SELECT 1 FROM community_likes WHERE post_id = p_post_id AND user_id = v_user)
  INTO v_liked;

  IF v_liked THEN
    DELETE FROM community_likes WHERE post_id = p_post_id AND user_id = v_user;
    RETURN false;
  END IF;

  INSERT INTO community_likes (post_id, user_id) VALUES (p_post_id, v_user);
  RETURN true;
END;
$$;

REVOKE EXECUTE ON FUNCTION toggle_post_like(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION toggle_post_like(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION report_community_content(p_type text, p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  report_total integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;

  IF p_type = 'post' THEN
    IF NOT EXISTS (SELECT 1 FROM community_posts WHERE id = p_id) THEN
      RAISE EXCEPTION 'not_found' USING ERRCODE = 'no_data_found';
    END IF;
  ELSIF p_type = 'comment' THEN
    IF NOT EXISTS (SELECT 1 FROM community_comments WHERE id = p_id) THEN
      RAISE EXCEPTION 'not_found' USING ERRCODE = 'no_data_found';
    END IF;
  ELSE
    RAISE EXCEPTION 'invalid_target' USING ERRCODE = 'invalid_parameter_value';
  END IF;

  INSERT INTO community_reports (reporter_id, target_type, target_id)
  VALUES (auth.uid(), p_type, p_id)
  ON CONFLICT (reporter_id, target_type, target_id) DO NOTHING;

  SELECT count(*) INTO report_total
  FROM community_reports
  WHERE target_type = p_type AND target_id = p_id;

  IF p_type = 'post' THEN
    UPDATE community_posts SET is_hidden = (report_total >= 3) WHERE id = p_id;
  ELSE
    UPDATE community_comments SET is_hidden = (report_total >= 3) WHERE id = p_id;
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION report_community_content(text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION report_community_content(text, uuid) TO authenticated;
