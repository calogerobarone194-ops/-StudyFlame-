/*
# Restrict profile updates to editable columns

1. Modified Tables
- `profiles`: students can no longer change their own `flames` or `xp`.

2. Security
- The table-wide UPDATE grant is removed.
- Students may update only `display_name`, `level` and `objective`.
- Progress values (`flames`, `xp`) will be written by trusted server logic only.

3. Notes
- No data is changed. Existing rows keep their values.
- Safe to re-run.
*/

REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (display_name, level, objective) ON profiles TO authenticated;
