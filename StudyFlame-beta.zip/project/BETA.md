# StudyFlame bêta : mise en ligne

## 1. Base de données (Supabase)

Applique les nouvelles migrations, dans cet ordre (SQL Editor de Supabase, ou `supabase db push`) :

1. `20261117190000_create_ai_lessons.sql` : leçons, correction des quiz, XP et flammes
2. `20261119230000_create_notes_and_weekly_contest.sql` : bloc-notes et classement de la semaine
3. `20261119232000_create_favorites.sql` : favoris
4. `20261124100000_notifications_triggers_and_names.sql` : crée les notifications et affiche les noms dans Messages
5. `20261124100100_notes_drawing.sql` : dessins dans les notes
6. `20261124100200_beta_feedback.sql` : avis des utilisateurs
7. `20261124100300_starter_lessons.sql` : leçons de démarrage (fonctionnent sans IA)

## 2. Leçons générées par l'IA (facultatif pour la bêta)

Sans cette étape, les élèves reçoivent les leçons de démarrage (18 leçons). Pour activer l'IA :

```
supabase functions deploy generate-lesson
supabase secrets set ANTHROPIC_API_KEY=ta_cle_api
```

## 3. Lire les avis des élèves

Supabase > Table Editor > table `feedback`.

## 4. Lancer le site

```
npm install
npm run dev
```
