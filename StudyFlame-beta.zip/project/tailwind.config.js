/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        orange: {
          50: 'rgb(var(--orange-50) / <alpha-value>)',
          100: 'rgb(var(--orange-100) / <alpha-value>)',
          200: 'rgb(var(--orange-200) / <alpha-value>)',
          300: 'rgb(var(--orange-300) / <alpha-value>)',
          400: 'rgb(var(--orange-400) / <alpha-value>)',
          500: 'rgb(var(--orange-500) / <alpha-value>)',
          600: 'rgb(var(--orange-600) / <alpha-value>)',
          700: 'rgb(var(--orange-700) / <alpha-value>)',
          800: 'rgb(var(--orange-800) / <alpha-value>)',
          900: 'rgb(var(--orange-900) / <alpha-value>)',
          950: 'rgb(var(--orange-950) / <alpha-value>)',
        },
        violet: {
          50: 'rgb(var(--violet-50) / <alpha-value>)',
          100: 'rgb(var(--violet-100) / <alpha-value>)',
          200: 'rgb(var(--violet-200) / <alpha-value>)',
          300: 'rgb(var(--violet-300) / <alpha-value>)',
          400: 'rgb(var(--violet-400) / <alpha-value>)',
          500: 'rgb(var(--violet-500) / <alpha-value>)',
          600: 'rgb(var(--violet-600) / <alpha-value>)',
          700: 'rgb(var(--violet-700) / <alpha-value>)',
          800: 'rgb(var(--violet-800) / <alpha-value>)',
          900: 'rgb(var(--violet-900) / <alpha-value>)',
          950: 'rgb(var(--violet-950) / <alpha-value>)',
        },
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        flicker: {
          '0%, 100%': { transform: 'scale(1) rotate(-2deg)' },
          '50%': { transform: 'scale(1.08) rotate(2deg)' },
        },
      },
      animation: {
        fadeUp: 'fadeUp 0.5s ease-out both',
        float: 'float 5s ease-in-out infinite',
        flicker: 'flicker 1.8s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
