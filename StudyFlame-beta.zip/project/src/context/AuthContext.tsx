import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

export interface Profile {
  id: string;
  display_name: string;
  level: string;
  objective: string;
  flames: number;
  xp: number;
  role: string;
  premium_until: string | null;
}

export interface SignUpInput {
  displayName: string;
  email: string;
  password: string;
  level: string;
  objective: string;
}

interface AuthContextValue {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signUp: (input: SignUpInput) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (changes: Pick<Profile, 'display_name' | 'level' | 'objective'>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, display_name, level, objective, flames, xp, role, premium_until')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const loadProfile = (userId: string) => {
      (async () => {
        try {
          const data = await fetchProfile(userId);
          if (active) setProfile(data);
        } catch {
          if (active) setProfile(null);
        } finally {
          if (active) setLoading(false);
        }
      })();
    };

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      if (data.session) {
        loadProfile(data.session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!active) return;
      setSession(nextSession);
      if (nextSession) {
        loadProfile(nextSession.user.id);
      } else {
        setProfile(null);
      }
    });

    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  const signUp = useCallback(async (input: SignUpInput) => {
    const { data, error } = await supabase.auth.signUp({
      email: input.email,
      password: input.password,
    });
    if (error) throw new Error(error.message);
    if (!data.user || !data.session) {
      throw new Error('Le compte a été créé, mais la connexion automatique a échoué. Réessayez de vous connecter.');
    }

    const { error: profileError } = await supabase.from('profiles').insert({
      id: data.user.id,
      display_name: input.displayName,
      level: input.level,
      objective: input.objective,
    });
    if (profileError) throw new Error(profileError.message);

    setProfile(await fetchProfile(data.user.id));
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
  }, []);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw new Error(error.message);
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin,
    });
    if (error) throw new Error(error.message);
  }, []);

  const updateProfile = useCallback(async (changes: Pick<Profile, 'display_name' | 'level' | 'objective'>) => {
    const userId = session?.user.id;
    if (!userId) throw new Error('Vous devez être connecté pour modifier votre profil.');
    const { data, error } = await supabase
      .from('profiles')
      .update(changes)
      .eq('id', userId)
      .select('id, display_name, level, objective, flames, xp, role, premium_until')
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) throw new Error('Profil introuvable.');
    setProfile(data);
  }, [session]);

  const refreshProfile = useCallback(async () => {
    const userId = session?.user.id;
    if (!userId) return;
    setProfile(await fetchProfile(userId));
  }, [session]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user: session?.user ?? null,
      profile,
      loading,
      signUp,
      signIn,
      signOut,
      resetPassword,
      updateProfile,
      refreshProfile,
    }),
    [session, profile, loading, signUp, signIn, signOut, resetPassword, updateProfile, refreshProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth doit être utilisé à l\'intérieur de AuthProvider');
  return context;
}
