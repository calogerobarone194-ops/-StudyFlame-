import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import { addFavorite, listFavorites, removeFavorite, type Favorite, type FavoriteType } from '@/lib/favorites';

interface FavoritesValue {
  favorites: Favorite[];
  isFavorite: (type: FavoriteType, id: string) => boolean;
  toggle: (type: FavoriteType, id: string) => Promise<void>;
  error: string | null;
}

const FavoritesContext = createContext<FavoritesValue | undefined>(undefined);

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setFavorites([]);
      return;
    }
    let active = true;
    listFavorites()
      .then((data) => active && setFavorites(data))
      .catch(() => active && setFavorites([]));
    return () => {
      active = false;
    };
  }, [user]);

  const isFavorite = useCallback(
    (type: FavoriteType, id: string) => favorites.some((item) => item.item_type === type && item.item_id === id),
    [favorites],
  );

  const toggle = useCallback(
    async (type: FavoriteType, id: string) => {
      const was = favorites.some((item) => item.item_type === type && item.item_id === id);
      setError(null);
      // Optimistic update, rolled back if the server refuses.
      setFavorites((prev) =>
        was ? prev.filter((item) => !(item.item_type === type && item.item_id === id)) : [{ item_type: type, item_id: id }, ...prev],
      );
      try {
        if (was) await removeFavorite(type, id);
        else await addFavorite(type, id);
      } catch {
        setError('Impossible de modifier tes favoris pour le moment.');
        setFavorites((prev) =>
          was ? [{ item_type: type, item_id: id }, ...prev] : prev.filter((item) => !(item.item_type === type && item.item_id === id)),
        );
      }
    },
    [favorites],
  );

  const value = useMemo(() => ({ favorites, isFavorite, toggle, error }), [favorites, isFavorite, toggle, error]);
  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites(): FavoritesValue {
  const context = useContext(FavoritesContext);
  if (!context) throw new Error('useFavorites must be used inside FavoritesProvider');
  return context;
}
