import { ArrowRight, Flame, Sparkles, Trophy } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { ThemeToggle } from '@/components/ThemeToggle';
import { FeatureSections } from '@/components/landing/FeatureSections';
import { PricingFaqFooter } from '@/components/landing/PricingFaqFooter';
import type { Theme } from '@/hooks/useTheme';

interface LandingPageProps {
  theme: Theme;
  onToggleTheme: () => void;
  onStart: () => void;
  onLogin: () => void;
}

export function LandingPage({ theme, onToggleTheme, onStart, onLogin }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/80 backdrop-blur-xl dark:border-slate-800/70 dark:bg-slate-950/80">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <a href="#accueil" aria-label="StudyFlame, accueil">
            <Logo />
          </a>
          <nav className="hidden items-center gap-8 text-sm font-medium text-slate-600 dark:text-slate-400 md:flex">
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#matieres">Matières</a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#flammes">Flammes</a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#tarifs">Tarifs</a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#faq">FAQ</a>
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            <button
              type="button"
              onClick={onLogin}
              className="hidden rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white sm:inline-flex"
            >
              Se connecter
            </button>
            <button
              type="button"
              onClick={onStart}
              className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-md transition hover:-translate-y-0.5 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200"
            >
              Commencer
            </button>
          </div>
        </div>
      </header>

      <main>
        <section id="accueil" className="relative overflow-hidden">
          <div className="pointer-events-none absolute -left-32 top-0 h-96 w-96 rounded-full bg-violet-500/20 blur-3xl dark:bg-violet-600/20" />
          <div className="pointer-events-none absolute -right-24 top-24 h-96 w-96 rounded-full bg-orange-500/20 blur-3xl dark:bg-orange-500/15" />

          <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-6 py-16 md:py-24 lg:grid-cols-2">
            <div className="animate-fadeUp">
              <span className="inline-flex items-center gap-2 rounded-full border border-orange-200 bg-orange-50 px-3 py-1.5 text-sm font-medium text-orange-700 dark:border-orange-900 dark:bg-orange-950/60 dark:text-orange-300">
                <Sparkles className="h-4 w-4" /> De la primaire au secondaire, de P1 à S6
              </span>
              <h1 className="mt-6 text-4xl font-extrabold leading-[1.15] tracking-tight sm:text-5xl lg:text-6xl">
                Chaque jour, une étape de plus vers la <span className="bg-gradient-to-r from-violet-600 to-orange-500 bg-clip-text text-transparent">réussite</span>.
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-slate-600 dark:text-slate-400">
                StudyFlame transforme les cours en leçons courtes, exercices et quiz. Gardez votre flamme allumée, gagnez de l'XP et préparez vos examens sereinement.
              </p>
              <div className="mt-10 flex flex-col gap-3 sm:flex-row">
                <button
                  type="button"
                  onClick={onStart}
                  className="group inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-orange-500 px-7 py-4 font-semibold text-white shadow-xl shadow-violet-600/25 transition hover:-translate-y-0.5 hover:shadow-2xl"
                >
                  Commencer gratuitement
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                </button>
                <button
                  type="button"
                  onClick={onLogin}
                  className="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-7 py-4 font-semibold text-slate-800 transition hover:-translate-y-0.5 hover:border-slate-400 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
                >
                  Se connecter
                </button>
              </div>
              <p className="mt-6 inline-flex items-center gap-2 rounded-lg border border-dashed border-orange-300 px-3 py-2 text-sm text-slate-600 dark:border-orange-800 dark:text-slate-400">
                <span className="rounded-md bg-orange-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-orange-700 dark:bg-orange-950 dark:text-orange-300">Bêta</span>
                Version de test : aide-nous à l'améliorer en nous donnant ton avis.
              </p>
              <div className="mt-10 flex items-center gap-6 text-sm text-slate-500 dark:text-slate-400">
                <span className="inline-flex items-center gap-2"><Flame className="h-4 w-4 text-orange-500" /> Flammes quotidiennes</span>
                <span className="inline-flex items-center gap-2"><Trophy className="h-4 w-4 text-violet-500" /> XP et progression</span>
              </div>
            </div>

            <div className="relative animate-fadeUp [animation-delay:150ms]">
              <div className="relative overflow-hidden rounded-3xl border border-slate-200 shadow-2xl shadow-slate-900/10 dark:border-slate-800">
                <img
                  src="https://images.pexels.com/photos/771317/pexels-photo-771317.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Élève concentré en train de réviser à son bureau"
                  className="h-[420px] w-full object-cover"
                />
                <div className="absolute inset-x-4 bottom-4 flex items-center gap-3 rounded-2xl bg-white/95 p-4 shadow-lg backdrop-blur dark:bg-slate-900/95">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-orange-400 to-orange-600">
                    <Flame className="h-6 w-6 text-white" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">7 jours de suite !</p>
                    <p className="text-sm text-slate-600 dark:text-slate-400">Votre flamme grandit à chaque leçon terminée.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <FeatureSections onStart={onStart} />
        <PricingFaqFooter onStart={onStart} />
      </main>
    </div>
  );
}
