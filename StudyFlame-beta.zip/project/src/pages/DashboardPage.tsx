import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { ArrowRight, Crown, Flame, Gift, LogOut, Pencil, Sparkles, Star, Trophy } from 'lucide-react';
import { BetaBanner } from '@/components/BetaBanner';
import { FavoriteButton } from '@/components/FavoriteButton';
import { useFavorites } from '@/context/FavoritesContext';
import { LessonsPage } from '@/components/lessons/LessonsPage';
import { NotesPage } from '@/components/notes/NotesPage';
import { ExercisesPage } from '@/components/exercises/ExercisesPage';
import { LanguagesPage } from '@/components/languages/LanguagesPage';
import { ContestPage } from '@/components/contest/ContestPage';
import { PremiumPage } from '@/components/premium/PremiumPage';
import { MessagesPage } from '@/components/messages/MessagesPage';
import { countDoneBySubject, listLessons, pickSuggestedSubject, type Lesson } from '@/lib/lessons';
import { useAuth } from '@/context/AuthContext';
import { Logo } from '@/components/Logo';
import { ThemeToggle } from '@/components/ThemeToggle';
import { ProfileEditDialog } from '@/components/dashboard/ProfileEditDialog';
import { HelpBoard } from '@/components/help/HelpBoard';
import { CommunityFeed } from '@/components/community/CommunityFeed';
import { SettingsPage } from '@/components/settings/SettingsPage';
import { NotificationsPage } from '@/components/notifications/NotificationsPage';
import { PromoDialog } from '@/components/promo/PromoDialog';
import { AdminPanel } from '@/components/promo/AdminPanel';
import { isAdmin } from '@/lib/promoCodes';
import { HamburgerButton, SideMenu, type SideView } from '@/components/layout/SideMenu';
import { getSubjectName, subjects, type SubjectCategory } from '@/data/subjects';
import type { Theme } from '@/hooks/useTheme';

interface DashboardPageProps {
  theme: Theme;
  onToggleTheme: () => void;
  sideView: SideView;
  onSideViewChange: (view: SideView) => void;
}

const categories: ('Toutes' | SubjectCategory)[] = ['Toutes', 'Lettres', 'Sciences', 'Sciences humaines', 'Langues', 'Technologie'];

export function DashboardPage({ theme, onToggleTheme, sideView, onSideViewChange }: DashboardPageProps) {
  const { profile, signOut } = useAuth();
  const [editing, setEditing] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [category, setCategory] = useState<(typeof categories)[number]>('Toutes');
  const [signOutError, setSignOutError] = useState<string | null>(null);
  const [promoOpen, setPromoOpen] = useState(false);
  const [adminAllowed, setAdminAllowed] = useState(false);

  useEffect(() => {
    let active = true;
    isAdmin().then((admin) => {
      if (active) setAdminAllowed(admin);
    });
    return () => {
      active = false;
    };
  }, []);

  const [lessons, setLessons] = useState<Lesson[]>([]);
  const { favorites } = useFavorites();

  useEffect(() => {
    if (sideView.name !== 'accueil') return;
    let active = true;
    listLessons()
      .then((data) => active && setLessons(data))
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [sideView.name]);

  const doneBySubject = useMemo(() => countDoneBySubject(lessons), [lessons]);
  const suggestedSubject = useMemo(
    () => subjects.find((s) => s.id === pickSuggestedSubject(lessons, subjects.map((x) => x.id))) ?? subjects[0],
    [lessons],
  );
  const lessonsToDo = lessons.filter((lesson) => lesson.status === 'new');

  const isPremium =!!profile?.premium_until && new Date(profile.premium_until) > new Date();

  const visibleSubjects = useMemo(
    () => (category === 'Toutes' ? subjects : subjects.filter((subject) => subject.category === category)),
    [category],
  );

  const handleSignOut = async () => {
    setSignOutError(null);
    try {
      await signOut();
    } catch (err) {
      setSignOutError(err instanceof Error ? err.message : 'Déconnexion impossible. Réessayez.');
    }
  };

  if (!profile) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 p-6 text-center dark:bg-slate-950">
        <p className="max-w-md text-base leading-relaxed text-slate-700 dark:text-slate-300">
          Impossible de charger votre profil pour le moment. Vérifiez votre connexion puis réessayez.
        </p>
        {signOutError && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{signOutError}</p>}
        <button
          type="button"
          onClick={handleSignOut}
          className="rounded-xl bg-slate-900 px-5 py-3 font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900"
        >
          Se déconnecter
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/85 backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/85">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-2 px-4 sm:px-6">
          <div className="flex items-center gap-1">
            <HamburgerButton onOpen={() => setMenuOpen(true)} />
            <Logo />
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              onClick={() => setPromoOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white"
            >
              <Gift className="h-4 w-4" />
              <span className="hidden sm:inline">Code promo</span>
            </button>
            <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            <button
              type="button"
              onClick={handleSignOut}
              className="inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Se déconnecter</span>
            </button>
          </div>
        </div>
      </header>

      {menuOpen && (
        <SideMenu
          view={sideView.name}
          onSelect={(next) => {
            setMenuOpen(false);
            onSideViewChange(next);
          }}
          onClose={() => setMenuOpen(false)}
        />
      )}

      <main className="mx-auto max-w-6xl space-y-10 px-4 py-8 sm:px-6 sm:py-10">
        <BetaBanner onOpenSettings={() => onSideViewChange({ name: 'parametres' })} />

        {sideView.name === 'accueil' && (
          <>
            <section className="flex flex-col gap-6 rounded-3xl bg-gradient-to-br from-slate-900 to-blue-950 p-8 text-white shadow-xl md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-sm font-medium text-slate-300">Bienvenue,</p>
                <h1 className="mt-1 text-3xl font-bold tracking-tight">{profile.display_name}</h1>
                <p className="mt-3 flex flex-wrap items-center gap-2 text-sm text-slate-300">
                  <span>Niveau {profile.level} · {profile.objective}</span>
                  {isPremium && (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-0.5 text-xs font-bold text-slate-950 shadow-md">
                      <Crown className="h-3.5 w-3.5" /> Premium
                    </span>
                  )}
                </p>
              </div>
              <div className="flex gap-4">
                <Stat icon={<Flame className="h-5 w-5 text-orange-400" />} value={profile.flames} label="flammes" />
                <Stat icon={<Trophy className="h-5 w-5 text-violet-300" />} value={profile.xp} label="XP" />
              </div>
              <button
                type="button"
                onClick={() => setEditing(true)}
                className="inline-flex items-center justify-center gap-2 self-start rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-white/20 md:self-auto"
              >
                <Pencil className="h-4 w-4" /> Modifier mon profil
              </button>
            </section>

            {signOutError && (
              <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
                {signOutError}
              </p>
            )}

            <section className="flex flex-col gap-4 rounded-3xl border border-orange-200 bg-orange-50 p-6 dark:border-orange-900/60 dark:bg-orange-950/30 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-orange-700 dark:text-orange-400">
                  <Sparkles className="h-4 w-4" /> Ta leçon du jour
                </p>
                <h2 className="mt-1 text-xl font-bold tracking-tight">
                  {lessonsToDo.length > 0 ? lessonsToDo[0].title : `${suggestedSubject.name} : une nouvelle leçon pour toi`}
                </h2>
                <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                  {lessonsToDo.length > 0
                    ? 'Tu as une leçon en cours. Termine-la pour gagner de l\'XP et garder ta flamme !'
                    : `Créée pour le niveau ${profile.level} selon ton objectif. Fais-en une par jour pour garder ta flamme.`}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  onSideViewChange(
                    lessonsToDo.length > 0
                      ? { name: 'lecons' }
                      : { name: 'lecons', subjectId: suggestedSubject.id, autostart: true },
                  )
                }
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-orange-500/25 transition hover:-translate-y-0.5"
              >
                {lessonsToDo.length > 0 ? 'Reprendre' : 'Commencer'} <ArrowRight className="h-4 w-4" />
              </button>
            </section>

            {favorites.length > 0 && (
              <section>
                <h2 className="flex items-center gap-2 text-xl font-bold tracking-tight">
                  <Star className="h-5 w-5 fill-current text-amber-500" /> Mes favoris
                </h2>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {favorites.map((favorite) => {
                    if (favorite.item_type === 'subject') {
                      const subject = subjects.find((item) => item.id === favorite.item_id);
                      if (!subject) return null;
                      return (
                        <li key={`s-${favorite.item_id}`}>
                          <button
                            type="button"
                            onClick={() => onSideViewChange({ name: 'lecons', subjectId: subject.id })}
                            className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900"
                          >
                            <span className="block text-sm font-semibold">{subject.name}</span>
                            <span className="block text-xs text-slate-500 dark:text-slate-400">Matière</span>
                          </button>
                        </li>
                      );
                    }
                    const lesson = lessons.find((item) => item.id === favorite.item_id);
                    if (!lesson) return null;
                    return (
                      <li key={`l-${favorite.item_id}`}>
                        <button
                          type="button"
                          onClick={() => onSideViewChange({ name: 'lecons', lessonId: lesson.id })}
                          className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900"
                        >
                          <span className="block truncate text-sm font-semibold">{lesson.title}</span>
                          <span className="block text-xs text-slate-500 dark:text-slate-400">Leçon · {getSubjectName(lesson.subject_id)}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </section>
            )}

            <section>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight">Catalogue des matières</h2>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Suivez votre avancement dans chaque matière.</p>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {categories.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setCategory(item)}
                      className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition ${
                        category === item
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                          : 'bg-white text-slate-600 hover:text-slate-900 dark:bg-slate-900 dark:text-slate-400 dark:hover:text-white'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {visibleSubjects.map((subject) => {
                  const Icon = subject.icon;
                  const done = doneBySubject[subject.id] ?? 0;
                  return (
                    <article
                      key={subject.id}
                      className="rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    >
                      <div className="flex items-center justify-between">
                        <span className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${subject.accent} shadow-md`}>
                          <Icon className="h-6 w-6 text-white" />
                        </span>
                        <span className="flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                          {subject.category}
                          <FavoriteButton type="subject" id={subject.id} label={subject.name} className="-mr-2" />
                        </span>
                      </div>
                      <h3 className="mt-5 text-lg font-semibold">{subject.name}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{subject.description}</p>
                      <div className="mt-5">
                        <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-400">
                          <span>Progression</span>
                          <span>{done} / {subject.lessons} leçons</span>
                        </div>
                        <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-violet-500 to-orange-500"
                            style={{ width: `${Math.min(100, (done / subject.lessons) * 100)}%` }}
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onSideViewChange({ name: 'lecons', subjectId: subject.id })}
                        className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200"
                      >
                        <Sparkles className="h-4 w-4" /> Apprendre
                      </button>
                    </article>
                  );
                })}
              </div>
            </section>
          </>
        )}

        {sideView.name === 'lecons' && (
          <LessonsPage
            key={`${sideView.subjectId ?? ''}-${sideView.lessonId ?? ''}-${sideView.autostart ? 'auto' : 'manual'}`}
            initialSubjectId={sideView.subjectId}
            autostart={sideView.autostart}
            initialLessonId={sideView.lessonId}
          />
        )}

        {sideView.name === 'cours' && <HelpBoard />}

        {sideView.name === 'communaute' && (
          <CommunityFeed onMessage={(id, name) => onSideViewChange({ name: 'messages', partnerId: id, partnerName: name })} />
        )}

        {sideView.name === 'blocnotes' && <NotesPage />}

        {sideView.name === 'exercices' && <ExercisesPage />}

        {sideView.name === 'langues' && <LanguagesPage />}

        {sideView.name === 'concours' && <ContestPage />}

        {sideView.name === 'messages' && (
          <MessagesPage
            key={sideView.partnerId ?? 'list'}
            initialPartner={sideView.partnerId ? { id: sideView.partnerId, name: sideView.partnerName ?? 'Élève' } : undefined}
          />
        )}

        {sideView.name === 'premium' && <PremiumPage onOpenPromo={() => setPromoOpen(true)} />}

        {(sideView.name === 'parametres' || sideView.name === 'compte') && (
          <SettingsPage
            onOpenSubject={(id) => onSideViewChange({ name: 'lecons', subjectId: id })}
            onOpenLesson={(id) => onSideViewChange({ name: 'lecons', lessonId: id })}
          />
        )}


        {sideView.name === 'notifications' && (
          <NotificationsPage onOpenView={(view) => onSideViewChange({ name: view as SideView['name'] })} />
        )}

        {sideView.name === 'accueil' && adminAllowed && (
          <section className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <h2 className="text-lg font-semibold">Administration</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Gérez les codes promotionnels et la modération.</p>
            <button
              type="button"
              onClick={() => onSideViewChange({ name: 'parametres' })}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
            >
              Ouvrir l'espace administrateur
            </button>
          </section>
        )}
      </main>

      {promoOpen && <PromoDialog onClose={() => setPromoOpen(false)} />}
      {editing && <ProfileEditDialog profile={profile} onClose={() => setEditing(false)} />}
    </div>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: number; label: string }) {
  return (
    <div className="min-w-[110px] rounded-2xl bg-white/10 px-5 py-4 backdrop-blur">
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-2xl font-bold tabular-nums">{value}</span>
      </div>
      <p className="mt-1 text-xs font-medium uppercase tracking-wider text-slate-300">{label}</p>
    </div>
  );
}
