import { useState, type FormEvent, type ReactNode } from 'react';
import { ArrowLeft, Flame, Loader2, Mail, Lock, User, GraduationCap, Target, ShieldCheck, type LucideIcon } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Logo } from '@/components/Logo';
import { schoolLevels, learningObjectives } from '@/data/subjects';

export type AuthMode = 'signin' | 'signup' | 'reset';

interface AuthPageProps {
  initialMode: AuthMode;
  onBack: () => void;
}

const inputClass =
  'w-full rounded-xl border border-slate-300 bg-white py-3 pl-11 pr-4 text-slate-900 placeholder:text-slate-400 transition focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500';

const selectClass =
  'w-full appearance-none rounded-xl border border-slate-300 bg-white py-3 pl-11 pr-4 text-slate-900 transition focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100';

export function AuthPage({ initialMode, onBack }: AuthPageProps) {
  const { signIn, signUp, resetPassword } = useAuth();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [level, setLevel] = useState('');
  const [objective, setObjective] = useState('');
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const switchMode = (next: AuthMode) => {
    setMode(next);
    setError(null);
    setInfo(null);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setInfo(null);

    if (mode === 'signup') {
      if (!level) return setError('Choisissez votre niveau scolaire.');
      if (!objective) return setError('Choisissez votre objectif d\'apprentissage.');
      if (password.length < 8) return setError('Le mot de passe doit contenir au moins 8 caractères.');
      if (!consent) return setError('Vous devez accepter les conditions et le consentement parental.');
    }

    setSubmitting(true);
    try {
      if (mode === 'signin') {
        await signIn(email.trim(), password);
      } else if (mode === 'signup') {
        await signUp({
          displayName: displayName.trim(),
          email: email.trim(),
          password,
          level,
          objective,
        });
      } else {
        await resetPassword(email.trim());
        setInfo('Si un compte existe pour cette adresse, un e-mail de réinitialisation vient d\'être envoyé.');
      }
    } catch (err) {
      setError(translateError(err instanceof Error ? err.message : ''));
    } finally {
      setSubmitting(false);
    }
  };

  const title = mode === 'signin' ? 'Bon retour parmi nous' : mode === 'signup' ? 'Créez votre compte' : 'Mot de passe oublié';
  const subtitle =
    mode === 'signin'
      ? 'Connectez-vous pour reprendre là où vous en étiez.'
      : mode === 'signup'
        ? 'Quelques secondes suffisent pour commencer votre parcours.'
        : 'Indiquez votre e-mail et nous vous enverrons un lien de réinitialisation.';

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 lg:flex-row">
      <aside className="relative hidden overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 p-12 text-white lg:flex lg:w-[42%] lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-orange-500/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-violet-500/30 blur-3xl" />
        <div className="relative">
          <Logo />
        </div>
        <div className="relative space-y-6">
          <Flame className="h-12 w-12 text-orange-400" />
          <p className="text-3xl font-semibold leading-tight">Chaque jour, une étape de plus vers la réussite.</p>
          <p className="max-w-sm text-base leading-relaxed text-slate-300">
            Des leçons courtes, des quiz et une flamme qui grandit avec votre régularité.
          </p>
        </div>
        <p className="relative text-sm text-slate-400">Primaire et secondaire, de P1 à S6.</p>
      </aside>

      <main className="flex flex-1 items-center justify-center px-6 py-12 sm:px-10">
        <div className="w-full max-w-md animate-[fadeUp_0.5s_ease-out]">
          <button
            type="button"
            onClick={onBack}
            className="mb-8 inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" /> Retour à l'accueil
          </button>

          <div className="lg:hidden mb-8">
            <Logo />
          </div>

          <h1 className="text-3xl font-bold leading-tight tracking-tight">{title}</h1>
          <p className="mt-2 text-base leading-relaxed text-slate-600 dark:text-slate-400">{subtitle}</p>

          {mode !== 'reset' && (
            <div className="mt-8 grid grid-cols-2 gap-1 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-900">
              {(['signin', 'signup'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => switchMode(tab)}
                  className={`rounded-lg py-2.5 text-sm font-semibold transition ${
                    mode === tab
                      ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {tab === 'signin' ? 'Se connecter' : 'Créer un compte'}
                </button>
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-8 space-y-4" noValidate>
            {mode === 'signup' && (
              <Field icon={User} label="Prénom ou pseudonyme">
                <input
                  className={inputClass}
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={40}
                  autoComplete="nickname"
                  placeholder="Ex. Lina"
                  required
                />
              </Field>
            )}

            <Field icon={Mail} label="Adresse e-mail">
              <input
                type="email"
                className={inputClass}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                placeholder="vous@exemple.com"
                required
              />
            </Field>

            {mode !== 'reset' && (
              <Field icon={Lock} label="Mot de passe">
                <input
                  type="password"
                  className={inputClass}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                  placeholder={mode === 'signup' ? '8 caractères minimum' : 'Votre mot de passe'}
                  required
                />
              </Field>
            )}

            {mode === 'signup' && (
              <>
                <Field icon={GraduationCap} label="Niveau scolaire">
                  <select className={selectClass} value={level} onChange={(e) => setLevel(e.target.value)} required>
                    <option value="" disabled>Choisir un niveau</option>
                    {schoolLevels.map((group) => (
                      <optgroup key={group.group} label={group.group}>
                        {group.levels.map((lvl) => (
                          <option key={lvl} value={lvl}>{lvl}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </Field>

                <Field icon={Target} label="Objectif d'apprentissage">
                  <select className={selectClass} value={objective} onChange={(e) => setObjective(e.target.value)} required>
                    <option value="" disabled>Choisir un objectif</option>
                    {learningObjectives.map((goal) => (
                      <option key={goal} value={goal}>{goal}</option>
                    ))}
                  </select>
                </Field>

                <label className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4 text-sm leading-relaxed text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={consent}
                    onChange={(e) => setConsent(e.target.checked)}
                    className="mt-1 h-4 w-4 shrink-0 accent-violet-600"
                  />
                  <span className="flex gap-2">
                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                    <span>
                      J'accepte les conditions d'utilisation et la politique de confidentialité. Pour les élèves mineurs, je certifie disposer de l'accord d'un parent ou d'un représentant légal.
                    </span>
                  </span>
                </label>
              </>
            )}

            {mode === 'signin' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => switchMode('reset')}
                  className="text-sm font-medium text-violet-600 transition hover:text-violet-500 dark:text-violet-400"
                >
                  Mot de passe oublié ?
                </button>
              </div>
            )}

            {error && (
              <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
                {error}
              </p>
            )}
            {info && (
              <p role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800 dark:border-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-300">
                {info}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-orange-500 py-3.5 font-semibold text-white shadow-lg shadow-violet-600/25 transition hover:-translate-y-0.5 hover:shadow-xl disabled:cursor-not-allowed disabled:opacity-70"
            >
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === 'signin' ? 'Se connecter' : mode === 'signup' ? 'Commencer gratuitement' : 'Envoyer le lien'}
            </button>

            {mode === 'reset' && (
              <button
                type="button"
                onClick={() => switchMode('signin')}
                className="w-full text-center text-sm font-medium text-slate-600 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
              >
                Revenir à la connexion
              </button>
            )}
          </form>
        </div>
      </main>
    </div>
  );
}

function Field({
  icon: Icon,
  label,
  children,
}: {
  icon: LucideIcon;
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">{label}</span>
      <span className="relative block">
        <Icon className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        {children}
      </span>
    </label>
  );
}

function translateError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('invalid login')) return 'E-mail ou mot de passe incorrect.';
  if (lower.includes('already registered') || lower.includes('already been registered')) {
    return 'Un compte existe déjà avec cette adresse e-mail.';
  }
  if (lower.includes('password should be at least')) return 'Le mot de passe doit contenir au moins 6 caractères.';
  if (lower.includes('email not confirmed')) return 'Adresse e-mail non confirmée.';
  if (lower.includes('failed to fetch') || lower.includes('network')) {
    return 'Connexion impossible. Vérifiez votre réseau et réessayez.';
  }
  return message || 'Une erreur inattendue est survenue. Réessayez.';
}
