import { useCallback, useEffect, useState } from 'react';

export type ThemeMode = 'light' | 'dark' | 'auto';
export type Theme = 'light' | 'dark';

const STORAGE_KEY = 'studyflame-theme-mode';

function systemTheme(): Theme {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function readInitialMode(): ThemeMode {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored === 'light' || stored === 'dark' || stored === 'auto') return stored;
  return 'auto';
}

export function useTheme() {
  const [mode, setMode] = useState<ThemeMode>(readInitialMode);
  const [theme, setTheme] = useState<Theme>(() => (mode === 'auto' ? systemTheme() : mode));

  const applyTheme = useCallback((nextMode: ThemeMode) => {
    const nextTheme = nextMode === 'auto' ? systemTheme() : nextMode;
    setTheme(nextTheme);
    document.documentElement.classList.toggle('dark', nextTheme === 'dark');
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, mode);
    applyTheme(mode);
    if (mode !== 'auto') return;

    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => applyTheme('auto');
    media.addEventListener('change', onChange);
    return () => media.removeEventListener('change', onChange);
  }, [mode, applyTheme]);

  const setThemeMode = useCallback((nextMode: ThemeMode) => {
    setMode(nextMode);
  }, []);

  const toggleTheme = useCallback(() => {
    setMode((current) => (current === 'dark' ? 'light' : 'dark'));
  }, []);

  return { theme, mode, setThemeMode, toggleTheme };
}
