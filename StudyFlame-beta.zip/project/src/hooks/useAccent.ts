import { useCallback, useState } from 'react';
import { accents, defaultAccentId, palettes, shades } from '@/data/accents';

const STORAGE_KEY = 'studyflame-accent';

function channels(hex: string): string {
  const value = parseInt(hex.slice(1), 16);
  return `${(value >> 16) & 255} ${(value >> 8) & 255} ${value & 255}`;
}

export function applyAccent(id: string): void {
  const accent = accents.find((item) => item.id === id) ?? accents[0];
  const root = document.documentElement;
  for (const shade of shades) {
    root.style.setProperty(`--orange-${shade}`, channels(palettes[accent.primary][shade]));
    root.style.setProperty(`--violet-${shade}`, channels(palettes[accent.secondary][shade]));
  }
  root.dataset.accent = accent.id;
}

export function readStoredAccent(): string {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && accents.some((item) => item.id === stored)) return stored;
  } catch {
    /* storage unavailable */
  }
  return defaultAccentId;
}

// Apply the saved theme as soon as the app loads, before the first screen.
if (typeof document !== 'undefined') applyAccent(readStoredAccent());

export function useAccent() {
  const [accentId, setAccentId] = useState(readStoredAccent);

  const setAccent = useCallback((id: string) => {
    setAccentId(id);
    applyAccent(id);
    try {
      localStorage.setItem(STORAGE_KEY, id);
    } catch {
      /* storage unavailable */
    }
  }, []);

  return { accentId, setAccent };
}
