import { useEffect, useState } from 'react';
import { ChevronRight, Loader2, MessageSquarePlus } from 'lucide-react';
import { getSubjectName, subjects } from '@/data/subjects';
import { formatHelpDate, helpErrorMessage, listPosts, type HelpPost } from '@/lib/helpForum';
import { NewPostDialog } from '@/components/help/NewPostDialog';
import { PostThread } from '@/components/help/PostThread';

export function HelpBoard() {
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [posts, setPosts] = useState<HelpPost[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    let active = true;
    setPosts(null);
    setLoadError(null);
    listPosts(subjectId)
      .then((data) => {
        if (active) setPosts(data);
      })
      .catch((err) => {
        if (active) setLoadError(helpErrorMessage(err));
      });
    return () => {
      active = false;
    };
  }, [subjectId, reloadKey]);

  if (selectedPostId) {
    return (
      <PostThread
        postId={selectedPostId}
        onBack={() => {
          setSelectedPostId(null);
          setReloadKey((key) => key + 1);
        }}
        onDeleted={() => {
          setSelectedPostId(null);
          setReloadKey((key) => key + 1);
        }}
      />
    );
  }

  return (
    <section className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Entraide des devoirs</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Posez une question, aidez les autres élèves à leur tour.</p>
        </div>
        <button
          type="button"
          onClick={() => setCreating(true)}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
        >
          <MessageSquarePlus className="h-4 w-4" /> Poser une question
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Filtrer par matière">
        {[null, ...subjects.map((subject) => subject.id)].map((id) => (
          <button
            key={id ?? 'all'}
            type="button"
            role="tab"
            aria-selected={subjectId === id}
            onClick={() => setSubjectId(id)}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition ${
              subjectId === id
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                : 'bg-white text-slate-600 hover:text-slate-900 dark:bg-slate-900 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            {id === null ? 'Toutes' : getSubjectName(id)}
          </button>
        ))}
      </div>

      {loadError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
          {loadError}
        </p>
      )}

      {!posts && !loadError && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
        </div>
      )}

      {posts && posts.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <p className="font-semibold">Aucune question pour le moment</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Soyez le premier à poser votre question.</p>
        </div>
      )}

      {posts && posts.length > 0 && (
        <ul className="space-y-3">
          {posts.map((post) => (
            <li key={post.id}>
              <button
                type="button"
                onClick={() => setSelectedPostId(post.id)}
                className="group flex w-full items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5 text-left transition duration-300 hover:-translate-y-0.5 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="min-w-0 flex-1">
                  <span className="text-xs font-semibold uppercase tracking-wider text-sky-700 dark:text-sky-400">{getSubjectName(post.subject_id)}</span>
                  <h3 className="mt-1 truncate text-lg font-semibold">{post.title}</h3>
                  <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{post.body}</p>
                  <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">{post.author_name} · {formatHelpDate(post.created_at)}</p>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-700 dark:group-hover:text-slate-200" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {creating && (
        <NewPostDialog
          defaultSubjectId={subjectId}
          onClose={() => setCreating(false)}
          onCreated={(post) => {
            setCreating(false);
            setSelectedPostId(post.id);
          }}
        />
      )}
    </section>
  );
}
