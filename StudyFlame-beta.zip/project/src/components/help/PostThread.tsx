import { useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, Flag, Loader2, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getSubjectName } from '@/data/subjects';
import {
  createReply,
  deletePost,
  deleteReply,
  formatHelpDate,
  getPost,
  helpErrorMessage,
  listReplies,
  reportContent,
  type HelpPost,
  type HelpReply,
} from '@/lib/helpForum';
import { helpFieldClass } from '@/components/help/NewPostDialog';

interface PostThreadProps {
  postId: string;
  onBack: () => void;
  onDeleted: () => void;
}

export function PostThread({ postId, onBack, onDeleted }: PostThreadProps) {
  const { user } = useAuth();
  const [post, setPost] = useState<HelpPost | null>(null);
  const [replies, setReplies] = useState<HelpReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [replyBody, setReplyBody] = useState('');
  const [replyError, setReplyError] = useState<string | null>(null);
  const [sendingReply, setSendingReply] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [reported, setReported] = useState<Set<string>>(new Set());
  const [confirmingDelete, setConfirmingDelete] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setLoadError(null);
    Promise.all([getPost(postId), listReplies(postId)])
      .then(([loadedPost, loadedReplies]) => {
        if (!active) return;
        setPost(loadedPost);
        setReplies(loadedReplies);
      })
      .catch((err) => {
        if (active) setLoadError(helpErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [postId]);

  const markReported = (key: string) => setReported((previous) => new Set(previous).add(key));

  const handleReport = async (type: 'post' | 'reply', id: string) => {
    setActionError(null);
    try {
      await reportContent(type, id);
      markReported(`${type}-${id}`);
    } catch (err) {
      setActionError(helpErrorMessage(err));
    }
  };

  const handleReply = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = replyBody.trim();
    if (!trimmed) return setReplyError('Écrivez votre réponse avant de l\'envoyer.');

    setReplyError(null);
    setSendingReply(true);
    try {
      const reply = await createReply({ postId, body: trimmed });
      setReplies((previous) => [...previous, reply]);
      setReplyBody('');
    } catch (err) {
      setReplyError(helpErrorMessage(err));
    } finally {
      setSendingReply(false);
    }
  };

  const handleDeletePost = async () => {
    setActionError(null);
    try {
      await deletePost(postId);
      onDeleted();
    } catch (err) {
      setActionError(helpErrorMessage(err));
    }
  };

  const handleDeleteReply = async (replyId: string) => {
    setActionError(null);
    try {
      await deleteReply(replyId);
      setReplies((previous) => previous.filter((reply) => reply.id !== replyId));
      setConfirmingDelete(null);
    } catch (err) {
      setActionError(helpErrorMessage(err));
    }
  };

  const backButton = (
    <button
      type="button"
      onClick={onBack}
      className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-white"
    >
      <ArrowLeft className="h-4 w-4" /> Retour aux questions
    </button>
  );

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
      </div>
    );
  }

  if (loadError || !post) {
    return (
      <div className="space-y-4">
        {backButton}
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
          {loadError ?? 'Cette question n\'est plus disponible.'}
        </p>
      </div>
    );
  }

  const isOwnPost = post.user_id === user?.id;
  const postReported = reported.has(`post-${post.id}`);

  return (
    <div className="space-y-6">
      {backButton}

      <article className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <span className="text-xs font-semibold uppercase tracking-wider text-sky-700 dark:text-sky-400">{getSubjectName(post.subject_id)}</span>
        <h2 className="mt-2 text-2xl font-bold tracking-tight">{post.title}</h2>
        <p className="mt-3 whitespace-pre-wrap text-base leading-relaxed text-slate-700 dark:text-slate-300">{post.body}</p>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 text-sm text-slate-500 dark:border-slate-800 dark:text-slate-400">
          <span>{post.author_name} · {formatHelpDate(post.created_at)}</span>
          <div className="flex items-center gap-2">
            {!isOwnPost && (
              <ReportButton reported={postReported} onReport={() => handleReport('post', post.id)} />
            )}
            {isOwnPost && (
              confirmingDelete === post.id ? (
                <DeleteConfirm onConfirm={handleDeletePost} onCancel={() => setConfirmingDelete(null)} />
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmingDelete(post.id)}
                  className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/60 dark:hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" /> Supprimer
                </button>
              )
            )}
          </div>
        </div>
      </article>

      {actionError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
          {actionError}
        </p>
      )}

      <section className="space-y-4">
        <h3 className="text-lg font-semibold">
          {replies.length === 0 ? 'Aucune réponse pour le moment' : `${replies.length} réponse${replies.length > 1 ? 's' : ''}`}
        </h3>

        {replies.map((reply) => {
          const isOwnReply = reply.user_id === user?.id;
          const replyReported = reported.has(`reply-${reply.id}`);
          return (
            <div key={reply.id} className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <p className="whitespace-pre-wrap text-base leading-relaxed text-slate-700 dark:text-slate-300">{reply.body}</p>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500 dark:text-slate-400">
                <span>{reply.author_name} · {formatHelpDate(reply.created_at)}</span>
                <div className="flex items-center gap-2">
                  {!isOwnReply && (
                    <ReportButton reported={replyReported} onReport={() => handleReport('reply', reply.id)} />
                  )}
                  {isOwnReply && (
                    confirmingDelete === reply.id ? (
                      <DeleteConfirm onConfirm={() => handleDeleteReply(reply.id)} onCancel={() => setConfirmingDelete(null)} />
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmingDelete(reply.id)}
                        className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/60 dark:hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" /> Supprimer
                      </button>
                    )
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </section>

      <form onSubmit={handleReply} className="space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900" noValidate>
        <label className="block">
          <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Votre réponse</span>
          <textarea
            className={`${helpFieldClass} min-h-[110px] resize-y`}
            value={replyBody}
            maxLength={2000}
            placeholder="Expliquez simplement, étape par étape."
            onChange={(e) => setReplyBody(e.target.value)}
          />
        </label>
        {replyError && (
          <p role="alert" className="text-sm text-red-600 dark:text-red-400">{replyError}</p>
        )}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={sendingReply}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
          >
            {sendingReply && <Loader2 className="h-4 w-4 animate-spin" />}
            Répondre
          </button>
        </div>
      </form>
    </div>
  );
}

function ReportButton({ reported, onReport }: { reported: boolean; onReport: () => void }) {
  if (reported) {
    return <span className="px-2.5 py-1.5 text-sm font-medium text-slate-500 dark:text-slate-400">Signalé, merci</span>;
  }
  return (
    <button
      type="button"
      onClick={onReport}
      className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-medium text-slate-500 transition hover:bg-amber-50 hover:text-amber-700 dark:hover:bg-amber-950/60 dark:hover:text-amber-300"
    >
      <Flag className="h-4 w-4" /> Signaler
    </button>
  );
}

function DeleteConfirm({ onConfirm, onCancel }: { onConfirm: () => void; onCancel: () => void }) {
  return (
    <span className="inline-flex items-center gap-2">
      <button type="button" onClick={onCancel} className="rounded-lg px-2.5 py-1.5 font-medium text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
        Annuler
      </button>
      <button type="button" onClick={onConfirm} className="rounded-lg bg-red-600 px-2.5 py-1.5 font-semibold text-white hover:bg-red-700">
        Confirmer
      </button>
    </span>
  );
}
