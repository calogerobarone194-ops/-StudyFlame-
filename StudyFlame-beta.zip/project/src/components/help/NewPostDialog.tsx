import { useEffect, useState, type FormEvent } from 'react';
import { Loader2, X } from 'lucide-react';
import { subjects } from '@/data/subjects';
import { createPost, helpErrorMessage, type HelpPost } from '@/lib/helpForum';

interface NewPostDialogProps {
  defaultSubjectId: string | null;
  onClose: () => void;
  onCreated: (post: HelpPost) => void;
}

export const helpFieldClass =
  'w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100';

export function NewPostDialog({ defaultSubjectId, onClose, onCreated }: NewPostDialogProps) {
  const [subjectId, setSubjectId] = useState(defaultSubjectId ?? subjects[0].id);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedTitle = title.trim();
    const trimmedBody = body.trim();
    if (trimmedTitle.length < 3) return setError('Le titre doit contenir au moins 3 caractères.');
    if (trimmedBody.length < 3) return setError('Décrivez votre question en au moins 3 caractères.');

    setError(null);
    setSaving(true);
    try {
      const post = await createPost({ subjectId, title: trimmedTitle, body: trimmedBody });
      onCreated(post);
    } catch (err) {
      setError(helpErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm animate-fadeUp" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="new-post-title"
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="new-post-title" className="text-xl font-bold">Poser une question</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Expliquez ce qui bloque, les autres élèves vous aideront.</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Matière</span>
            <select className={helpFieldClass} value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
              {subjects.map((subject) => (
                <option key={subject.id} value={subject.id}>{subject.name}</option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Titre de la question</span>
            <input className={helpFieldClass} value={title} maxLength={120} placeholder="Ex. Comment calculer une moyenne pondérée ?" onChange={(e) => setTitle(e.target.value)} />
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Détails</span>
            <textarea
              className={`${helpFieldClass} min-h-[140px] resize-y`}
              value={body}
              maxLength={2000}
              placeholder="Montrez ce que vous avez déjà essayé."
              onChange={(e) => setBody(e.target.value)}
            />
            <span className="mt-1.5 block text-right text-xs text-slate-500 dark:text-slate-400">{body.length} / 2000</span>
          </label>

          <p className="rounded-xl bg-slate-50 px-4 py-3 text-xs leading-relaxed text-slate-600 dark:bg-slate-900 dark:text-slate-400">
            Ne partagez jamais de numéro de téléphone, d'adresse e-mail, de lien ou de pseudo de réseau social.
          </p>

          {error && (
            <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
              {error}
            </p>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-slate-300 py-3 font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-900"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Publier
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
