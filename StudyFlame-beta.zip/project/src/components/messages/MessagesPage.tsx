import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Loader2, MessageSquare, Search } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { MessageComposer, ReportMessageButton, useConversations, type DirectMessage } from '@/lib/messages';

interface Partner {
  id: string;
  name: string;
}

const timeFmt = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export function MessagesPage({ initialPartner }: { initialPartner?: Partner }) {
  const [partner, setPartner] = useState<Partner | null>(initialPartner ?? null);

  if (partner) {
    return <Thread partner={partner} onBack={() => setPartner(null)} />;
  }
  return <ConversationList onOpen={setPartner} />;
}

function ConversationList({ onOpen }: { onOpen: (partner: Partner) => void }) {
  const { conversations, error, reload } = useConversations();
  const [search, setSearch] = useState('');

  useEffect(() => {
    void reload();
  }, [reload]);

  const filtered = conversations?.filter((item) => item.partner_name.toLowerCase().includes(search.trim().toLowerCase()));

  return (
    <section className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Messages</h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Tes conversations privées. Pour écrire à quelqu'un, utilise le bouton « Écrire » sur ses publications dans la Communauté.
        </p>
      </div>

      {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{error}</p>}

      <label className="relative block">
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          aria-label="Rechercher une conversation"
          placeholder="Rechercher une conversation…"
          className="w-full rounded-xl border border-slate-300 bg-white py-3 pl-11 pr-4 dark:border-slate-700 dark:bg-slate-900"
        />
      </label>

      {!conversations && !error && <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-slate-500" /></div>}

      {filtered && filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <MessageSquare className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-2 font-semibold">Aucune conversation</p>
        </div>
      )}

      {filtered && filtered.length > 0 && (
        <ul className="space-y-2">
          {filtered.map((item) => (
            <li key={item.partner_id}>
              <button
                type="button"
                onClick={() => onOpen({ id: item.partner_id, name: item.partner_name })}
                className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900"
              >
                <span className="flex justify-between gap-3">
                  <span className="text-sm font-semibold">{item.partner_name}</span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">{timeFmt.format(new Date(item.last_at))}</span>
                </span>
                <span className="mt-0.5 block truncate text-sm text-slate-600 dark:text-slate-400">{item.last_body}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Thread({ partner, onBack }: { partner: Partner; onBack: () => void }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<DirectMessage[] | null>(null);
  const [error, setError] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const { data, error: fetchError } = await supabase
      .from('direct_messages')
      .select('id, sender_id, recipient_id, body, created_at')
      .or(
        `and(sender_id.eq.${user.id},recipient_id.eq.${partner.id}),and(sender_id.eq.${partner.id},recipient_id.eq.${user.id})`,
      )
      .order('created_at', { ascending: true })
      .limit(200);
    if (fetchError) {
      setError(true);
      setMessages((previous) => previous ?? []);
      return;
    }
    setError(false);
    setMessages(data ?? []);
  }, [user, partner.id]);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 10000);
    return () => window.clearInterval(timer);
  }, [load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'end' });
  }, [messages?.length]);

  return (
    <section className="mx-auto max-w-2xl space-y-4">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" /> Messages
      </button>
      <h1 className="text-xl font-bold">{partner.name}</h1>

      {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400">Impossible de charger les messages.</p>}

      <div className="max-h-[50vh] min-h-[200px] space-y-2 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900" aria-live="polite">
        {!messages ? (
          <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
        ) : messages.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">Écris le premier message.</p>
        ) : (
          messages.map((message) => {
            const mine = message.sender_id === user?.id;
            return (
              <div key={message.id} className={`flex items-end gap-1 ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${mine ? 'bg-orange-500 text-white' : 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100'}`}>
                  <p className="whitespace-pre-wrap break-words">{message.body}</p>
                  <p className={`mt-1 text-[11px] ${mine ? 'text-orange-100' : 'text-slate-500 dark:text-slate-400'}`}>{timeFmt.format(new Date(message.created_at))}</p>
                </div>
                {!mine && <ReportMessageButton messageId={message.id} onReported={() => void load()} />}
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      <MessageComposer recipientId={partner.id} recipientName={partner.name} onSent={() => void load()} />
    </section>
  );
}
