import { useEffect, useMemo, useState } from 'react';
import { Award, Loader2, Lock, Medal, Trophy } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { computeBadges, getWeeklyLeaderboard, type LeaderboardRow } from '@/lib/contest';
import { listLessons, type Lesson } from '@/lib/lessons';

function daysLeftInWeek(): number {
  // Week ends Sunday night; getDay(): 0 = Sunday.
  const day = new Date().getDay();
  return day === 0 ? 0 : 7 - day;
}

export function ContestPage() {
  const { profile } = useAuth();
  const [rows, setRows] = useState<LeaderboardRow[] | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    let active = true;
    getWeeklyLeaderboard(10)
      .then((data) => active && setRows(data))
      .catch(() => {
        if (active) {
          setError(true);
          setRows([]);
        }
      });
    listLessons()
      .then((data) => active && setLessons(data))
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  const badges = useMemo(
    () => computeBadges({ xp: profile?.xp ?? 0, flames: profile?.flames ?? 0, lessons }),
    [profile?.xp, profile?.flames, lessons],
  );
  const unlocked = badges.filter((badge) => badge.unlocked).length;
  const left = daysLeftInWeek();

  return (
    <section className="space-y-10">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <Trophy className="h-6 w-6 text-orange-500" /> Concours et récompenses
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Le classement de la semaine compte l'XP gagné en terminant des leçons et des exercices. Tu es comparé aux élèves de ton niveau,
          avec leur pseudo seulement.
        </p>
      </div>

      <div>
        <div className="flex items-end justify-between">
          <h2 className="text-lg font-bold">Classement de la semaine</h2>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {left === 0 ? 'Dernier jour !' : `Se termine dans ${left} jour${left > 1 ? 's' : ''}`}
          </span>
        </div>

        {!rows ? (
          <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
        ) : error ? (
          <p role="alert" className="mt-3 text-sm text-red-600 dark:text-red-400">Impossible de charger le classement.</p>
        ) : rows.length === 0 ? (
          <p className="mt-3 rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
            Personne n'a encore marqué d'XP cette semaine. Termine une leçon pour prendre la première place !
          </p>
        ) : (
          <ol className="mt-3 space-y-2">
            {rows.map((row) => (
              <li
                key={`${row.rank}-${row.display_name}-${row.is_me}`}
                className={`flex items-center gap-3 rounded-xl border p-3 ${
                  row.is_me
                    ? 'border-orange-400 bg-orange-50 dark:border-orange-700 dark:bg-orange-950/30'
                    : 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900'
                }`}
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-sm font-bold dark:bg-slate-800">
                  {row.rank <= 3 ? <Medal className={`h-4 w-4 ${row.rank === 1 ? 'text-amber-500' : row.rank === 2 ? 'text-slate-400' : 'text-orange-700'}`} /> : row.rank}
                </span>
                <span className="flex-1 truncate text-sm font-semibold">
                  {row.display_name}
                  {row.is_me && ' (toi)'}
                </span>
                <span className="text-sm font-bold tabular-nums">{row.weekly_xp} XP</span>
              </li>
            ))}
          </ol>
        )}
      </div>

      <div>
        <h2 className="flex items-center gap-2 text-lg font-bold">
          <Award className="h-5 w-5 text-violet-500" /> Mes badges
          <span className="text-sm font-medium text-slate-500">({unlocked} / {badges.length})</span>
        </h2>
        <ul className="mt-3 grid gap-3 sm:grid-cols-2">
          {badges.map((badge) => (
            <li
              key={badge.id}
              className={`flex items-center gap-3 rounded-xl border p-4 ${
                badge.unlocked
                  ? 'border-violet-200 bg-violet-50 dark:border-violet-900/60 dark:bg-violet-950/30'
                  : 'border-slate-200 bg-white opacity-75 dark:border-slate-800 dark:bg-slate-900'
              }`}
            >
              <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${badge.unlocked ? 'bg-gradient-to-br from-violet-500 to-orange-500 text-white' : 'bg-slate-200 text-slate-500 dark:bg-slate-800'}`}>
                {badge.unlocked ? <Award className="h-5 w-5" /> : <Lock className="h-4 w-4" />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold">{badge.label}</span>
                <span className="block text-xs text-slate-600 dark:text-slate-400">{badge.description}</span>
              </span>
              <span className="text-xs font-semibold tabular-nums text-slate-500">{badge.progress}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
