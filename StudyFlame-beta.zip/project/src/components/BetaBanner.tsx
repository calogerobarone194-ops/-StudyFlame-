import { useState } from 'react';
import { FlaskConical, X } from 'lucide-react';

const STORAGE_KEY = 'studyflame-beta-banner-dismissed';

function wasDismissed(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) === '1';
  } catch {
    return false;
  }
}

export function BetaBanner({ onOpenSettings }: { onOpenSettings: () => void }) {
  const [hidden, setHidden] = useState(wasDismissed);
  if (hidden) return null;

  const dismiss = () => {
    setHidden(true);
    try {
      localStorage.setItem(STORAGE_KEY, '1');
    } catch {
      /* storage unavailable */
    }
  };

  return (
    <div role="note" className="flex items-start gap-3 rounded-2xl border border-orange-200 bg-orange-50 p-4 text-sm dark:border-orange-900/60 dark:bg-orange-950/30">
      <FlaskConical className="mt-0.5 h-5 w-5 shrink-0 text-orange-600 dark:text-orange-400" />
      <p className="min-w-0 flex-1 text-slate-700 dark:text-slate-300">
        <strong className="font-semibold">StudyFlame est en version bêta.</strong> Tout n'est pas encore parfait et certaines choses peuvent changer.
        Un problème ou une idée ?{' '}
        <button type="button" onClick={onOpenSettings} className="font-semibold text-orange-700 underline underline-offset-2 dark:text-orange-300">
          Donne-nous ton avis
        </button>
        .
      </p>
      <button
        type="button"
        onClick={dismiss}
        aria-label="Fermer le message bêta"
        className="rounded-lg p-1 text-slate-500 transition hover:bg-orange-100 hover:text-slate-900 dark:hover:bg-orange-900/40 dark:hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
