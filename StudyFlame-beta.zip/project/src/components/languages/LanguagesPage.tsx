import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { CheckCircle2, Languages as LanguagesIcon, Loader2 } from 'lucide-react';
import { getSubjectName, languages } from '@/data/subjects';
import { listLessons, type Lesson } from '@/lib/lessons';
import { LessonPlayer } from '@/components/lessons/LessonPlayer';
import { useLessonGenerator } from '@/components/lessons/useLessonGenerator';

const skills = ['Vocabulaire', 'Grammaire', 'Conjugaison', 'Compréhension écrite', 'Expressions utiles'] as const;

export function LanguagesPage() {
  const [languageId, setLanguageId] = useState<string>(languages[0].id);
  const [skill, setSkill] = useState<string>(skills[0]);
  const [topic, setTopic] = useState('');
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const { generating, error, run } = useLessonGenerator();

  const reload = useCallback(async () => {
    try {
      setLessons(await listLessons());
    } catch {
      /* the list is a bonus, generation still works */
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const languageIds = useMemo<string[]>(() => languages.map((language) => language.id), []);
  const mine = lessons.filter((lesson) => languageIds.includes(lesson.subject_id));

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (generating) return;
    const theme = topic.trim() ? `${skill} : ${topic.trim()}` : skill;
    const id = await run(languageId, theme, 'lesson');
    if (id) {
      setTopic('');
      setOpenId(id);
    }
  };

  if (openId) {
    return (
      <LessonPlayer
        lessonId={openId}
        onBack={() => {
          setOpenId(null);
          void reload();
        }}
      />
    );
  }

  return (
    <section className="space-y-8">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <LanguagesIcon className="h-6 w-6 text-orange-500" /> Apprentissage des langues
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Choisis une langue et une compétence : la leçon est adaptée à ton niveau.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <fieldset>
          <legend className="text-sm font-semibold">Langue</legend>
          <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {languages.map((language) => (
              <button
                key={language.id}
                type="button"
                aria-pressed={languageId === language.id}
                onClick={() => setLanguageId(language.id)}
                className={`rounded-xl border px-4 py-3 text-left transition ${
                  languageId === language.id
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/30'
                    : 'border-slate-200 hover:border-slate-400 dark:border-slate-700'
                }`}
              >
                <span className="block text-xs font-bold text-slate-500">{language.flag}</span>
                <span className="block text-sm font-semibold">{language.name}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend className="text-sm font-semibold">Compétence</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {skills.map((item) => (
              <button
                key={item}
                type="button"
                aria-pressed={skill === item}
                onClick={() => setSkill(item)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  skill === item ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
          <input
            value={topic}
            onChange={(event) => setTopic(event.target.value)}
            maxLength={100}
            disabled={generating}
            aria-label="Thème (facultatif)"
            placeholder="Thème (facultatif) : la famille, les nombres, au restaurant…"
            className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-950"
          />
          <button
            type="submit"
            disabled={generating}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-3 text-sm font-semibold text-white shadow-md disabled:opacity-60"
          >
            {generating && <Loader2 className="h-4 w-4 animate-spin" />}
            {generating ? 'Création…' : 'Créer ma leçon'}
          </button>
        </div>
        {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{error}</p>}
      </form>

      {mine.length > 0 && (
        <div>
          <h2 className="text-lg font-bold">Mes leçons de langues</h2>
          <ul className="mt-3 space-y-2">
            {mine.slice(0, 15).map((lesson) => (
              <li key={lesson.id}>
                <button
                  type="button"
                  onClick={() => setOpenId(lesson.id)}
                  className="flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 text-left transition hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900"
                >
                  {lesson.status === 'done' ? (
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" />
                  ) : (
                    <span className="h-5 w-5 shrink-0 rounded-full border-2 border-orange-400" />
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">{lesson.title}</span>
                    <span className="block text-xs text-slate-500 dark:text-slate-400">{getSubjectName(lesson.subject_id)}</span>
                  </span>
                  {lesson.status === 'done' && <span className="text-sm font-semibold">{lesson.score} / {lesson.total}</span>}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
