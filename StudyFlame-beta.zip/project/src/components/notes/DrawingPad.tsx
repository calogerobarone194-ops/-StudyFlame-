import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Eraser, PenLine, Trash2, Undo2 } from 'lucide-react';

const WIDTH = 800;
const HEIGHT = 500;
const colors = ['#0f172a', '#dc2626', '#2563eb', '#16a34a', '#f59e0b', '#9333ea'];
const sizes = [
  { value: 2, label: 'Fin' },
  { value: 5, label: 'Moyen' },
  { value: 12, label: 'Épais' },
];

interface DrawingPadProps {
  /** PNG data URL of the saved drawing, or null for a blank page. */
  initial: string | null;
  /** Called after each stroke with the PNG data URL, or null when the page is blank. */
  onChange: (dataUrl: string | null) => void;
}

export function DrawingPad({ initial, onChange }: DrawingPadProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const historyRef = useRef<ImageData[]>([]);
  const inkRef = useRef(false);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [color, setColor] = useState(colors[0]);
  const [size, setSize] = useState(sizes[1].value);
  const [canUndo, setCanUndo] = useState(false);

  const paintBackground = useCallback(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    paintBackground();
    historyRef.current = [];
    setCanUndo(false);
    inkRef.current = false;
    if (initial) {
      const image = new Image();
      image.onload = () => {
        ctx.drawImage(image, 0, 0, WIDTH, HEIGHT);
        inkRef.current = true;
      };
      image.src = initial;
    }
  }, [initial, paintBackground]);

  const point = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) * WIDTH) / rect.width,
      y: ((event.clientY - rect.top) * HEIGHT) / rect.height,
    };
  };

  const stroke = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    ctx.lineWidth = tool === 'eraser' ? size * 2.5 : size;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
  };

  const handleDown = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    canvas.setPointerCapture(event.pointerId);
    historyRef.current = [...historyRef.current.slice(-19), ctx.getImageData(0, 0, WIDTH, HEIGHT)];
    setCanUndo(true);
    drawingRef.current = true;
    const start = point(event);
    lastRef.current = start;
    stroke(start, { x: start.x + 0.01, y: start.y }); // a dot for a simple tap
  };

  const handleMove = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current || !lastRef.current) return;
    const next = point(event);
    stroke(lastRef.current, next);
    lastRef.current = next;
  };

  const finish = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    lastRef.current = null;
    inkRef.current = true;
    onChange(canvasRef.current!.toDataURL('image/png'));
  };

  const undo = () => {
    const ctx = canvasRef.current?.getContext('2d');
    const previous = historyRef.current.pop();
    if (!ctx || !previous) return;
    ctx.putImageData(previous, 0, 0);
    setCanUndo(historyRef.current.length > 0);
    onChange(inkRef.current ? canvasRef.current!.toDataURL('image/png') : null);
  };

  const clear = () => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    historyRef.current = [...historyRef.current.slice(-19), ctx.getImageData(0, 0, WIDTH, HEIGHT)];
    setCanUndo(true);
    paintBackground();
    inkRef.current = false;
    onChange(null);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2" role="toolbar" aria-label="Outils de dessin">
        <button
          type="button"
          aria-pressed={tool === 'pen'}
          onClick={() => setTool('pen')}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold ${tool === 'pen' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}
        >
          <PenLine className="h-4 w-4" /> Stylo
        </button>
        <button
          type="button"
          aria-pressed={tool === 'eraser'}
          onClick={() => setTool('eraser')}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold ${tool === 'eraser' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}
        >
          <Eraser className="h-4 w-4" /> Gomme
        </button>
        <span className="mx-1 hidden h-6 w-px bg-slate-300 dark:bg-slate-700 sm:block" />
        {colors.map((value) => (
          <button
            key={value}
            type="button"
            aria-label={`Couleur ${value}`}
            aria-pressed={tool === 'pen' && color === value}
            onClick={() => {
              setColor(value);
              setTool('pen');
            }}
            style={{ backgroundColor: value }}
            className={`h-7 w-7 rounded-full border-2 ${tool === 'pen' && color === value ? 'border-slate-900 ring-2 ring-slate-400 dark:border-white' : 'border-white dark:border-slate-700'}`}
          />
        ))}
        <span className="mx-1 hidden h-6 w-px bg-slate-300 dark:bg-slate-700 sm:block" />
        {sizes.map((item) => (
          <button
            key={item.value}
            type="button"
            aria-pressed={size === item.value}
            onClick={() => setSize(item.value)}
            className={`rounded-lg px-3 py-2 text-xs font-semibold ${size === item.value ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}
          >
            {item.label}
          </button>
        ))}
        <span className="ml-auto flex gap-2">
          <button
            type="button"
            onClick={undo}
            disabled={!canUndo}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-700 disabled:opacity-40 dark:bg-slate-800 dark:text-slate-300"
          >
            <Undo2 className="h-4 w-4" /> Annuler
          </button>
          <button
            type="button"
            onClick={clear}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-700 hover:text-red-600 dark:bg-slate-800 dark:text-slate-300"
          >
            <Trash2 className="h-4 w-4" /> Tout effacer
          </button>
        </span>
      </div>

      <canvas
        ref={canvasRef}
        width={WIDTH}
        height={HEIGHT}
        aria-label="Zone de dessin"
        onPointerDown={handleDown}
        onPointerMove={handleMove}
        onPointerUp={finish}
        onPointerCancel={finish}
        className="aspect-[8/5] w-full cursor-crosshair touch-none rounded-xl border border-slate-300 bg-white shadow-inner dark:border-slate-600"
      />
    </div>
  );
}
