import { useCallback, useEffect, useState } from 'react';
import { FileText, Loader2, PenLine, Plus, Save, Trash2, Type } from 'lucide-react';
import { getSubjectName, subjects } from '@/data/subjects';
import { DrawingPad } from '@/components/notes/DrawingPad';
import { createNote, deleteNote, getNoteDrawing, listNotes, updateNote, type Note } from '@/lib/notes';

const dateFmt = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const MAX_DRAWING_LENGTH = 590000;


export function NotesPage() {
  const [notes, setNotes] = useState<Note[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | 'new' | null>(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [mode, setMode] = useState<'text' | 'draw'>('text');
  // `loadedDrawing` feeds the canvas when a note opens; `drawing` is the current content after strokes.
  const [loadedDrawing, setLoadedDrawing] = useState<string | null>(null);
  const [drawing, setDrawing] = useState<string | null>(null);
  const [drawingDirty, setDrawingDirty] = useState(false);
  const [drawingLoading, setDrawingLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ kind: 'ok' | 'error'; text: string } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const load = useCallback(async () => {
    try {
      setNotes(await listNotes());
    } catch {
      setNotes([]);
      setMessage({ kind: 'error', text: 'Impossible de charger tes notes.' });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const open = async (note: Note | null) => {
    setMessage(null);
    setConfirmDelete(false);
    setMode('text');
    setDrawingDirty(false);
    setLoadedDrawing(null);
    setDrawing(null);
    if (!note) {
      setSelectedId('new');
      setTitle('');
      setBody('');
      setSubjectId('');
      return;
    }
    setSelectedId(note.id);
    setTitle(note.title);
    setBody(note.body);
    setSubjectId(note.subject_id ?? '');
    if (note.has_drawing) {
      setDrawingLoading(true);
      const saved = await getNoteDrawing(note.id);
      setLoadedDrawing(saved);
      setDrawing(saved);
      setDrawingLoading(false);
    }
  };

  const handleSave = async () => {
    if (!title.trim() && !body.trim() && !drawing) {
      setMessage({ kind: 'error', text: "Écris un titre, une note ou fais un dessin avant d'enregistrer." });
      return;
    }
    if (drawingDirty && drawing && drawing.length > MAX_DRAWING_LENGTH) {
      setMessage({ kind: 'error', text: 'Ton dessin est trop lourd. Efface une partie ou simplifie-le.' });
      return;
    }
    setSaving(true);
    setMessage(null);
    const payload = {
      title: title.trim(),
      body,
      subject_id: subjectId || null,
      // Only send the drawing when it changed, so notes still save if the drawing migration is missing.
      ...(drawingDirty ? { drawing } : {}),
    };
    try {
      if (selectedId === 'new' || selectedId === null) {
        const id = await createNote(payload);
        setSelectedId(id);
      } else {
        await updateNote(selectedId, payload);
      }
      setDrawingDirty(false);
      setLoadedDrawing(drawing);
      await load();
      setMessage({ kind: 'ok', text: 'Note enregistrée.' });
    } catch (error) {
      const text = error instanceof Error && error.message.includes('drawing')
        ? "Le dessin n'a pas pu être enregistré : la mise à jour de la base de données est à faire."
        : 'Enregistrement impossible. Réessaie.';
      setMessage({ kind: 'error', text });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedId || selectedId === 'new') return;
    try {
      await deleteNote(selectedId);
      setSelectedId(null);
      setConfirmDelete(false);
      await load();
    } catch {
      setMessage({ kind: 'error', text: 'Suppression impossible.' });
    }
  };

  return (
    <section className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mon bloc-notes</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Écris ou dessine. Tes notes sont privées : toi seul peux les lire.</p>
        </div>
        <button
          type="button"
          onClick={() => void open(null)}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900"
        >
          <Plus className="h-4 w-4" /> Nouvelle note
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <div>
          {!notes ? (
            <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
          ) : notes.length === 0 ? (
            <p className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
              Aucune note pour le moment.
            </p>
          ) : (
            <ul className="space-y-2">
              {notes.map((note) => (
                <li key={note.id}>
                  <button
                    type="button"
                    onClick={() => void open(note)}
                    aria-current={selectedId === note.id ? 'true' : undefined}
                    className={`w-full rounded-xl border p-3 text-left transition ${
                      selectedId === note.id
                        ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/30'
                        : 'border-slate-200 bg-white hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="block min-w-0 flex-1 truncate text-sm font-semibold">{note.title || 'Sans titre'}</span>
                      {note.has_drawing && <PenLine className="h-3.5 w-3.5 shrink-0 text-slate-400" aria-label="Contient un dessin" />}
                    </span>
                    <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
                      {note.subject_id ? `${getSubjectName(note.subject_id)} · ` : ''}
                      {dateFmt.format(new Date(note.updated_at))}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          {selectedId === null ? (
            <div className="flex flex-col items-center gap-2 py-16 text-center text-slate-500 dark:text-slate-400">
              <FileText className="h-8 w-8" />
              <p className="text-sm">Choisis une note ou crée-en une nouvelle.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                maxLength={120}
                aria-label="Titre de la note"
                placeholder="Titre"
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-lg font-semibold dark:border-slate-700 dark:bg-slate-950"
              />
              <select
                value={subjectId}
                onChange={(event) => setSubjectId(event.target.value)}
                aria-label="Matière de la note"
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm dark:border-slate-700 dark:bg-slate-950 sm:w-60"
              >
                <option value="">Sans matière</option>
                {subjects.map((subject) => (
                  <option key={subject.id} value={subject.id}>{subject.name}</option>
                ))}
              </select>

              <div className="inline-flex rounded-xl bg-slate-100 p-1 dark:bg-slate-800" role="tablist" aria-label="Type de contenu">
                {([['text', 'Texte', Type], ['draw', 'Dessin', PenLine]] as const).map(([value, label, Icon]) => (
                  <button
                    key={value}
                    type="button"
                    role="tab"
                    aria-selected={mode === value}
                    onClick={() => setMode(value)}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold transition ${
                      mode === value ? 'bg-white shadow dark:bg-slate-950' : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Icon className="h-4 w-4" /> {label}
                  </button>
                ))}
              </div>

              {mode === 'text' && (
                <textarea
                  value={body}
                  onChange={(event) => setBody(event.target.value)}
                  maxLength={20000}
                  aria-label="Contenu de la note"
                  placeholder="Écris ici…"
                  className="min-h-[280px] w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-base leading-relaxed dark:border-slate-700 dark:bg-slate-950"
                />
              )}

              {drawingLoading && mode === 'draw' && (
                <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
              )}
              {/* Kept mounted (just hidden) so strokes are not lost when switching to the text tab. */}
              {!drawingLoading && (
                <div hidden={mode !== 'draw'}>
                  <DrawingPad
                    key={`${selectedId}-${loadedDrawing ? 'saved' : 'blank'}`}
                    initial={loadedDrawing}
                    onChange={(dataUrl) => {
                      setDrawing(dataUrl);
                      setDrawingDirty(true);
                    }}
                  />
                </div>
              )}

              {message && (
                <p role={message.kind === 'error' ? 'alert' : 'status'} className={`text-sm ${message.kind === 'error' ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                  {message.text}
                </p>
              )}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={saving}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md disabled:opacity-60"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Enregistrer
                </button>
                {selectedId !== 'new' &&
                  (confirmDelete ? (
                    <span className="inline-flex items-center gap-2 text-sm">
                      Supprimer pour de bon ?
                      <button type="button" onClick={handleDelete} className="font-semibold text-red-600">Oui</button>
                      <button type="button" onClick={() => setConfirmDelete(false)} className="font-semibold text-slate-600 dark:text-slate-300">Non</button>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(true)}
                      className="inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-red-600 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      <Trash2 className="h-4 w-4" /> Supprimer
                    </button>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
