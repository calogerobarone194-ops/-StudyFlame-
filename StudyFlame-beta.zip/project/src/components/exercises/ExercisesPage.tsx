import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { CheckCircle2, Dumbbell, Loader2, Target } from 'lucide-react';
import { getSubjectName, subjects } from '@/data/subjects';
import { listLessons, type Lesson } from '@/lib/lessons';
import { LessonPlayer } from '@/components/lessons/LessonPlayer';
import { useLessonGenerator } from '@/components/lessons/useLessonGenerator';

interface SubjectStat {
  id: string;
  done: number;
  percent: number | null;
}

export function ExercisesPage() {
  const [lessons, setLessons] = useState<Lesson[] | null>(null);
  const [subjectId, setSubjectId] = useState(subjects[0].id);
  const [topic, setTopic] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const [loadError, setLoadError] = useState(false);
  const { generating, error, run } = useLessonGenerator();

  const reload = useCallback(async () => {
    try {
      setLessons(await listLessons());
    } catch {
      setLoadError(true);
      setLessons([]);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const stats = useMemo<SubjectStat[]>(() => {
    const done = (lessons ?? []).filter((lesson) => lesson.status === 'done' && lesson.total > 0);
    return subjects
      .map((subject) => {
        const mine = done.filter((lesson) => lesson.subject_id === subject.id);
        const score = mine.reduce((sum, lesson) => sum + (lesson.score ?? 0), 0);
        const total = mine.reduce((sum, lesson) => sum + lesson.total, 0);
        return { id: subject.id, done: mine.length, percent: total > 0 ? Math.round((score / total) * 100) : null };
      })
      .filter((stat) => stat.done > 0);
  }, [lessons]);

  const weakest = useMemo(
    () => [...stats].filter((stat) => stat.percent !== null && stat.percent < 100).sort((a, b) => a.percent! - b.percent!)[0],
    [stats],
  );

  const start = async (forSubject: string, forTopic: string) => {
    const id = await run(forSubject, forTopic, 'practice');
    if (id) {
      setTopic('');
      setOpenId(id);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!generating) void start(subjectId, topic);
  };

  if (openId) {
    return (
      <LessonPlayer
        lessonId={openId}
        onBack={() => {
          setOpenId(null);
          void reload();
        }}
      />
    );
  }

  const history = (lessons ?? []).filter((lesson) => lesson.status === 'done').slice(0, 10);

  return (
    <section className="space-y-8">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <Dumbbell className="h-6 w-6 text-orange-500" /> Mes exercices
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Entraîne-toi avec une série d'exercices adaptée à ton niveau. Chaque bonne réponse rapporte de l'XP.
        </p>
      </div>

      {weakest && (
        <div className="flex flex-col gap-3 rounded-2xl border border-orange-200 bg-orange-50 p-5 dark:border-orange-900/60 dark:bg-orange-950/30 sm:flex-row sm:items-center sm:justify-between">
          <p className="flex items-start gap-2 text-sm">
            <Target className="mt-0.5 h-4 w-4 shrink-0 text-orange-600" />
            <span>
              <strong>Point à travailler :</strong> {getSubjectName(weakest.id)} ({weakest.percent} % de réussite). Une série pour progresser ?
            </span>
          </p>
          <button
            type="button"
            disabled={generating}
            onClick={() => start(weakest.id, '')}
            className="shrink-0 rounded-xl bg-orange-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-orange-700 disabled:opacity-60"
          >
            M'entraîner en {getSubjectName(weakest.id)}
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid gap-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 sm:grid-cols-[200px_1fr_auto]">
        <select
          value={subjectId}
          onChange={(event) => setSubjectId(event.target.value)}
          aria-label="Matière"
          disabled={generating}
          className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-950"
        >
          {subjects.map((subject) => (
            <option key={subject.id} value={subject.id}>{subject.name}</option>
          ))}
        </select>
        <input
          value={topic}
          onChange={(event) => setTopic(event.target.value)}
          maxLength={120}
          disabled={generating}
          aria-label="Notion à travailler (facultatif)"
          placeholder="Notion à travailler (facultatif)"
          className="rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-950"
        />
        <button
          type="submit"
          disabled={generating}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-3 text-sm font-semibold text-white shadow-md disabled:opacity-60"
        >
          {generating && <Loader2 className="h-4 w-4 animate-spin" />}
          {generating ? 'Création…' : 'Commencer'}
        </button>
        {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400 sm:col-span-3">{error}</p>}
      </form>

      {!lessons ? (
        <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
      ) : (
        <>
          {loadError && <p role="alert" className="text-sm text-red-600 dark:text-red-400">Impossible de charger ton historique.</p>}
          <div>
            <h2 className="text-lg font-bold">Ma réussite par matière</h2>
            {stats.length === 0 ? (
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-400">Termine un exercice pour voir tes résultats ici.</p>
            ) : (
              <ul className="mt-3 grid gap-3 sm:grid-cols-2">
                {stats.map((stat) => (
                  <li key={stat.id} className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                    <div className="flex justify-between text-sm font-semibold">
                      <span>{getSubjectName(stat.id)}</span>
                      <span>{stat.percent} %</span>
                    </div>
                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-orange-500" style={{ width: `${stat.percent ?? 0}%` }} />
                    </div>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{stat.done} exercice{stat.done > 1 ? 's' : ''} terminé{stat.done > 1 ? 's' : ''}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {history.length > 0 && (
            <div>
              <h2 className="text-lg font-bold">Derniers résultats</h2>
              <ul className="mt-3 space-y-2">
                {history.map((lesson) => (
                  <li key={lesson.id}>
                    <button
                      type="button"
                      onClick={() => setOpenId(lesson.id)}
                      className="flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 text-left transition hover:border-slate-400 dark:border-slate-800 dark:bg-slate-900"
                    >
                      <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold">{lesson.title}</span>
                        <span className="block text-xs text-slate-500 dark:text-slate-400">{getSubjectName(lesson.subject_id)}</span>
                      </span>
                      <span className="text-sm font-semibold">{lesson.score} / {lesson.total}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </section>
  );
}
