import { useEffect, type ReactNode } from 'react';
import { Award, Bell, Crown, Dumbbell, FileText, Home, Languages, LifeBuoy, Mail, Settings, Sparkles, Users, X, type LucideIcon } from 'lucide-react';
import { Logo } from '@/components/Logo';

export type SideView =
  | { name: 'accueil' }
  | { name: 'lecons'; subjectId?: string; autostart?: boolean; lessonId?: string }
  | { name: 'cours' }
  | { name: 'premium' }
  | { name: 'messages'; partnerId?: string; partnerName?: string }
  | { name: 'communaute' }
  | { name: 'blocnotes' }
  | { name: 'exercices' }
  | { name: 'langues' }
  | { name: 'concours' }
  | { name: 'notifications' }
  | { name: 'parametres' }
  | { name: 'compte' };

const items: { view: SideView['name']; label: string; icon: LucideIcon }[] = [
  { view: 'accueil', label: 'Accueil', icon: Home },
  { view: 'lecons', label: 'Mes leçons', icon: Sparkles },
  { view: 'communaute', label: 'Communauté', icon: Users },
  { view: 'blocnotes', label: 'Bloc-notes', icon: FileText },
  { view: 'exercices', label: 'Exercices', icon: Dumbbell },
  { view: 'langues', label: 'Langues', icon: Languages },
  { view: 'concours', label: 'Concours', icon: Award },
  { view: 'messages', label: 'Messages', icon: Mail },
  { view: 'premium', label: 'Premium', icon: Crown },
  { view: 'notifications', label: 'Notifications', icon: Bell },
  { view: 'parametres', label: 'Paramètres', icon: Settings },
  { view: 'cours', label: 'Entraide', icon: LifeBuoy },
];

export const sideViewLabels: Record<SideView['name'], string> = Object.fromEntries(
  items.map((item) => [item.view, item.label]),
) as Record<SideView['name'], string>;

interface SideMenuProps {
  view: SideView['name'];
  onSelect: (view: SideView) => void;
  onClose: () => void;
  children?: ReactNode;
}

export function SideMenu({ view, onSelect, onClose }: SideMenuProps) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label="Menu principal">
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm animate-fadeUp" onClick={onClose} />
      <aside className="relative flex h-full w-72 max-w-[85vw] flex-col overflow-y-auto bg-white p-5 shadow-2xl dark:bg-slate-950">
        <div className="flex items-center justify-between">
          <Logo />
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer le menu"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="mt-8 flex flex-1 flex-col gap-1" aria-label="Sections du site">
          {items.map(({ view: itemView, label, icon: Icon }) => (
            <button
              key={itemView}
              type="button"
              onClick={() => onSelect({ name: itemView } as SideView)}
              aria-current={view === itemView ? 'page' : undefined}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-semibold transition ${
                view === itemView
                  ? 'bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-md shadow-orange-500/25'
                  : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="h-[18px] w-[18px]" />
              {label}
            </button>
          ))}
        </nav>

        <p className="mt-6 border-t border-slate-200 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          StudyFlame · Apprendre ensemble
        </p>
      </aside>
    </div>
  );
}

export function HamburgerButton({ onOpen }: { onOpen: () => void }) {
  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label="Ouvrir le menu"
      className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-md shadow-orange-500/25 transition hover:-translate-y-0.5"
    >
      <span className="flex flex-col gap-1.5">
        <span className="block h-0.5 w-5 rounded-full bg-white" />
        <span className="block h-0.5 w-5 rounded-full bg-white" />
        <span className="block h-0.5 w-5 rounded-full bg-white" />
      </span>
    </button>
  );
}
