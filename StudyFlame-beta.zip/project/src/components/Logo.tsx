import { Flame } from 'lucide-react';

interface LogoProps {
  className?: string;
}

export function Logo({ className = '' }: LogoProps) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <span className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-lg shadow-orange-500/30">
        <Flame className="h-5 w-5 text-white" strokeWidth={2.5} />
      </span>
      <span className="text-xl font-bold tracking-tight">
        Study<span className="text-orange-500">Flame</span>
      </span>
      <span className="self-start rounded-md bg-orange-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-orange-700 dark:bg-orange-950 dark:text-orange-300">
        Bêta
      </span>
    </span>
  );
}
