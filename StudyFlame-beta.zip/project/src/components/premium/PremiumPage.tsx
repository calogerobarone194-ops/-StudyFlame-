import { useState } from 'react';
import { Crown, Flame, GraduationCap, Gift } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { plans, premiumFeatures, type PlanKind } from '@/data/plans';

const dateFmt = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

export function PremiumPage({ onOpenPromo }: { onOpenPromo: () => void }) {
  const { profile } = useAuth();
  const [kind, setKind] = useState<PlanKind>('classique');
  const [days, setDays] = useState(30);

  const options = plans[kind].options;
  const selected = options.find((option) => option.days === days) ?? options[0];
  const until = profile?.premium_until ? new Date(profile.premium_until) : null;
  const active = !!until && until > new Date();

  const chooseKind = (next: PlanKind) => {
    setKind(next);
    if (!plans[next].options.some((option) => option.days === days)) setDays(30);
  };

  return (
    <section className="space-y-8">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <Crown className="h-6 w-6 text-amber-500" /> Premium
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Débloque toutes les matières, les quiz illimités et les statistiques détaillées. Tu peux aussi rester en version gratuite.
        </p>
      </div>

      <div
        className={`rounded-2xl border p-5 text-sm ${
          active
            ? 'border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30'
            : 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900'
        }`}
      >
        {active ? (
          <p className="font-semibold">
            Ton Premium est actif jusqu'au {dateFmt.format(until!)}. Tu peux le prolonger avec un code promo.
          </p>
        ) : (
          <p className="font-semibold">Tu utilises la version gratuite (0 € / mois).</p>
        )}
      </div>

      <div className="relative overflow-hidden rounded-3xl bg-slate-900 p-8 text-white shadow-2xl shadow-violet-900/20">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-orange-500/30 blur-3xl" />

        <div className="relative grid max-w-xs grid-cols-2 gap-1 rounded-xl bg-white/10 p-1" role="group" aria-label="Type d'abonnement">
          {(Object.keys(plans) as PlanKind[]).map((key) => (
            <button
              key={key}
              type="button"
              aria-pressed={kind === key}
              onClick={() => chooseKind(key)}
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold transition ${
                kind === key ? 'bg-white text-slate-900' : 'text-slate-200 hover:bg-white/10'
              }`}
            >
              {key === 'etudiant' && <GraduationCap className="h-4 w-4" />}
              {plans[key].label}
            </button>
          ))}
        </div>

        <div className="relative mt-4 flex flex-wrap gap-2" role="group" aria-label="Durée">
          {options.map((option) => (
            <button
              key={option.days}
              type="button"
              aria-pressed={selected.days === option.days}
              onClick={() => setDays(option.days)}
              className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition ${
                selected.days === option.days
                  ? 'border-orange-400 bg-orange-500 text-white'
                  : 'border-white/20 text-slate-200 hover:border-white/50'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        <p className="relative mt-6 flex items-baseline gap-2">
          <span className="text-5xl font-extrabold">{selected.price}</span>
          <span className="text-slate-300">/ {selected.label}</span>
        </p>
        <p className="relative mt-3 text-sm text-slate-300">
          {kind === 'etudiant' ? 'Tarif réduit réservé aux étudiants.' : 'Accès complet pendant la durée choisie.'}
        </p>

        <ul className="relative mt-6 space-y-3">
          {premiumFeatures.map((feature) => (
            <li key={feature} className="flex gap-3 text-sm text-slate-100">
              <Flame className="mt-0.5 h-4 w-4 shrink-0 text-orange-400" />
              {feature}
            </li>
          ))}
        </ul>

        <div className="relative mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          <button
            type="button"
            onClick={onOpenPromo}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-orange-500 px-6 py-3.5 font-semibold text-white shadow-lg transition hover:-translate-y-0.5"
          >
            <Gift className="h-4 w-4" /> J'ai un code promo
          </button>
          <p className="text-xs text-slate-300">Le paiement en ligne n'est pas encore disponible : pour l'instant, Premium s'active avec un code.</p>
        </div>
      </div>
    </section>
  );
}
