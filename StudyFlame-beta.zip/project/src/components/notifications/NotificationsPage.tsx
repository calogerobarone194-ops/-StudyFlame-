import { useCallback, useEffect, useState } from 'react';
import { Bell, CheckCheck, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export interface AppNotification {
  id: string;
  type: 'comment' | 'reply' | 'like' | 'message' | 'interaction';
  actor_name: string;
  body: string;
  link_view: string;
  is_read: boolean;
  created_at: string;
}

const typeLabels: Record<AppNotification['type'], string> = {
  comment: 'a commenté votre publication',
  reply: 'a répondu à votre commentaire',
  like: "a aimé votre publication",
  message: 'vous a envoyé un message',
  interaction: 'a interagi avec votre contenu',
};

const dateFmt = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export function NotificationsPage({ onOpenView }: { onOpenView: (view: string) => void }) {
  const [notifications, setNotifications] = useState<AppNotification[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [marking, setMarking] = useState(false);

  const load = useCallback(() => {
    setLoadError(null);
    supabase
      .from('notifications')
      .select('id, type, actor_name, body, link_view, is_read, created_at')
      .order('created_at', { ascending: false })
      .limit(50)
      .then(({ data, error }) => {
        if (error) setLoadError('Impossible de charger vos notifications.');
        else setNotifications((data ?? []) as AppNotification[]);
      });
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const markAllRead = async () => {
    setMarking(true);
    try {
      await supabase.from('notifications').update({ is_read: true }).eq('is_read', false);
      setNotifications((previous) => previous?.map((item) => ({ ...item, is_read: true })) ?? null);
    } finally {
      setMarking(false);
    }
  };

  const unreadCount = notifications?.filter((item) => !item.is_read).length ?? 0;

  return (
    <section className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {unreadCount === 0 ? 'Tout est à jour.' : `${unreadCount} non lue${unreadCount > 1 ? 's' : ''}.`}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            type="button"
            onClick={markAllRead}
            disabled={marking}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
          >
            {marking ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCheck className="h-4 w-4" />}
            Tout marquer comme lu
          </button>
        )}
      </div>

      {loadError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{loadError}</p>
      )}

      {!notifications && !loadError && (
        <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-slate-500" /></div>
      )}

      {notifications && notifications.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <Bell className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-3 font-semibold">Aucune notification</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Les interactions avec vos publications apparaîtront ici.</p>
        </div>
      )}

      {notifications && notifications.length > 0 && (
        <ul className="space-y-2">
          {notifications.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onOpenView(item.link_view)}
                className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition hover:shadow-md ${
                  item.is_read
                    ? 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900'
                    : 'border-orange-200 bg-orange-50/70 dark:border-orange-900 dark:bg-orange-950/40'
                }`}
              >
                <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${item.is_read ? 'bg-slate-300 dark:bg-slate-600' : 'bg-orange-500'}`} />
                <span className="min-w-0 flex-1">
                  <span className="block text-sm text-slate-800 dark:text-slate-200">
                    <span className="font-semibold">{item.actor_name || 'Quelqu\'un'}</span> {typeLabels[item.type]}
                  </span>
                  {item.body && <span className="mt-0.5 block truncate text-sm text-slate-600 dark:text-slate-400">{item.body}</span>}
                  <span className="mt-1 block text-xs text-slate-500 dark:text-slate-500">{dateFmt.format(new Date(item.created_at))}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
