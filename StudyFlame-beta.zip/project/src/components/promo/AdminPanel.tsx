import { useCallback, useEffect, useState } from 'react';
import { Archive, ArchiveRestore, ChevronDown, Loader2, Plus, Trash2, X } from 'lucide-react';
import {
  createPromoCode,
  deletePromoCode,
  isAdmin,
  listPromoCodes,
  listRedemptions,
  randomPromoCode,
  setActivePromoCode,
  type PromoCodeWithStats,
  type PromoRedemption,
} from '@/lib/promoCodes';

const monthOptions = [1, 3, 6, 12];

const monthLabels: Record<number, string> = {
  1: '1 mois de Premium',
  3: '3 mois de Premium',
  6: '6 mois de Premium',
  12: '12 mois de Premium',
};

export function AdminPanel() {
  const [codes, setCodes] = useState<PromoCodeWithStats[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [redemptions, setRedemptions] = useState<PromoRedemption[]>([]);
  const [loadingRedemptions, setLoadingRedemptions] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const reload = useCallback(() => {
    setLoadError(null);
    listPromoCodes()
      .then(setCodes)
      .catch((err) => setLoadError(err instanceof Error ? err.message : 'Chargement impossible.'));
  }, []);

  useEffect(() => {
    isAdmin().then((admin) => {
      if (!admin) {
        setLoadError("Cette section est réservée à l'administrateur.");
        setCodes([]);
        return;
      }
      reload();
    });
  }, [reload]);

  const toggleExpanded = async (codeId: string) => {
    if (expanded === codeId) {
      setExpanded(null);
      return;
    }
    setExpanded(codeId);
    setLoadingRedemptions(true);
    try {
      setRedemptions(await listRedemptions(codeId));
    } catch {
      setRedemptions([]);
    } finally {
      setLoadingRedemptions(false);
    }
  };

  const handleSetActive = async (id: string, active: boolean) => {
    setActionError(null);
    try {
      await setActivePromoCode(id, active);
      setCodes((previous) => previous?.map((code) => (code.id === id ? { ...code, active } : code)) ?? null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Modification impossible.');
    }
  };

  const handleDelete = async (id: string) => {
    setActionError(null);
    try {
      await deletePromoCode(id);
      setConfirmDelete(null);
      setCodes((previous) => previous?.filter((code) => code.id !== id) ?? null);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Suppression impossible.');
    }
  };

  if (loadError) {
    return <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{loadError}</p>;
  }

  if (!codes) {
    return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-slate-500" /></div>;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Administration</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Codes promotionnels et suivi des utilisations.</p>
        </div>
        <button
          type="button"
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
        >
          <Plus className="h-4 w-4" /> Créer un code
        </button>
      </div>

      {actionError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{actionError}</p>
      )}

      {codes.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <p className="font-semibold">Aucun code pour le moment</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Créez votre premier code promotionnel.</p>
        </div>
      )}

      <ul className="space-y-3">
        {codes.map((code) => (
          <li key={code.id} className="rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center gap-3 p-5">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-lg bg-slate-100 px-2.5 py-1 font-mono text-sm font-bold tracking-widest text-slate-900 dark:bg-slate-800 dark:text-white">{code.code}</span>
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${code.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'}`}>
                    {code.active ? 'Actif' : 'Désactivé'}
                  </span>
                  {code.organization_name && (
                    <span className="rounded-full bg-sky-100 px-2.5 py-0.5 text-xs font-semibold text-sky-700 dark:bg-sky-950 dark:text-sky-300">{code.organization_name}</span>
                  )}
                </div>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{monthLabels[code.months_granted]}</p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-500">
                  {code.uses} utilisation{code.uses > 1 ? 's' : ''}{code.max_uses ? ` sur ${code.max_uses}` : ''}
                  {code.expires_at ? ` · expire le ${new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium' }).format(new Date(code.expires_at))}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button type="button" onClick={() => handleSetActive(code.id, !code.active)} className="rounded-lg p-2.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white" title={code.active ? 'Désactiver' : 'Réactiver'}>
                  {code.active ? <Archive className="h-4 w-4" /> : <ArchiveRestore className="h-4 w-4" />}
                </button>
                {confirmDelete === code.id ? (
                  <span className="flex items-center gap-1">
                    <button type="button" onClick={() => handleDelete(code.id)} className="rounded-lg bg-red-600 px-3 py-1.5 text-sm font-semibold text-white hover:bg-red-700">Confirmer</button>
                    <button type="button" onClick={() => setConfirmDelete(null)} className="rounded-lg px-2 py-1.5 text-sm text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">Annuler</button>
                    <X className="hidden" />
                  </span>
                ) : (
                  <button type="button" onClick={() => setConfirmDelete(code.id)} className="rounded-lg p-2.5 text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/60 dark:hover:text-red-400" title="Supprimer">
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
                <button type="button" onClick={() => toggleExpanded(code.id)} aria-expanded={expanded === code.id} className="rounded-lg p-2.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white" title="Voir les utilisations">
                  <ChevronDown className={`h-4 w-4 transition ${expanded === code.id ? 'rotate-180' : ''}`} />
                </button>
              </div>
            </div>

            {expanded === code.id && (
              <div className="border-t border-slate-200 p-5 dark:border-slate-800">
                {loadingRedemptions ? (
                  <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-slate-500" /></div>
                ) : redemptions.length === 0 ? (
                  <p className="text-sm text-slate-600 dark:text-slate-400">Aucune utilisation pour le moment.</p>
                ) : (
                  <ul className="space-y-2">
                    {redemptions.map((redemption) => (
                      <li key={redemption.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-4 py-3 text-sm dark:bg-slate-800">
                        <span className="font-medium text-slate-900 dark:text-slate-100">{redemption.profiles?.display_name ?? 'Compte supprimé'}</span>
                        <span className="text-slate-500 dark:text-slate-400">
                          {new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(redemption.created_at))}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </li>
        ))}
      </ul>

      {creating && (
        <CreateCodeDialog
          onClose={() => setCreating(false)}
          onCreated={() => {
            setCreating(false);
            reload();
          }}
        />
      )}
    </div>
  );
}

function CreateCodeDialog({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [code, setCode] = useState('');
  const [label, setLabel] = useState('');
  const [months, setMonths] = useState(1);
  const [organization, setOrganization] = useState('');
  const [unlimited, setUnlimited] = useState(true);
  const [maxUses, setMaxUses] = useState(100);
  const [noExpiry, setNoExpiry] = useState(true);
  const [expiresAt, setExpiresAt] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (code.trim().length < 4) return setError('Le code doit contenir au moins 4 caractères.');
    if (!label.trim()) return setError("Donnez un nom à l'offre, par exemple « Offre de lancement ».");

    setError(null);
    setSaving(true);
    try {
      await createPromoCode({
        code: code.trim().toUpperCase(),
        label: label.trim(),
        months,
        organization: organization.trim(),
        maxUses: unlimited ? null : maxUses,
        expiresAt: noExpiry || !expiresAt ? null : new Date(`${expiresAt}T23:59:59`).toISOString(),
      });
      onCreated();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Création impossible.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm animate-fadeUp" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="create-code-title"
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="create-code-title" className="text-xl font-bold">Nouveau code promo</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Définissez l'avantage et ses limites.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Fermer" className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-900 dark:hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Code</span>
            <div className="flex gap-2">
              <input
                className="flex-1 rounded-xl border border-slate-300 bg-white px-4 py-3 font-mono text-lg font-semibold uppercase tracking-widest text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                value={code}
                maxLength={40}
                placeholder="STUDYFLAME2026"
                onChange={(e) => setCode(e.target.value.toUpperCase())}
              />
              <button
                type="button"
                onClick={() => setCode(randomPromoCode())}
                className="shrink-0 rounded-xl border border-slate-300 px-4 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-900"
              >
                Générer
              </button>
            </div>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Nom de l'offre</span>
            <input
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              value={label}
              maxLength={80}
              placeholder="Offre de lancement, École partenaire…"
              onChange={(e) => setLabel(e.target.value)}
            />
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Avantage</span>
            <select
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              value={months}
              onChange={(e) => setMonths(Number(e.target.value))}
            >
              {monthOptions.map((option) => (
                <option key={option} value={option}>{monthLabels[option]}</option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">École ou partenaire (facultatif)</span>
            <input
              className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              value={organization}
              maxLength={120}
              placeholder="Collège Victor Hugo"
              onChange={(e) => setOrganization(e.target.value)}
            />
          </label>

          <fieldset className="space-y-2">
            <legend className="text-sm font-medium text-slate-700 dark:text-slate-300">Nombre d'utilisations</legend>
            <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input type="checkbox" checked={unlimited} onChange={(e) => setUnlimited(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
              Illimité
            </label>
            {!unlimited && (
              <input
                type="number"
                min={1}
                max={100000}
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                value={maxUses}
                onChange={(e) => setMaxUses(Number(e.target.value))}
              />
            )}
          </fieldset>

          <fieldset className="space-y-2">
            <legend className="text-sm font-medium text-slate-700 dark:text-slate-300">Date d'expiration</legend>
            <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input type="checkbox" checked={noExpiry} onChange={(e) => setNoExpiry(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
              Sans expiration
            </label>
            {!noExpiry && (
              <input
                type="date"
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
              />
            )}
          </fieldset>

          {error && (
            <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{error}</p>
          )}

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 rounded-xl border border-slate-300 py-3 font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-900">
              Annuler
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Créer le code
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
