import { useEffect, useState, type FormEvent } from 'react';
import { Gift, Loader2, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { promoErrorMessage, redeemPromoCode } from '@/lib/promoCodes';

interface PromoDialogProps {
  onClose: () => void;
}

export function PromoDialog({ onClose }: PromoDialogProps) {
  const { refreshProfile } = useAuth();
  const [code, setCode] = useState('');
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const premiumUntil = await redeemPromoCode(code);
      await refreshProfile();
      const date = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(premiumUntil));
      setSuccess(`Bravo ! Votre Premium est activé jusqu'au ${date}.`);
    } catch (err) {
      setError(promoErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm animate-fadeUp" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="promo-dialog-title"
        className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-md">
              <Gift className="h-5 w-5 text-white" />
            </span>
            <div>
              <h2 id="promo-dialog-title" className="text-xl font-bold">Code promo</h2>
              <p className="text-sm text-slate-600 dark:text-slate-400">Saisissez le code que vous avez reçu.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {success ? (
          <div className="mt-6 space-y-6">
            <p className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-300">
              {success}
            </p>
            <button
              type="button"
              onClick={onClose}
              className="w-full rounded-xl bg-slate-900 py-3 font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
            >
              C'est noté
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
            <label className="block">
              <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Votre code</span>
              <input
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-lg font-semibold uppercase tracking-widest text-slate-900 transition focus:border-orange-500 focus:outline-none focus:ring-4 focus:ring-orange-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                value={code}
                maxLength={40}
                placeholder="EXEMPLE2026"
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                autoFocus
              />
            </label>

            {error && (
              <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 py-3 font-semibold text-white shadow-lg shadow-orange-600/25 transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              Utiliser mon code
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
