import { Star } from 'lucide-react';
import { useFavorites } from '@/context/FavoritesContext';
import type { FavoriteType } from '@/lib/favorites';

interface FavoriteButtonProps {
  type: FavoriteType;
  id: string;
  label: string;
  className?: string;
}

export function FavoriteButton({ type, id, label, className = '' }: FavoriteButtonProps) {
  const { isFavorite, toggle } = useFavorites();
  const active = isFavorite(type, id);
  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={active ? `Retirer ${label} des favoris` : `Ajouter ${label} aux favoris`}
      title={active ? 'Retirer des favoris' : 'Ajouter aux favoris'}
      onClick={() => void toggle(type, id)}
      className={`rounded-lg p-2 transition hover:bg-slate-100 dark:hover:bg-slate-800 ${active ? 'text-amber-500' : 'text-slate-400 hover:text-amber-500'} ${className}`}
    >
      <Star className={`h-5 w-5 ${active ? 'fill-current' : ''}`} />
    </button>
  );
}
