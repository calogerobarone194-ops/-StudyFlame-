
import { useState } from 'react';
import { Check, ChevronDown, Flame, GraduationCap } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { plans, premiumFeatures, type PlanKind } from '@/data/plans';


interface PricingFaqFooterProps {
  onStart: () => void;
}

const freeFeatures = [
  'Accès aux leçons de base de chaque matière',
  'Flammes quotidiennes et XP',
  'Quiz de révision hebdomadaires',
];


const faqs = [
  {
    question: 'StudyFlame est-il gratuit ?',
    answer: 'Oui. La version gratuite donne accès aux leçons de base et au système de flammes. Premium débloque l\'ensemble du contenu.',
  },
  {
    question: 'Quels niveaux sont couverts ?',
    answer: 'De P1 à P6 pour le primaire, puis de S1 à S6 pour le secondaire.',
  },
  {
    question: 'Mes données sont-elles protégées ?',
    answer: 'Vos données de progression sont stockées de façon sécurisée et ne sont accessibles qu\'à votre compte. Les élèves mineurs doivent disposer de l\'accord d\'un parent ou d\'un représentant légal.',
  },
  {
    question: 'Quelles sont les durées d\'abonnement Premium ?',
    answer: 'Vous choisissez une durée d\'accès : 1, 7, 30, 90 ou 365 jours. Les étudiants bénéficient d\'un tarif réduit pour 30, 90 ou 365 jours.',
  },
];

export function PricingFaqFooter({ onStart }: PricingFaqFooterProps) {
  const [kind, setKind] = useState<PlanKind>('classique');
  const [days, setDays] = useState(30);
  const options = plans[kind].options;
  const selected = options.find((option) => option.days === days) ?? options[0];

  const chooseKind = (next: PlanKind) => {
    setKind(next);
    // Keep the same duration when it exists for the new plan, otherwise fall back to 30 days.
    if (!plans[next].options.some((option) => option.days === days)) setDays(30);
  };

  return (
    <>
      <section id="tarifs" className="py-20">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-violet-600 dark:text-violet-400">
              Tarifs
            </p>
            <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
              Commencez gratuitement, passez à Premium quand vous voulez
            </h2>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-2">
            {/* Offre gratuite */}
            <div className="flex flex-col rounded-3xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-950">
              <p className="text-lg font-semibold">Gratuit</p>

              <p className="mt-4 flex items-baseline gap-1">
                <span className="text-5xl font-extrabold">0 €</span>
                <span className="text-slate-500 dark:text-slate-400">/ mois</span>
              </p>

              <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                Pour découvrir la plateforme et prendre le rythme.
              </p>

              <ul className="mt-8 flex-1 space-y-3">
                {freeFeatures.map((feature) => (
                  <li key={feature} className="flex gap-3 text-sm text-slate-700 dark:text-slate-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={onStart}
                className="mt-8 rounded-xl border border-slate-300 py-3.5 font-semibold text-slate-800 transition hover:-translate-y-0.5 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-100 dark:hover:bg-slate-900"
              >
                Commencer gratuitement
              </button>
            </div>

            {/* Offre Premium */}
            <div className="relative flex flex-col overflow-hidden rounded-3xl bg-slate-900 p-8 text-white shadow-2xl shadow-violet-900/20 dark:bg-slate-900">
              <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-orange-500/30 blur-3xl" />

              <div className="relative flex items-center justify-between">
                <p className="text-lg font-semibold">Premium</p>
                <span className="rounded-full bg-orange-500 px-3 py-1 text-xs font-bold uppercase tracking-wide">
                  Recommandé
                </span>
              </div>

              <div className="relative mt-5 grid grid-cols-2 gap-1 rounded-xl bg-white/10 p-1" role="group" aria-label="Type d'abonnement">
                {(Object.keys(plans) as PlanKind[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={kind === key}
                    onClick={() => chooseKind(key)}
                    className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold transition ${
                      kind === key ? 'bg-white text-slate-900' : 'text-slate-200 hover:bg-white/10'
                    }`}
                  >
                    {key === 'etudiant' && <GraduationCap className="h-4 w-4" />}
                    {plans[key].label}
                  </button>
                ))}
              </div>

              <div className="relative mt-3 flex flex-wrap gap-2" role="group" aria-label="Durée">
                {options.map((option) => (
                  <button
                    key={option.days}
                    type="button"
                    aria-pressed={selected.days === option.days}
                    onClick={() => setDays(option.days)}
                    className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition ${
                      selected.days === option.days
                        ? 'border-orange-400 bg-orange-500 text-white'
                        : 'border-white/20 text-slate-200 hover:border-white/50'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              <p className="relative mt-6 flex items-baseline gap-2">
                <span className="text-5xl font-extrabold">{selected.price}</span>
                <span className="text-slate-300">/ {selected.label}</span>
              </p>

              <p className="relative mt-3 text-sm leading-relaxed text-slate-300">
                {kind === 'etudiant'
                  ? 'Tarif réduit réservé aux étudiants, avec toutes les ressources.'
                  : 'Pour réussir vos examens avec toutes les ressources.'}
              </p>

              <ul className="relative mt-8 flex-1 space-y-3">
                {premiumFeatures.map((feature) => (
                  <li key={feature} className="flex gap-3 text-sm text-slate-100">
                    <Flame className="mt-0.5 h-4 w-4 shrink-0 text-orange-400" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                type="button"
                onClick={onStart}
                className="relative mt-8 rounded-xl bg-gradient-to-r from-violet-600 to-orange-500 py-3.5 font-semibold text-white shadow-lg transition hover:-translate-y-0.5 hover:shadow-xl"
              >
                Choisir Premium · {selected.label}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Questions fréquentes */}
      <section
        id="faq"
        className="border-t border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40"
      >
        <div className="mx-auto max-w-3xl px-6">
          <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">
            Questions fréquentes
          </h2>

          <div className="mt-12 space-y-3">
            {faqs.map((faq) => (
              <details
                key={faq.question}
                className="group rounded-2xl border border-slate-200 bg-white px-6 py-5 open:shadow-md dark:border-slate-800 dark:bg-slate-950"
              >
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold">
                  {faq.question}
                  <ChevronDown className="h-5 w-5 shrink-0 text-slate-500 transition group-open:rotate-180" />
                </summary>

                <p className="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Pied de page */}
      <footer className="border-t border-slate-200 bg-white py-12 dark:border-slate-800 dark:bg-slate-950">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 md:grid-cols-[1fr_auto]">
          <div>
            <Logo />
            <p className="mt-4 max-w-md text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Chaque jour, une étape de plus vers la réussite. StudyFlame accompagne les élèves de P1 à S6.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-x-12 gap-y-3 text-sm text-slate-600 dark:text-slate-400">
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#mentions-legales">
              Mentions légales
            </a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#conditions">
              Conditions d'utilisation
            </a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#confidentialite">
              Confidentialité
            </a>
            <a className="transition hover:text-slate-900 dark:hover:text-white" href="#faq">
              Questions fréquentes
            </a>
          </div>
        </div>

        <div className="mx-auto mt-10 max-w-6xl space-y-6 border-t border-slate-200 px-6 pt-8 text-xs leading-relaxed text-slate-500 dark:border-slate-800 dark:text-slate-500">
          <p id="mentions-legales">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Mentions légales.
            </span>
            {' '}StudyFlame est un service éducatif en ligne. Les informations légales complètes (éditeur, hébergeur, contact) seront publiées ici avant l'ouverture commerciale.
          </p>

          <p id="conditions">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Conditions d'utilisation.
            </span>
            {' '}En créant un compte, vous acceptez d'utiliser StudyFlame à des fins personnelles et éducatives. Les élèves mineurs doivent obtenir l'accord d'un parent ou d'un représentant légal.
          </p>

          <p id="confidentialite">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Confidentialité.
            </span>
            {' '}Seules les données nécessaires au fonctionnement du compte et au suivi de la progression sont conservées.
          </p>

          <p>© {new Date().getFullYear()} StudyFlame, version bêta. Tous droits réservés.</p>
        </div>
      </footer>
    </>
  );
}
