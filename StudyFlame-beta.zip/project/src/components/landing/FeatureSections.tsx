import { Brain, CheckCircle2, Flame, Gauge, Target, Timer } from 'lucide-react';
import { subjects } from '@/data/subjects';

interface FeatureSectionsProps {
  onStart: () => void;
}

const flameSteps = [
  { day: 'Jour 1', text: 'Terminez une leçon pour allumer votre flamme.' },
  { day: 'Jour 2', text: 'Revenez le lendemain pour la faire grandir.' },
  { day: 'Jour 3', text: 'Gardez la série et débloquez de nouveaux badges.' },
];

const quizHighlights = [
  { icon: Timer, title: 'Quiz chronométrés', text: 'Entraînez-vous dans les conditions de l\'examen.' },
  { icon: Brain, title: 'Mémorisation active', text: 'Des rappels intelligents pour retenir durablement.' },
  { icon: Target, title: 'Correction immédiate', text: 'Une explication claire après chaque réponse.' },
  { icon: Gauge, title: 'Suivi des progrès', text: 'Visualisez vos points forts et vos axes d\'amélioration.' },
];

export function FeatureSections({ onStart }: FeatureSectionsProps) {
  return (
    <>
      <section id="matieres" className="border-t border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-violet-600 dark:text-violet-400">Matières</p>
            <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
              Toutes les matières clés, organisées par thème
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-slate-600 dark:text-slate-400">
              Des parcours structurés du primaire au secondaire, avec des leçons courtes à votre rythme.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {subjects.map((subject) => {
              const Icon = subject.icon;
              return (
                <article
                  key={subject.id}
                  className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-slate-800 dark:bg-slate-950"
                >
                  <span className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${subject.accent} shadow-lg`}>
                    <Icon className="h-6 w-6 text-white" />
                  </span>
                  <p className="mt-5 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">{subject.category}</p>
                  <h3 className="mt-1 text-xl font-semibold">{subject.name}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{subject.description}</p>
                  <p className="mt-4 text-sm font-medium text-slate-700 dark:text-slate-300">{subject.lessons} leçons</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section id="flammes" className="py-20">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-6 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">Système de flammes</p>
            <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
              Une série qui motive, jour après jour
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-slate-600 dark:text-slate-400">
              Chaque jour d'étude allume votre flamme. Plus votre série est longue, plus elle brille, et plus vous gagnez d'XP.
            </p>
            <ol className="mt-8 space-y-5">
              {flameSteps.map((step) => (
                <li key={step.day} className="flex gap-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-orange-100 text-orange-600 dark:bg-orange-950 dark:text-orange-400">
                    <Flame className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-semibold">{step.day}</p>
                    <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-400">{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>
            <button
              type="button"
              onClick={onStart}
              className="mt-10 inline-flex items-center justify-center rounded-xl bg-orange-500 px-6 py-3.5 font-semibold text-white shadow-lg shadow-orange-500/25 transition hover:-translate-y-0.5 hover:bg-orange-600"
            >
              Allumer ma première flamme
            </button>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="absolute h-72 w-72 rounded-full bg-orange-500/20 blur-3xl" />
            <div className="relative w-full max-w-sm rounded-3xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-col items-center text-center">
                <Flame className="h-24 w-24 animate-flicker text-orange-500 drop-shadow-[0_0_24px_rgba(249,115,22,0.6)]" strokeWidth={1.75} />
                <p className="mt-4 text-5xl font-extrabold tabular-nums">7</p>
                <p className="mt-1 text-sm font-medium text-slate-600 dark:text-slate-400">jours d'affilée</p>
              </div>
              <div className="mt-8 grid grid-cols-7 gap-2">
                {Array.from({ length: 7 }, (_, index) => (
                  <span
                    key={index}
                    className="h-2 rounded-full bg-gradient-to-r from-orange-400 to-orange-600"
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="quiz" className="border-t border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto max-w-6xl px-6">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-sky-600 dark:text-sky-400">Quiz</p>
            <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
              Testez vos connaissances avant l'examen
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-slate-600 dark:text-slate-400">
              Des quiz courts pour vérifier ce que vous avez appris et repérer ce qu'il reste à revoir.
            </p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {quizHighlights.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="rounded-2xl border border-slate-200 bg-white p-6 transition hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-950"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-100 text-sky-600 dark:bg-sky-950 dark:text-sky-400">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-5 font-semibold">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{item.text}</p>
                  <CheckCircle2 className="mt-4 h-4 w-4 text-emerald-500" />
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}
