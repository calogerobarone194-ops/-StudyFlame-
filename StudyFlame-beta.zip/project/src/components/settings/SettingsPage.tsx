import { useEffect, useState, type FormEvent } from 'react';
import { Camera, Check, FlaskConical, Loader2, LogOut, Star, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useTheme, type ThemeMode } from '@/hooks/useTheme';
import { useAccent } from '@/hooks/useAccent';
import { accents, palettes } from '@/data/accents';
import { getSubjectName, subjects } from '@/data/subjects';
import { useFavorites } from '@/context/FavoritesContext';
import { listLessons, type Lesson } from '@/lib/lessons';
import { sendFeedback } from '@/lib/feedback';
import {
  blockUser,
  changeEmail,
  changePassword,
  deleteOwnAccount,
  getAvatarUrl,
  getSettings,
  listBlocked,
  listSignInHistory,
  settingsErrorMessage,
  unblockUser,
  updateSettings,
  uploadAvatar,
  saveAvatarPath,
  type BlockedAccount,
  type SignInEntry,
} from '@/lib/accountSettings';

const sectionClass = 'rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900';
const inputClass =
  'w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100';
const buttonClass =
  'inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100';

const themeOptions: { value: ThemeMode; label: string }[] = [
  { value: 'light', label: 'Clair' },
  { value: 'dark', label: 'Sombre' },
  { value: 'auto', label: 'Automatique (appareil)' },
];

interface SettingsPageProps {
  onOpenSubject?: (subjectId: string) => void;
  onOpenLesson?: (lessonId: string) => void;
}

export function SettingsPage({ onOpenSubject, onOpenLesson }: SettingsPageProps = {}) {
  const { user, profile, updateProfile, refreshProfile, signOut } = useAuth();
  const { mode, setThemeMode } = useTheme();
  const { accentId, setAccent } = useAccent();
  const { favorites, toggle: toggleFavorite, error: favoritesError } = useFavorites();
  const [favoriteLessons, setFavoriteLessons] = useState<Lesson[]>([]);
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackBusy, setFeedbackBusy] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ ok: boolean; text: string } | null>(null);

  const handleFeedback = async (event: FormEvent) => {
    event.preventDefault();
    if (!feedbackText.trim()) return;
    setFeedbackBusy(true);
    setFeedbackMessage(null);
    try {
      await sendFeedback(feedbackText, 'parametres');
      setFeedbackText('');
      setFeedbackMessage({ ok: true, text: 'Merci ! Ton message a bien été envoyé.' });
    } catch {
      setFeedbackMessage({ ok: false, text: "Envoi impossible pour l'instant. Réessaie plus tard." });
    } finally {
      setFeedbackBusy(false);
    }
  };

  useEffect(() => {
    if (!favorites.some((item) => item.item_type === 'lesson')) {
      setFavoriteLessons([]);
      return;
    }
    let active = true;
    listLessons()
      .then((data) => active && setFavoriteLessons(data))
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [favorites]);

  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [notifyComments, setNotifyComments] = useState(true);
  const [notifyLikes, setNotifyLikes] = useState(true);
  const [notifyMessages, setNotifyMessages] = useState(true);
  const [isPrivate, setIsPrivate] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [savingName, setSavingName] = useState(false);
  const [nameMessage, setNameMessage] = useState<string | null>(null);

  const [password, setPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);

  const [email, setEmail] = useState('');
  const [savingEmail, setSavingEmail] = useState(false);
  const [emailMessage, setEmailMessage] = useState<string | null>(null);

  const [blocked, setBlocked] = useState<BlockedAccount[]>([]);
  const [history, setHistory] = useState<SignInEntry[]>([]);
  const [blockError, setBlockError] = useState<string | null>(null);

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const data = await getSettings();
        if (!active) return;
        setNotifyComments(data.notify_comments ?? true);
        setNotifyLikes(data.notify_likes ?? true);
        setNotifyMessages(data.notify_messages ?? true);
        setIsPrivate(data.is_private_profile ?? false);
        if (data.avatar_path) {
          getAvatarUrl(data.avatar_path).then((url) => active && setAvatarUrl(url));
        }
      } catch {
        if (active) setLoaded(true);
      } finally {
        if (active) setLoaded(true);
      }

      try {
        const [blockedResult, historyResult] = await Promise.all([listBlocked(), listSignInHistory()]);
        if (!active) return;
        setBlocked(blockedResult);
        setHistory(historyResult);
      } catch {
        if (active) setBlockError('Impossible de charger vos listes pour le moment.');
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleAvatarChange = async (file: File | null) => {
    if (!file) return;
    try {
      const path = await uploadAvatar(file);
      await saveAvatarPath(path);
      await refreshProfile();
      setAvatarUrl(await getAvatarUrl(path));
    } catch (err) {
      setBlockError(settingsErrorMessage(err));
    }
  };

  const handleSaveName = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = displayName.trim();
    if (!trimmed) return setNameMessage('Le pseudo ne peut pas être vide.');
    setSavingName(true);
    setNameMessage(null);
    try {
      await updateSettings({});
      await updateProfile({ display_name: trimmed, level: profile?.level ?? 'S1', objective: profile?.objective ?? 'Progresser régulièrement' });
      setNameMessage('Pseudo enregistré.');
    } catch (err) {
      setNameMessage(settingsErrorMessage(err));
    } finally {
      setSavingName(false);
    }
  };

  const handleSavePassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password.length < 6) return setPasswordMessage('Le mot de passe doit contenir au moins 6 caractères.');
    setSavingPassword(true);
    setPasswordMessage(null);
    try {
      await changePassword(password);
      setPassword('');
      setPasswordMessage('Mot de passe modifié.');
    } catch (err) {
      setPasswordMessage(settingsErrorMessage(err));
    } finally {
      setSavingPassword(false);
    }
  };

  const handleSaveEmail = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!email.includes('@')) return setEmailMessage('Saisissez une adresse e-mail valide.');
    setSavingEmail(true);
    setEmailMessage(null);
    try {
      await changeEmail(email.trim());
      setEmailMessage('Un e-mail de confirmation vous a été envoyé pour valider la nouvelle adresse.');
    } catch (err) {
      setEmailMessage(settingsErrorMessage(err));
    } finally {
      setSavingEmail(false);
    }
  };

  const handleNotificationToggle = async (key: 'notify_comments' | 'notify_likes' | 'notify_messages', value: boolean) => {
    if (key === 'notify_comments') setNotifyComments(value);
    if (key === 'notify_likes') setNotifyLikes(value);
    if (key === 'notify_messages') setNotifyMessages(value);
    try {
      await updateSettings({ [key]: value });
    } catch (err) {
      setBlockError(settingsErrorMessage(err));
    }
  };

  const handlePrivacyToggle = async (value: boolean) => {
    setIsPrivate(value);
    try {
      await updateSettings({ is_private_profile: value });
    } catch (err) {
      setBlockError(settingsErrorMessage(err));
    }
  };

  const handleUnblock = async (blockId: string) => {
    try {
      await unblockUser(blockId);
      setBlocked((previous) => previous.filter((entry) => entry.id !== blockId));
    } catch (err) {
      setBlockError(settingsErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    setDeleteError(null);
    try {
      await deleteOwnAccount();
      await signOut();
    } catch (err) {
      setDeleteError(settingsErrorMessage(err));
    }
  };

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Paramètres</h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Votre compte, votre apparence, votre vie privée.</p>
      </div>

      {blockError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{blockError}</p>
      )}

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Photo de profil</h3>
        <div className="mt-4 flex items-center gap-4">
          {avatarUrl ? (
            <img src={avatarUrl} alt="Votre photo de profil" className="h-16 w-16 rounded-full border border-slate-200 object-cover dark:border-slate-700" />
          ) : (
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-sky-500 to-blue-600 text-xl font-bold text-white">
              {(profile?.display_name ?? '?').charAt(0).toUpperCase()}
            </span>
          )}
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-950">
            <Camera className="h-4 w-4" /> Changer de photo
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => handleAvatarChange(e.target.files?.[0] ?? null)} />
          </label>
        </div>
      </div>

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Apparence</h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Votre choix est mémorisé sur votre compte.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {themeOptions.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setThemeMode(option.value)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                mode === option.value
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 dark:bg-slate-800 dark:text-slate-300 dark:hover:text-white'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        <h4 className="mt-6 text-sm font-semibold">Couleurs du site</h4>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Le thème change les couleurs de toutes les pages. Il est mémorisé sur cet appareil.</p>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3" role="radiogroup" aria-label="Thème de couleurs">
          {accents.map((accent) => {
            const selected = accentId === accent.id;
            return (
              <button
                key={accent.id}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => setAccent(accent.id)}
                className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${
                  selected
                    ? 'border-slate-900 ring-2 ring-slate-900/10 dark:border-white dark:ring-white/10'
                    : 'border-slate-200 hover:border-slate-400 dark:border-slate-700 dark:hover:border-slate-500'
                }`}
              >
                <span
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-white"
                  style={{ backgroundImage: `linear-gradient(135deg, ${palettes[accent.primary][500]}, ${palettes[accent.secondary][500]})` }}
                >
                  {selected && <Check className="h-5 w-5" />}
                </span>
                <span className="text-sm font-semibold">{accent.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className={sectionClass}>
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <Star className="h-5 w-5 fill-current text-amber-500" /> Mes favoris
        </h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Ajoute une matière ou une leçon avec l'étoile pour la retrouver ici et sur l'accueil.
        </p>
        {favoritesError && <p role="alert" className="mt-3 text-sm text-red-600 dark:text-red-400">{favoritesError}</p>}
        {favorites.length === 0 ? (
          <p className="mt-4 rounded-xl border border-dashed border-slate-300 p-5 text-center text-sm text-slate-600 dark:border-slate-700 dark:text-slate-400">
            Aucun favori pour le moment.
          </p>
        ) : (
          <ul className="mt-4 space-y-2">
            {favorites.map((favorite) => {
              const isSubject = favorite.item_type === 'subject';
              const subject = isSubject ? subjects.find((item) => item.id === favorite.item_id) : undefined;
              const lesson = !isSubject ? favoriteLessons.find((item) => item.id === favorite.item_id) : undefined;
              if (isSubject && !subject) return null;
              const title = isSubject ? subject!.name : lesson?.title ?? 'Leçon';
              const kindLabel = isSubject ? 'Matière' : `Leçon${lesson ? ` · ${getSubjectName(lesson.subject_id)}` : ''}`;
              return (
                <li key={`${favorite.item_type}-${favorite.item_id}`} className="flex items-center gap-2 rounded-xl border border-slate-200 p-3 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => (isSubject ? onOpenSubject?.(favorite.item_id) : onOpenLesson?.(favorite.item_id))}
                    className="min-w-0 flex-1 text-left"
                  >
                    <span className="block truncate text-sm font-semibold">{title}</span>
                    <span className="block text-xs text-slate-500 dark:text-slate-400">{kindLabel}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void toggleFavorite(favorite.item_type, favorite.item_id)}
                    aria-label={`Retirer ${title} des favoris`}
                    className="rounded-lg p-2 text-amber-500 transition hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Star className="h-5 w-5 fill-current" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <form onSubmit={handleFeedback} className={sectionClass} noValidate>
        <h3 className="flex items-center gap-2 text-lg font-semibold">
          <FlaskConical className="h-5 w-5 text-orange-500" /> StudyFlame bêta
        </h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Tu utilises la version bêta (v0.1) : elle est encore en test. Dis-nous ce qui ne marche pas ou ce que tu aimerais voir.
          N'écris pas de données personnelles (adresse, téléphone).
        </p>
        <textarea
          className={`${inputClass} mt-4 min-h-[110px]`}
          value={feedbackText}
          maxLength={2000}
          aria-label="Ton message"
          placeholder="Ton avis, une idée ou un problème rencontré…"
          onChange={(e) => setFeedbackText(e.target.value)}
        />
        {feedbackMessage && (
          <p role={feedbackMessage.ok ? 'status' : 'alert'} className={`mt-2 text-sm ${feedbackMessage.ok ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
            {feedbackMessage.text}
          </p>
        )}
        <div className="mt-4">
          <button type="submit" disabled={feedbackBusy || !feedbackText.trim()} className={buttonClass}>
            {feedbackBusy && <Loader2 className="h-4 w-4 animate-spin" />} Envoyer mon avis
          </button>
        </div>
      </form>

      <form onSubmit={handleSaveName} className={sectionClass} noValidate>
        <h3 className="text-lg font-semibold">Pseudo</h3>
        <input className={`${inputClass} mt-4`} value={displayName} maxLength={40} onChange={(e) => setDisplayName(e.target.value)} />
        {nameMessage && <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{nameMessage}</p>}
        <div className="mt-4">
          <button type="submit" disabled={savingName} className={buttonClass}>
            {savingName && <Loader2 className="h-4 w-4 animate-spin" />} Enregistrer le pseudo
          </button>
        </div>
      </form>

      <form onSubmit={handleSavePassword} className={sectionClass} noValidate>
        <h3 className="text-lg font-semibold">Mot de passe</h3>
        <input type="password" className={`${inputClass} mt-4`} value={password} placeholder="Nouveau mot de passe" onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
        {passwordMessage && <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{passwordMessage}</p>}
        <div className="mt-4">
          <button type="submit" disabled={savingPassword} className={buttonClass}>
            {savingPassword && <Loader2 className="h-4 w-4 animate-spin" />} Changer le mot de passe
          </button>
        </div>
      </form>

      <form onSubmit={handleSaveEmail} className={sectionClass} noValidate>
        <h3 className="text-lg font-semibold">Adresse e-mail</h3>
        <input type="email" className={`${inputClass} mt-4`} value={email} placeholder={user?.email ?? 'Nouvelle adresse'} onChange={(e) => setEmail(e.target.value)} />
        {emailMessage && <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{emailMessage}</p>}
        <div className="mt-4">
          <button type="submit" disabled={savingEmail} className={buttonClass}>
            {savingEmail && <Loader2 className="h-4 w-4 animate-spin" />} Modifier l'adresse
          </button>
        </div>
      </form>

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Notifications</h3>
        <div className="mt-4 space-y-3">
          <ToggleRow label="Commentaires et réponses" checked={notifyComments} onChange={(value) => handleNotificationToggle('notify_comments', value)} />
          <ToggleRow label="Mentions j'aime" checked={notifyLikes} onChange={(value) => handleNotificationToggle('notify_likes', value)} />
          <ToggleRow label="Messages privés" checked={notifyMessages} onChange={(value) => handleNotificationToggle('notify_messages', value)} />
        </div>
      </div>

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Confidentialité</h3>
        <div className="mt-4">
          <ToggleRow label="Profil privé (vos publications ne sont visibles que par vos amis)" checked={isPrivate} onChange={handlePrivacyToggle} />
        </div>
      </div>

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Comptes bloqués</h3>
        {blocked.length === 0 ? (
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Vous n'avez bloqué personne.</p>
        ) : (
          <ul className="mt-4 space-y-2">
            {blocked.map((entry) => (
              <li key={entry.id} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-sm dark:bg-slate-800">
                <span className="font-medium">{entry.profiles?.display_name ?? 'Compte inconnu'}</span>
                <button type="button" onClick={() => handleUnblock(entry.id)} className="font-semibold text-slate-600 underline dark:text-slate-300">Débloquer</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className={sectionClass}>
        <h3 className="text-lg font-semibold">Historique des connexions</h3>
        {history.length === 0 ? (
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Aucune connexion enregistrée pour le moment.</p>
        ) : (
          <ul className="mt-4 space-y-2">
            {history.map((entry) => (
              <li key={entry.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-4 py-3 text-sm dark:bg-slate-800">
                <span>{entry.device}</span>
                <span className="text-slate-500 dark:text-slate-400">
                  {new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(entry.signed_in_at))}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="rounded-2xl border border-red-200 bg-red-50/60 p-6 dark:border-red-900 dark:bg-red-950/40">
        <h3 className="text-lg font-semibold text-red-700 dark:text-red-300">Supprimer mon compte</h3>
        <p className="mt-1 text-sm text-red-700/80 dark:text-red-300/80">
          Toutes vos données (publications, notes, messages) seront définitivement effacées.
        </p>
        {deleteError && <p role="alert" className="mt-3 text-sm text-red-700 dark:text-red-300">{deleteError}</p>}
        {confirmDelete ? (
          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" onClick={handleDelete} className="rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-700">
              Oui, supprimer définitivement
            </button>
            <button type="button" onClick={() => setConfirmDelete(false)} className="rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:text-slate-200">
              Annuler
            </button>
          </div>
        ) : (
          <button type="button" onClick={() => setConfirmDelete(true)} className="mt-4 inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-red-700">
            <Trash2 className="h-4 w-4" /> Supprimer mon compte
          </button>
        )}
      </div>

      <div className="flex justify-end pb-4">
        <button type="button" onClick={() => signOut()} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-950">
          <LogOut className="h-4 w-4" /> Se déconnecter
        </button>
      </div>
    </section>
  );
}

function ToggleRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (value: boolean) => void }) {
  return (
    <label className="flex items-center justify-between gap-4 rounded-xl bg-slate-50 px-4 py-3 dark:bg-slate-800">
      <span className="text-sm text-slate-700 dark:text-slate-300">{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 rounded border-slate-300 accent-orange-500" />
    </label>
  );
}
