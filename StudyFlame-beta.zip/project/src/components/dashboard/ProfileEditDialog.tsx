import { useEffect, useState, type FormEvent } from 'react';
import { Loader2, X } from 'lucide-react';
import { useAuth, type Profile } from '@/context/AuthContext';
import { learningObjectives, schoolLevels } from '@/data/subjects';

interface ProfileEditDialogProps {
  profile: Profile;
  onClose: () => void;
}

const fieldClass =
  'w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100';

export function ProfileEditDialog({ profile, onClose }: ProfileEditDialogProps) {
  const { updateProfile } = useAuth();
  const [displayName, setDisplayName] = useState(profile.display_name);
  const [level, setLevel] = useState(profile.level);
  const [objective, setObjective] = useState(profile.objective);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = displayName.trim();
    if (!trimmed) return setError('Le prénom ou pseudonyme ne peut pas être vide.');

    setError(null);
    setSaving(true);
    try {
      await updateProfile({ display_name: trimmed, level, objective });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Enregistrement impossible. Réessayez.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm animate-fadeUp" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="profile-dialog-title"
        className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="profile-dialog-title" className="text-xl font-bold">Modifier mon profil</h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Mettez à jour vos informations d'apprentissage.</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Prénom ou pseudonyme</span>
            <input className={fieldClass} value={displayName} maxLength={40} onChange={(e) => setDisplayName(e.target.value)} />
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Niveau scolaire</span>
            <select className={fieldClass} value={level} onChange={(e) => setLevel(e.target.value)}>
              {schoolLevels.map((group) => (
                <optgroup key={group.group} label={group.group}>
                  {group.levels.map((lvl) => (
                    <option key={lvl} value={lvl}>{lvl}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">Objectif d'apprentissage</span>
            <select className={fieldClass} value={objective} onChange={(e) => setObjective(e.target.value)}>
              {learningObjectives.map((goal) => (
                <option key={goal} value={goal}>{goal}</option>
              ))}
            </select>
          </label>

          {error && (
            <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
              {error}
            </p>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-slate-300 py-3 font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-900"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-orange-500 py-3 font-semibold text-white shadow-lg shadow-violet-600/25 transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-70"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
