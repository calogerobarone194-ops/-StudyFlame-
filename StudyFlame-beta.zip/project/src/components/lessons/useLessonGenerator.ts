import { useCallback, useState } from 'react';
import { generateLesson, lessonErrorMessage } from '@/lib/lessons';

export function useLessonGenerator() {
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async (subjectId: string, topic: string, mode: 'lesson' | 'practice' = 'lesson') => {
    setGenerating(true);
    setError(null);
    try {
      return await generateLesson(subjectId, topic, mode);
    } catch (err) {
      setError(lessonErrorMessage(err));
      return null;
    } finally {
      setGenerating(false);
    }
  }, []);

  return { generating, error, run };
}
