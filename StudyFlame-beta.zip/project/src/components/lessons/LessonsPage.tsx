import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { CheckCircle2, Loader2, Sparkles, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { getSubjectName, subjects } from '@/data/subjects';
import { deleteLesson, generateLesson, lessonErrorMessage, listLessons, type Lesson } from '@/lib/lessons';
import { FavoriteButton } from '@/components/FavoriteButton';
import { LessonPlayer } from '@/components/lessons/LessonPlayer';

interface LessonsPageProps {
  initialSubjectId?: string;
  autostart?: boolean;
  initialLessonId?: string;
}

export function LessonsPage({ initialSubjectId, autostart, initialLessonId }: LessonsPageProps) {
  const { profile } = useAuth();
  const [subjectId, setSubjectId] = useState(initialSubjectId ?? subjects[0].id);
  const [topic, setTopic] = useState('');
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(initialLessonId ?? null);
  const autostarted = useRef(false);

  const reload = useCallback(async () => {
    try {
      setLessons(await listLessons());
    } catch {
      setError('Impossible de charger tes leçons.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const generate = useCallback(async (forSubject: string, forTopic: string) => {
    setGenerating(true);
    setError(null);
    try {
      const id = await generateLesson(forSubject, forTopic);
      setTopic('');
      setOpenId(id);
    } catch (err) {
      setError(lessonErrorMessage(err));
    } finally {
      setGenerating(false);
    }
  }, []);

  useEffect(() => {
    if (autostart && initialSubjectId && !autostarted.current) {
      autostarted.current = true;
      void generate(initialSubjectId, '');
    }
  }, [autostart, initialSubjectId, generate]);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!generating) void generate(subjectId, topic);
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteLesson(id);
      setLessons((prev) => prev.filter((lesson) => lesson.id !== id));
    } catch {
      setError('Suppression impossible.');
    }
  };

  if (openId) {
    return (
      <LessonPlayer
        lessonId={openId}
        onBack={() => {
          setOpenId(null);
          void reload();
        }}
      />
    );
  }

  return (
    <div className="space-y-8">
      <section className="rounded-3xl bg-gradient-to-br from-slate-900 to-blue-950 p-8 text-white shadow-xl">
        <h1 className="flex items-center gap-2 text-3xl font-bold tracking-tight">
          <Sparkles className="h-7 w-7 text-orange-400" /> Mes leçons
        </h1>
        <p className="mt-2 max-w-xl text-sm text-slate-300">
          Choisis une matière : StudyFlame crée une leçon et des exercices adaptés à ton niveau {profile?.level} et à ton objectif
          « {profile?.objective} ».
        </p>

        <form onSubmit={handleSubmit} className="mt-6 grid gap-3 sm:grid-cols-[200px_1fr_auto]">
          <label className="sr-only" htmlFor="lesson-subject">Matière</label>
          <select
            id="lesson-subject"
            value={subjectId}
            onChange={(event) => setSubjectId(event.target.value)}
            disabled={generating}
            className="rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-sm font-medium text-white"
          >
            {subjects.map((subject) => (
              <option key={subject.id} value={subject.id} className="text-slate-900">
                {subject.name}
              </option>
            ))}
          </select>
          <label className="sr-only" htmlFor="lesson-topic">Sujet (facultatif)</label>
          <input
            id="lesson-topic"
            value={topic}
            onChange={(event) => setTopic(event.target.value)}
            maxLength={120}
            disabled={generating}
            placeholder="Sujet précis (facultatif) : les fractions, le passé composé…"
            className="rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-sm text-white placeholder:text-slate-400"
          />
          <button
            type="submit"
            disabled={generating}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-3 text-sm font-semibold text-white shadow-md transition hover:-translate-y-0.5 disabled:opacity-60"
          >
            {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            {generating ? 'Création…' : 'Créer ma leçon'}
          </button>
        </form>
        {generating && <p className="mt-3 text-sm text-slate-300">Ta leçon est en préparation, ça prend environ 20 secondes.</p>}
        {error && (
          <p role="alert" className="mt-4 rounded-xl bg-red-500/15 px-4 py-3 text-sm text-red-200">
            {error}
          </p>
        )}
      </section>

      <section>
        <h2 className="text-xl font-bold tracking-tight">Mes leçons précédentes</h2>
        {loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-5 w-5 animate-spin text-slate-500" />
          </div>
        ) : lessons.length === 0 ? (
          <p className="mt-4 rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
            Tu n'as pas encore de leçon. Crée la première ci-dessus !
          </p>
        ) : (
          <ul className="mt-4 grid gap-3">
            {lessons.map((lesson) => (
              <li
                key={lesson.id}
                className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
              >
                <button type="button" onClick={() => setOpenId(lesson.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                  {lesson.status === 'done' ? (
                    <CheckCircle2 className="h-6 w-6 shrink-0 text-emerald-500" />
                  ) : (
                    <span className="h-6 w-6 shrink-0 rounded-full border-2 border-orange-400" aria-label="Pas terminée" />
                  )}
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold">{lesson.title}</span>
                    <span className="block text-xs text-slate-500 dark:text-slate-400">
                      {getSubjectName(lesson.subject_id)}
                      {lesson.status === 'done' ? ` · ${lesson.score} / ${lesson.total} · +${lesson.xp_awarded} XP` : ' · à faire'}
                    </span>
                  </span>
                </button>
                <FavoriteButton type="lesson" id={lesson.id} label={lesson.title} />
                <button
                  type="button"
                  onClick={() => handleDelete(lesson.id)}
                  aria-label={`Supprimer la leçon ${lesson.title}`}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-red-600 dark:hover:bg-slate-800"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
