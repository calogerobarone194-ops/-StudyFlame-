import { useEffect, useState } from 'react';
import { ArrowLeft, Check, CheckCircle2, Flame, Loader2, Trophy, XCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { FavoriteButton } from '@/components/FavoriteButton';
import { getSubjectName } from '@/data/subjects';
import { getLesson, lessonErrorMessage, submitLesson, type Lesson, type LessonResult } from '@/lib/lessons';

interface LessonPlayerProps {
  lessonId: string;
  onBack: () => void;
}

export function LessonPlayer({ lessonId, onBack }: LessonPlayerProps) {
  const { refreshProfile } = useAuth();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [step, setStep] = useState<'read' | 'quiz' | 'result'>('read');
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [result, setResult] = useState<LessonResult | null>(null);

  useEffect(() => {
    let active = true;
    getLesson(lessonId)
      .then((data) => {
        if (!active) return;
        if (!data) {
          setLoadError('Leçon introuvable.');
          return;
        }
        setLesson(data);
        setAnswers(new Array(data.total).fill(null));
      })
      .catch(() => active && setLoadError('Impossible de charger la leçon.'));
    return () => {
      active = false;
    };
  }, [lessonId]);

  if (loadError) {
    return (
      <div className="space-y-4">
        <BackButton onBack={onBack} />
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
          {loadError}
        </p>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
      </div>
    );
  }

  const done = lesson.status === 'done';
  const allAnswered = answers.every((a) => a !== null);

  const handleSubmit = async () => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      const data = await submitLesson(lesson.id, answers as number[]);
      setResult(data);
      setStep('result');
      void refreshProfile();
    } catch (err) {
      setSubmitError(lessonErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <BackButton onBack={onBack} />

      <header>
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            {getSubjectName(lesson.subject_id)} · {lesson.level}
          </p>
          <FavoriteButton type="lesson" id={lesson.id} label={lesson.title} />
        </div>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">{lesson.title}</h1>
        <p className="mt-3 text-base leading-relaxed text-slate-600 dark:text-slate-400">{lesson.content.intro}</p>
      </header>

      {(step === 'read' || done) && (
        <>
          {lesson.content.sections.map((section) => (
            <section key={section.heading} className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <h2 className="text-lg font-semibold">{section.heading}</h2>
              <div className="mt-3 space-y-3 text-base leading-relaxed text-slate-700 dark:text-slate-300">
                {section.body.split(/\n\s*\n/).map((paragraph, index) => (
                  <p key={index} className="whitespace-pre-line">{paragraph}</p>
                ))}
              </div>
            </section>
          ))}

          <section className="rounded-2xl border border-orange-200 bg-orange-50 p-6 dark:border-orange-900/60 dark:bg-orange-950/30">
            <h2 className="flex items-center gap-2 text-lg font-semibold">
              <Flame className="h-5 w-5 text-orange-500" /> À retenir
            </h2>
            <ul className="mt-3 space-y-2">
              {lesson.content.key_points.map((point) => (
                <li key={point} className="flex gap-2 text-base text-slate-800 dark:text-slate-200">
                  <Check className="mt-1 h-4 w-4 shrink-0 text-orange-600" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </section>

          {done ? (
            <p className="rounded-2xl bg-slate-100 p-5 text-center text-sm font-semibold dark:bg-slate-900">
              Leçon terminée : {lesson.score} / {lesson.total} · +{lesson.xp_awarded} XP
            </p>
          ) : (
            <button
              type="button"
              onClick={() => setStep('quiz')}
              className="w-full rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 px-6 py-4 text-base font-semibold text-white shadow-md shadow-orange-500/25 transition hover:-translate-y-0.5"
            >
              C'est compris, je passe aux exercices
            </button>
          )}
        </>
      )}

      {step === 'quiz' && !done && (
        <>
          {lesson.content.exercises.map((exercise, qi) => (
            <fieldset key={qi} className="rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <legend className="px-1 text-sm font-semibold text-slate-500">Question {qi + 1} / {lesson.total}</legend>
              <p className="text-base font-semibold">{exercise.question}</p>
              <div className="mt-4 grid gap-2">
                {exercise.choices.map((choice, ci) => {
                  const selected = answers[qi] === ci;
                  return (
                    <button
                      key={ci}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => setAnswers((prev) => prev.map((value, index) => (index === qi ? ci : value)))}
                      className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                        selected
                          ? 'border-orange-500 bg-orange-50 text-slate-900 dark:bg-orange-950/40 dark:text-white'
                          : 'border-slate-200 hover:border-slate-400 dark:border-slate-700 dark:hover:border-slate-500'
                      }`}
                    >
                      {choice}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          ))}

          {submitError && (
            <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">
              {submitError}
            </p>
          )}

          <button
            type="button"
            disabled={!allAnswered || submitting}
            onClick={handleSubmit}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-6 py-4 text-base font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-slate-900"
          >
            {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
            {allAnswered ? 'Valider mes réponses' : 'Réponds à toutes les questions'}
          </button>
        </>
      )}

      {step === 'result' && result && (
        <>
          <section className="rounded-3xl bg-gradient-to-br from-slate-900 to-blue-950 p-8 text-center text-white shadow-xl">
            <Trophy className="mx-auto h-10 w-10 text-violet-300" />
            <h2 className="mt-3 text-2xl font-bold">
              {result.score === result.total ? 'Parfait !' : result.score >= result.total / 2 ? 'Bien joué !' : 'Continue, tu progresses !'}
            </h2>
            <p className="mt-2 text-slate-300">
              {result.score} / {result.total} bonnes réponses
            </p>
            <div className="mt-5 flex justify-center gap-3 text-sm font-semibold">
              <span className="rounded-full bg-white/10 px-4 py-2">+{result.xp} XP</span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-2">
                <Flame className="h-4 w-4 text-orange-400" /> {result.flames} {result.flames > 1 ? 'flammes' : 'flamme'}
              </span>
            </div>
          </section>

          {lesson.content.exercises.map((exercise, qi) => {
            const detail = result.results[qi];
            return (
              <article
                key={qi}
                className={`rounded-2xl border p-6 ${
                  detail.correct
                    ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900/60 dark:bg-emerald-950/30'
                    : 'border-red-200 bg-red-50 dark:border-red-900/60 dark:bg-red-950/30'
                }`}
              >
                <p className="flex items-start gap-2 text-base font-semibold">
                  {detail.correct ? (
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                  ) : (
                    <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
                  )}
                  {exercise.question}
                </p>
                {!detail.correct && (
                  <p className="mt-2 text-sm text-slate-700 dark:text-slate-300">
                    Ta réponse : {exercise.choices[answers[qi] ?? 0]}
                  </p>
                )}
                <p className="mt-1 text-sm font-semibold text-slate-800 dark:text-slate-200">
                  Bonne réponse : {exercise.choices[detail.answer_index]}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">{detail.explanation}</p>
              </article>
            );
          })}

          <button
            type="button"
            onClick={onBack}
            className="w-full rounded-xl bg-slate-900 px-6 py-4 text-base font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900"
          >
            Retour à mes leçons
          </button>
        </>
      )}
    </div>
  );
}

function BackButton({ onBack }: { onBack: () => void }) {
  return (
    <button
      type="button"
      onClick={onBack}
      className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 transition hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
    >
      <ArrowLeft className="h-4 w-4" /> Mes leçons
    </button>
  );
}
