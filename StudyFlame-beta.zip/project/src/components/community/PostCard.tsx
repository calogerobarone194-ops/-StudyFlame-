import { useEffect, useState } from 'react';
import { Flag, Heart, Loader2, Mail, MessageSquare, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  communityErrorMessage,
  getPhotoUrl,
  reportCommunityContent,
  type CommunityPostWithMeta,
} from '@/lib/community';

interface PostCardProps {
  post: CommunityPostWithMeta;
  onOpenComments: (postId: string) => void;
  onToggleLike: (postId: string) => Promise<boolean>;
  onReport: (type: 'post' | 'comment', id: string) => Promise<void>;
  onDelete: (postId: string) => Promise<void>;
  onMessage?: (userId: string, name: string) => void;
}

export function PostCard({ post, onOpenComments, onToggleLike, onReport, onDelete, onMessage }: PostCardProps) {
  const { user } = useAuth();
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [liked, setLiked] = useState(post.liked_by_me);
  const [likes, setLikes] = useState(post.like_count);
  const [reported, setReported] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    let active = true;
    if (!post.photo_path) return;
    getPhotoUrl(post.photo_path).then((url) => {
      if (active) setPhotoUrl(url);
    });
    return () => {
      active = false;
    };
  }, [post.photo_path]);

  const isOwn = post.user_id === user?.id;

  const handleLike = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const nowLiked = await onToggleLike(post.id);
      setLiked(nowLiked);
      setLikes((count) => count + (nowLiked ? 1 : -1));
    } catch (err) {
      setError(communityErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const handleReport = async () => {
    setError(null);
    try {
      await onReport('post', post.id);
      setReported(true);
    } catch (err) {
      setError(communityErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    setError(null);
    try {
      await onDelete(post.id);
    } catch (err) {
      setError(communityErrorMessage(err));
      setConfirmDelete(false);
    }
  };

  const date = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(post.created_at));

  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 transition hover:shadow-md dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-sky-500 to-blue-600 text-sm font-bold text-white">
            {post.author_name.charAt(0).toUpperCase()}
          </span>
          <div>
            <p className="text-sm font-semibold">{post.author_name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{date}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {!isOwn && onMessage && (
            <button
              type="button"
              onClick={() => onMessage(post.user_id, post.author_name)}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white"
            >
              <Mail className="h-3.5 w-3.5" /> Écrire
            </button>
          )}
          {!isOwn && !reported && (
            <button
              type="button"
              onClick={handleReport}
              className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-amber-50 hover:text-amber-700 dark:hover:bg-amber-950/60 dark:hover:text-amber-300"
            >
              <Flag className="h-3.5 w-3.5" /> Signaler
            </button>
          )}
          {reported && <span className="px-2 py-1.5 text-xs text-slate-500 dark:text-slate-400">Signalé, merci</span>}
        </div>
      </div>

      <p className="mt-4 whitespace-pre-wrap text-base leading-relaxed text-slate-800 dark:text-slate-200">{post.body}</p>

      {photoUrl && (
        <img
          src={photoUrl}
          alt="Photo de la publication"
          className="mt-4 max-h-96 w-full rounded-xl border border-slate-200 object-cover dark:border-slate-800"
          loading="lazy"
        />
      )}

      {error && <p role="alert" className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <div className="mt-4 flex items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
        <button
          type="button"
          onClick={handleLike}
          disabled={busy}
          aria-pressed={liked}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-60 ${
            liked
              ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400'
              : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white'
          }`}
        >
          <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} /> {likes}
        </button>
        <button
          type="button"
          onClick={() => onOpenComments(post.id)}
          className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          <MessageSquare className="h-4 w-4" /> {post.comment_count}
        </button>
        {isOwn && (
          confirmDelete ? (
            <span className="ml-auto flex items-center gap-1">
              <button type="button" onClick={handleDelete} className="rounded-lg bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-700">Confirmer</button>
              <button type="button" onClick={() => setConfirmDelete(false)} className="rounded-lg px-2 py-1.5 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">Annuler</button>
            </span>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              className="ml-auto inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-500 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/60 dark:hover:text-red-400"
            >
              <Trash2 className="h-4 w-4" /> Supprimer
            </button>
          )
        )}
      </div>
    </article>
  );
}

export function CommentRow({
  comment,
  onReply,
  onReport,
  onDelete,
}: {
  comment: { id: string; user_id: string; author_name: string; body: string; created_at: string };
  onReply: (comment: { id: string; author_name: string }) => void;
  onReport: (type: 'post' | 'comment', id: string) => Promise<void>;
  onDelete: (commentId: string) => Promise<void>;
}) {
  const { user } = useAuth();
  const [reported, setReported] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const isOwn = comment.user_id === user?.id;

  const date = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(comment.created_at));

  return (
    <div className="rounded-xl bg-slate-50 p-4 dark:bg-slate-800">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm">
          <span className="font-semibold text-slate-900 dark:text-slate-100">{comment.author_name}</span>{' '}
          <span className="text-slate-500 dark:text-slate-400">· {date}</span>
        </p>
        <div className="flex items-center gap-1">
          {!isOwn && !reported && (
            <button type="button" onClick={() => onReport('comment', comment.id).then(() => setReported(true)).catch((err) => setError(communityErrorMessage(err)))} className="rounded-lg p-1.5 text-slate-500 transition hover:bg-amber-50 hover:text-amber-700 dark:hover:bg-amber-950/60 dark:hover:text-amber-300" aria-label="Signaler ce commentaire">
              <Flag className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>
      <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-700 dark:text-slate-300">{comment.body}</p>
      {error && <p role="alert" className="mt-2 text-xs text-red-600 dark:text-red-400">{error}</p>}
      <div className="mt-2 flex items-center gap-3">
        <button type="button" onClick={() => onReply(comment)} className="text-xs font-semibold text-slate-500 transition hover:text-slate-900 dark:hover:text-white">
          Répondre
        </button>
        {isOwn && (
          confirmDelete ? (
            <span className="flex items-center gap-1">
              <button type="button" onClick={() => onDelete(comment.id).catch((err) => setError(communityErrorMessage(err)))} className="rounded bg-red-600 px-2 py-0.5 text-xs font-semibold text-white hover:bg-red-700">Confirmer</button>
              <button type="button" onClick={() => setConfirmDelete(false)} className="rounded px-1.5 py-0.5 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">Annuler</button>
            </span>
          ) : (
            <button type="button" onClick={() => setConfirmDelete(true)} className="text-xs font-semibold text-slate-500 transition hover:text-red-600 dark:hover:text-red-400">
              Supprimer
            </button>
          )
        )}
      </div>
    </div>
  );
}

export function FeedSkeleton() {
  return (
    <div className="flex justify-center py-16">
      <Loader2 className="h-6 w-6 animate-spin text-slate-500" />
    </div>
  );
}
