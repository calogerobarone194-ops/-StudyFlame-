import { useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, ImagePlus, Loader2, Send, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  communityErrorMessage,
  createComment,
  createPost,
  deleteComment,
  deletePost,
  listComments,
  listPosts,
  reportCommunityContent,
  toggleLike,
  uploadPostPhoto,
  type CommunityComment,
  type CommunityPostWithMeta,
} from '@/lib/community';
import { PostCard, CommentRow, FeedSkeleton } from '@/components/community/PostCard';

export function CommunityFeed({ onMessage }: { onMessage?: (userId: string, name: string) => void } = {}) {
  const [posts, setPosts] = useState<CommunityPostWithMeta[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [composerBody, setComposerBody] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [posting, setPosting] = useState(false);
  const [postError, setPostError] = useState<string | null>(null);
  const [openPostId, setOpenPostId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoadError(null);
    listPosts()
      .then((data) => {
        if (active) setPosts(data);
      })
      .catch((err) => {
        if (active) setLoadError(communityErrorMessage(err));
      });
    return () => {
      active = false;
    };
  }, []);

  const handlePhotoChange = (file: File | null) => {
    setPhotoFile(file);
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoPreview(file ? URL.createObjectURL(file) : null);
  };

  useEffect(() => () => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
  }, [photoPreview]);

  const handlePost = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const body = composerBody.trim();
    if (!body) return setPostError('Écrivez quelque chose avant de publier.');

    setPostError(null);
    setPosting(true);
    try {
      const photoPath = photoFile ? await uploadPostPhoto(photoFile) : null;
      const post = await createPost({ body, photoPath });
      setPosts((previous) => [{ ...post, like_count: 0, comment_count: 0, liked_by_me: false }, ...(previous ?? [])]);
      setComposerBody('');
      handlePhotoChange(null);
    } catch (err) {
      setPostError(communityErrorMessage(err));
    } finally {
      setPosting(false);
    }
  };

  const handleToggleLike = async (postId: string) => toggleLike(postId);

  const handleReport = async (type: 'post' | 'comment', id: string) => reportCommunityContent(type, id);

  const handleDeletePost = async (postId: string) => {
    const post = posts?.find((item) => item.id === postId);
    await deletePost(postId, post?.photo_path ?? null);
    setPosts((previous) => previous?.filter((item) => item.id !== postId) ?? null);
  };

  if (openPostId) {
    return <PostComments postId={openPostId} onBack={() => setOpenPostId(null)} />;
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Communauté</h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Partagez vos devoirs, aidez les autres, échangez.</p>
      </div>

      <form onSubmit={handlePost} className="space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900" noValidate>
        <textarea
          className="min-h-[90px] w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          value={composerBody}
          maxLength={2000}
          placeholder="Partagez une question, un devoir, une astuce…"
          onChange={(e) => setComposerBody(e.target.value)}
        />
        {photoPreview && (
          <div className="relative inline-block">
            <img src={photoPreview} alt="Aperçu de la photo" className="h-24 rounded-lg border border-slate-200 object-cover dark:border-slate-700" />
            <button type="button" onClick={() => handlePhotoChange(null)} aria-label="Retirer la photo" className="absolute -right-2 -top-2 rounded-full bg-slate-900 p-1 text-white shadow-md">
              <X className="h-3 w-3" />
            </button>
          </div>
        )}
        {postError && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{postError}</p>}
        <div className="flex items-center justify-between">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800">
            <ImagePlus className="h-4 w-4" /> Photo
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => handlePhotoChange(e.target.files?.[0] ?? null)}
            />
          </label>
          <button
            type="submit"
            disabled={posting}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
          >
            {posting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Publier
          </button>
        </div>
      </form>

      {loadError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{loadError}</p>
      )}

      {!posts && !loadError && <FeedSkeleton />}

      {posts && posts.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <p className="font-semibold">Aucune publication pour le moment</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Lancez la conversation avec votre première publication.</p>
        </div>
      )}

      {posts && posts.length > 0 && (
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onOpenComments={setOpenPostId}
              onToggleLike={handleToggleLike}
              onReport={handleReport}
              onDelete={handleDeletePost}
              onMessage={onMessage}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function PostComments({ postId, onBack }: { postId: string; onBack: () => void }) {
  const { user } = useAuth();
  const [comments, setComments] = useState<CommunityComment[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [replyTo, setReplyTo] = useState<{ id: string; author_name: string } | null>(null);
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    listComments(postId)
      .then((data) => {
        if (active) setComments(data);
      })
      .catch((err) => {
        if (active) setLoadError(communityErrorMessage(err));
      });
    return () => {
      active = false;
    };
  }, [postId]);

  const handleSend = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = body.trim();
    if (!trimmed) return setSendError('Écrivez votre commentaire.');

    setSendError(null);
    setSending(true);
    try {
      const comment = await createComment({ postId, parentCommentId: replyTo?.id ?? null, body: trimmed });
      setComments((previous) => [...(previous ?? []), comment]);
      setBody('');
      setReplyTo(null);
    } catch (err) {
      setSendError(communityErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const topLevel = comments?.filter((comment) => !comment.parent_comment_id) ?? [];
  const repliesOf = (commentId: string) => comments?.filter((comment) => comment.parent_comment_id === commentId) ?? [];

  return (
    <section className="space-y-6">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" /> Retour au fil
      </button>

      <h2 className="text-xl font-bold">
        {comments === null ? 'Commentaires' : comments.length === 0 ? 'Aucun commentaire' : `${comments.length} commentaire${comments.length > 1 ? 's' : ''}`}
      </h2>

      {loadError && (
        <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{loadError}</p>
      )}

      {!comments && !loadError && <FeedSkeleton />}

      {comments && (
        <div className="space-y-3">
          {topLevel.map((comment) => (
            <div key={comment.id} className="space-y-2">
              <CommentRow
                comment={comment}
                onReply={setReplyTo}
                onReport={reportCommunityContent}
                onDelete={async (id) => {
                  await deleteComment(id);
                  setComments((previous) => previous?.filter((item) => item.id !== id) ?? null);
                }}
              />
              {repliesOf(comment.id).map((reply) => (
                <div key={reply.id} className="ml-6">
                  <CommentRow
                    comment={reply}
                    onReply={setReplyTo}
                    onReport={reportCommunityContent}
                    onDelete={async (id) => {
                      await deleteComment(id);
                      setComments((previous) => previous?.filter((item) => item.id !== id) ?? null);
                    }}
                  />
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <form onSubmit={handleSend} className="space-y-3 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900" noValidate>
        {replyTo && (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Réponse à <span className="font-semibold">{replyTo.author_name}</span>{' '}
            <button type="button" onClick={() => setReplyTo(null)} className="font-semibold text-slate-700 underline dark:text-slate-300">annuler</button>
          </p>
        )}
        <textarea
          className="min-h-[80px] w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          value={body}
          maxLength={1000}
          placeholder="Votre commentaire…"
          onChange={(e) => setBody(e.target.value)}
        />
        {sendError && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{sendError}</p>}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={sending}
            className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
          >
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            Envoyer
          </button>
        </div>
      </form>
    </section>
  );
}
