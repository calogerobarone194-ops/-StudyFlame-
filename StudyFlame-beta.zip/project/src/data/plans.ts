export type PlanKind = 'classique' | 'etudiant';

export const plans: Record<PlanKind, { label: string; options: { days: number; label: string; price: string }[] }> = {
  classique: {
    label: 'Classique',
    options: [
      { days: 1, label: '1 jour', price: '0,99 €' },
      { days: 7, label: '7 jours', price: '2,99 €' },
      { days: 30, label: '30 jours', price: '5,99 €' },
      { days: 90, label: '90 jours', price: '14,99 €' },
      { days: 365, label: '365 jours', price: '49,99 €' },
    ],
  },
  etudiant: {
    label: 'Étudiant',
    options: [
      { days: 30, label: '30 jours', price: '3,99 €' },
      { days: 90, label: '90 jours', price: '9,99 €' },
      { days: 365, label: '365 jours', price: '29,99 €' },
    ],
  },
};

export const premiumFeatures = [
  'Toutes les matières et tous les niveaux, de P1 à S6',
  'Quiz illimités et préparation aux examens',
  'Statistiques détaillées de progression',
  'Rappels personnalisés pour garder votre flamme',
  'Sans publicité',
];
