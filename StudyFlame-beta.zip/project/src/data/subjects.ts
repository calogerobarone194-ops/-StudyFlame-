import { Calculator, BookOpen, Landmark, Globe2, Languages, FlaskConical, Atom, Zap, Monitor, type LucideIcon } from 'lucide-react';

export type SubjectCategory = 'Lettres' | 'Sciences' | 'Sciences humaines' | 'Langues' | 'Technologie';

export interface Subject {
  id: string;
  name: string;
  category: SubjectCategory;
  description: string;
  lessons: number;
  icon: LucideIcon;
  accent: string;
}

export const subjects: Subject[] = [
  { id: 'maths', name: 'Mathématiques', category: 'Sciences', description: 'Calcul, géométrie, fonctions et logique pas à pas.', lessons: 48, icon: Calculator, accent: 'from-sky-500 to-blue-600' },
  { id: 'francais', name: 'Français', category: 'Lettres', description: 'Grammaire, orthographe, conjugaison et lecture.', lessons: 42, icon: BookOpen, accent: 'from-violet-500 to-purple-600' },
  { id: 'histoire', name: 'Histoire', category: 'Sciences humaines', description: 'Repères chronologiques et grands événements.', lessons: 30, icon: Landmark, accent: 'from-amber-500 to-orange-600' },
  { id: 'geographie', name: 'Géographie', category: 'Sciences humaines', description: 'Continents, climats, cartes et territoires.', lessons: 28, icon: Globe2, accent: 'from-emerald-500 to-teal-600' },
  { id: 'anglais', name: 'Anglais', category: 'Langues', description: 'Vocabulaire, grammaire et compréhension orale.', lessons: 36, icon: Languages, accent: 'from-rose-500 to-pink-600' },
  { id: 'sciences', name: 'Sciences', category: 'Sciences', description: 'Le vivant, la Terre et l\'univers expliqués simplement.', lessons: 34, icon: FlaskConical, accent: 'from-green-500 to-emerald-600' },
  { id: 'chimie', name: 'Chimie', category: 'Sciences', description: 'Atomes, réactions et formules chimiques.', lessons: 22, icon: Atom, accent: 'from-cyan-500 to-sky-600' },
  { id: 'physique', name: 'Physique', category: 'Sciences', description: 'Forces, énergie, ondes et électricité.', lessons: 26, icon: Zap, accent: 'from-yellow-500 to-amber-600' },
  { id: 'informatique', name: 'Informatique', category: 'Technologie', description: 'Algorithmes, programmation et culture numérique.', lessons: 20, icon: Monitor, accent: 'from-slate-500 to-slate-700' },
];

export const languages = [
  { id: 'anglais', name: 'Anglais', flag: 'EN' },
  { id: 'neerlandais', name: 'Néerlandais', flag: 'NL' },
  { id: 'allemand', name: 'Allemand', flag: 'DE' },
  { id: 'espagnol', name: 'Espagnol', flag: 'ES' },
] as const;

export function getSubjectName(subjectId: string): string {
  return (
    subjects.find((subject) => subject.id === subjectId)?.name ??
    languages.find((language) => language.id === subjectId)?.name ??
    subjectId
  );
}

export const schoolLevels = [
  { group: 'Primaire', levels: ['P1', 'P2', 'P3', 'P4', 'P5', 'P6'] },
  { group: 'Secondaire', levels: ['S1', 'S2', 'S3', 'S4', 'S5', 'S6'] },
] as const;

export const learningObjectives = [
  'Réussir mes examens',
  'Rattraper mon retard',
  'Progresser régulièrement',
  'Réviser avant un contrôle',
  'Apprendre pour le plaisir',
] as const;
