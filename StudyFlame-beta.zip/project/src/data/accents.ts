// Colour themes. The site's "orange" (main colour) and "violet" (second colour) Tailwind palettes
// are read from CSS variables, so choosing a theme recolours every page at once.

export const shades = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950] as const;
export type Shade = (typeof shades)[number];
type Palette = Record<Shade, string>;

function palette(...hex: string[]): Palette {
  return Object.fromEntries(shades.map((shade, index) => [shade, hex[index]])) as Palette;
}

export const palettes = {
  orange: palette('#fff7ed', '#ffedd5', '#fed7aa', '#fdba74', '#fb923c', '#f97316', '#ea580c', '#c2410c', '#9a3412', '#7c2d12', '#431407'),
  violet: palette('#f5f3ff', '#ede9fe', '#ddd6fe', '#c4b5fd', '#a78bfa', '#8b5cf6', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95', '#2e1065'),
  blue: palette('#eff6ff', '#dbeafe', '#bfdbfe', '#93c5fd', '#60a5fa', '#3b82f6', '#2563eb', '#1d4ed8', '#1e40af', '#1e3a8a', '#172554'),
  cyan: palette('#ecfeff', '#cffafe', '#a5f3fc', '#67e8f9', '#22d3ee', '#06b6d4', '#0891b2', '#0e7490', '#155e75', '#164e63', '#083344'),
  emerald: palette('#ecfdf5', '#d1fae5', '#a7f3d0', '#6ee7b7', '#34d399', '#10b981', '#059669', '#047857', '#065f46', '#064e3b', '#022c22'),
  teal: palette('#f0fdfa', '#ccfbf1', '#99f6e4', '#5eead4', '#2dd4bf', '#14b8a6', '#0d9488', '#0f766e', '#115e59', '#134e4a', '#042f2e'),
  pink: palette('#fdf2f8', '#fce7f3', '#fbcfe8', '#f9a8d4', '#f472b6', '#ec4899', '#db2777', '#be185d', '#9d174d', '#831843', '#500724'),
  purple: palette('#faf5ff', '#f3e8ff', '#e9d5ff', '#d8b4fe', '#c084fc', '#a855f7', '#9333ea', '#7e22ce', '#6b21a8', '#581c87', '#3b0764'),
  rose: palette('#fff1f2', '#ffe4e6', '#fecdd3', '#fda4af', '#fb7185', '#f43f5e', '#e11d48', '#be123c', '#9f1239', '#881337', '#4c0519'),
  amber: palette('#fffbeb', '#fef3c7', '#fde68a', '#fcd34d', '#fbbf24', '#f59e0b', '#d97706', '#b45309', '#92400e', '#78350f', '#451a03'),
  indigo: palette('#eef2ff', '#e0e7ff', '#c7d2fe', '#a5b4fc', '#818cf8', '#6366f1', '#4f46e5', '#4338ca', '#3730a3', '#312e81', '#1e1b4b'),
} as const;

export type PaletteName = keyof typeof palettes;

export interface Accent {
  id: string;
  label: string;
  primary: PaletteName;
  secondary: PaletteName;
}

export const accents: Accent[] = [
  { id: 'flamme', label: 'Flamme', primary: 'orange', secondary: 'violet' },
  { id: 'ocean', label: 'Océan', primary: 'blue', secondary: 'cyan' },
  { id: 'foret', label: 'Forêt', primary: 'emerald', secondary: 'teal' },
  { id: 'bonbon', label: 'Bonbon', primary: 'pink', secondary: 'purple' },
  { id: 'couchant', label: 'Couchant', primary: 'rose', secondary: 'amber' },
  { id: 'minuit', label: 'Minuit', primary: 'indigo', secondary: 'purple' },
];

export const defaultAccentId = accents[0].id;
