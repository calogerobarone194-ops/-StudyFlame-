import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Flag, Loader2, Search, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export interface ConversationSummary {
  partner_id: string;
  partner_name: string;
  last_body: string;
  last_at: string;
}

export interface DirectMessage {
  id: string;
  sender_id: string;
  recipient_id: string;
  body: string;
  created_at: string;
}

function contactBlocked(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('contact_info_blocked')) {
    return 'Les numéros, e-mails, liens et réseaux sociaux ne sont pas autorisés dans les messages.';
  }
  return 'Envoi impossible pour le moment. Réessayez.';
}

export function useConversations() {
  const [conversations, setConversations] = useState<ConversationSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const { data: sessionData } = await supabase.auth.getSession();
    const me = sessionData.session?.user.id;
    if (!me) return;

    const { data, error: fetchError } = await supabase
      .from('direct_messages')
      .select('sender_id, recipient_id, body, created_at')
      .or(`sender_id.eq.${me},recipient_id.eq.${me}`)
      .order('created_at', { ascending: false })
      .limit(200);

    if (fetchError) {
      setError('Impossible de charger vos conversations.');
      setConversations([]);
      return;
    }

    const partnerIds = new Set<string>();
    for (const message of data ?? []) {
      partnerIds.add(message.sender_id === me ? message.recipient_id : message.sender_id);
    }

    const summaries: ConversationSummary[] = [];
    const seen = new Set<string>();
    for (const message of data ?? []) {
      const partnerId = message.sender_id === me ? message.recipient_id : message.sender_id;
      if (seen.has(partnerId)) continue;
      seen.add(partnerId);
      summaries.push({ partner_id: partnerId, partner_name: '…', last_body: message.body, last_at: message.created_at });
    }

    if (summaries.length > 0) {
      // Profiles are private; this function only returns the pseudonym of people you exchanged messages with.
      const { data: profilesData } = await supabase.rpc('get_conversation_names', { p_ids: [...partnerIds] });
      const names = new Map(
        ((profilesData ?? []) as { id: string; display_name: string }[]).map((profile) => [profile.id, profile.display_name]),
      );
      for (const summary of summaries) {
        summary.partner_name = names.get(summary.partner_id) ?? 'Compte supprimé';
      }
    }

    setConversations(summaries);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { conversations, error, reload: load };
}

export function ConversationsPage() {
  const { conversations, error } = useConversations();
  const [search, setSearch] = useState('');

  const filtered = conversations?.filter((conversation) =>
    conversation.partner_name.toLowerCase().includes(search.trim().toLowerCase()),
  );

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Messages privés</h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Vos conversations avec les autres élèves.</p>
      </div>

      {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/60 dark:text-red-300">{error}</p>}

      <label className="relative block">
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          className="w-full rounded-xl border border-slate-300 bg-white py-3 pl-11 pr-4 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
          value={search}
          placeholder="Rechercher une conversation…"
          onChange={(e) => setSearch(e.target.value)}
        />
      </label>

      {!conversations && !error && (
        <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-slate-500" /></div>
      )}

      {filtered && filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center dark:border-slate-700 dark:bg-slate-900">
          <p className="font-semibold">Aucune conversation</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">Le bouton « Écrire » arrive sur les profils de la communauté.</p>
        </div>
      )}

      {filtered && filtered.length > 0 && (
        <ul className="space-y-2">
          {filtered.map((conversation) => (
            <li key={conversation.partner_id} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
              <p className="text-sm font-semibold">{conversation.partner_name}</p>
              <p className="mt-0.5 truncate text-sm text-slate-600 dark:text-slate-400">{conversation.last_body}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export function MessageComposer({ recipientId, recipientName, onSent }: { recipientId: string; recipientName: string; onSent: () => void }) {
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSend = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = body.trim();
    if (!trimmed) return setError('Écrivez votre message.');

    setSending(true);
    setError(null);
    try {
      const { error: sendError } = await supabase
        .from('direct_messages')
        .insert({ recipient_id: recipientId, body: trimmed });
      if (sendError) throw sendError;
      setBody('');
      onSent();
    } catch (err) {
      setError(contactBlocked(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={handleSend} className="space-y-3" noValidate>
      <textarea
        className="min-h-[90px] w-full resize-y rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 transition focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-500/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
        value={body}
        maxLength={2000}
        placeholder={`Votre message à ${recipientName}…`}
        onChange={(e) => setBody(e.target.value)}
      />
      {error && <p role="alert" className="text-sm text-red-600 dark:text-red-400">{error}</p>}
      <button
        type="submit"
        disabled={sending}
        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
      >
        {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        Envoyer
      </button>
    </form>
  );
}

export function ReportMessageButton({ messageId, onReported }: { messageId: string; onReported: () => void }) {
  const [reporting, setReporting] = useState(false);
  const [reported, setReported] = useState(false);

  const handleReport = async () => {
    setReporting(true);
    try {
      await supabase.rpc('report_direct_message', { p_message_id: messageId });
      setReported(true);
      onReported();
    } finally {
      setReporting(false);
    }
  };

  if (reported) return <span className="text-xs text-slate-500 dark:text-slate-400">Signalé, merci</span>;

  return (
    <button
      type="button"
      onClick={handleReport}
      disabled={reporting}
      aria-label="Signaler ce message"
      className="rounded-lg p-1.5 text-slate-500 transition hover:bg-amber-50 hover:text-amber-700 disabled:opacity-50 dark:hover:bg-amber-950/60 dark:hover:text-amber-300"
    >
      <Flag className="h-3.5 w-3.5" />
    </button>
  );
}
