import { supabase } from '@/lib/supabase';

export interface AccountSettings {
  avatar_path: string | null;
  theme_mode: 'light' | 'dark' | 'auto';
  notify_comments: boolean;
  notify_likes: boolean;
  notify_messages: boolean;
  is_private_profile: boolean;
}

export interface BlockedAccount {
  id: string;
  blocked_id: string;
  profiles: { display_name: string } | null;
}

export interface SignInEntry {
  id: string;
  signed_in_at: string;
  device: string;
}

const settingsColumns = 'avatar_path, theme_mode, notify_comments, notify_likes, notify_messages, is_private_profile';

export function settingsErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('not_authorized')) return 'Ce fichier ne peut pas être utilisé comme photo de profil.';
  return 'Une erreur est survenue. Réessayez dans un instant.';
}

export async function getSettings(): Promise<Partial<AccountSettings>> {
  const { data, error } = await supabase.from('profiles').select(settingsColumns).eq('id', (await supabase.auth.getUser()).data.user?.id ?? '').maybeSingle();
  if (error) throw new Error(error.message);
  return data ?? {};
}

export async function updateSettings(changes: Partial<Omit<AccountSettings, 'avatar_path'>>): Promise<void> {
  const { error } = await supabase.from('profiles').update(changes);
  if (error) throw new Error(error.message);
}

export async function uploadAvatar(file: File): Promise<string> {
  if (file.size > 2 * 1024 * 1024) throw new Error('La photo de profil doit peser moins de 2 Mo.');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Formats acceptés : JPEG, PNG ou WebP.');

  const { data: sessionData } = await supabase.auth.getSession();
  const userId = sessionData.session?.user.id;
  if (!userId) throw new Error('Connectez-vous pour changer de photo.');

  const extension = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
  const path = `${userId}/${crypto.randomUUID()}.${extension}`;

  const { error } = await supabase.storage.from('avatars').upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw new Error("Envoi de la photo impossible. Vérifiez sa taille et son format.");
  return path;
}

export async function saveAvatarPath(path: string | null): Promise<void> {
  const { error } = await supabase.rpc('set_avatar_path', { p_path: path });
  if (error) throw new Error(settingsErrorMessage(error));
}

export async function getAvatarUrl(avatarPath: string): Promise<string | null> {
  const { data, error } = await supabase.storage.from('avatars').createSignedUrl(avatarPath, 600);
  if (error) return null;
  return data?.signedUrl ?? null;
}

export async function listBlocked(): Promise<BlockedAccount[]> {
  const { data, error } = await supabase
    .from('account_blocks')
    .select('id, blocked_id, profiles:profiles!account_blocks_blocked_id_fkey(display_name)')
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as BlockedAccount[];
}

export async function blockUser(userId: string): Promise<void> {
  const { error } = await supabase.from('account_blocks').insert({ blocked_id: userId });
  if (error) throw new Error(error.message);
}

export async function unblockUser(blockId: string): Promise<void> {
  const { error } = await supabase.from('account_blocks').delete().eq('id', blockId);
  if (error) throw new Error(error.message);
}

export async function listSignInHistory(): Promise<SignInEntry[]> {
  const { data, error } = await supabase
    .from('signin_history')
    .select('id, signed_in_at, device')
    .order('signed_in_at', { ascending: false })
    .limit(20);
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function changePassword(newPassword: string): Promise<void> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw new Error(error.message);
}

export async function changeEmail(newEmail: string): Promise<void> {
  const { error } = await supabase.auth.updateUser({ email: newEmail });
  if (error) throw new Error(error.message);
}

export async function deleteOwnAccount(): Promise<void> {
  const { error } = await supabase.rpc('delete_own_account');
  if (error) throw new Error(error.message);
}
