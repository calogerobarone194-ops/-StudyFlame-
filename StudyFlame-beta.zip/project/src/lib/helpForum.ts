import { supabase } from '@/lib/supabase';

export interface HelpPost {
  id: string;
  user_id: string;
  subject_id: string;
  author_name: string;
  title: string;
  body: string;
  created_at: string;
}

export interface HelpReply {
  id: string;
  post_id: string;
  user_id: string;
  author_name: string;
  body: string;
  created_at: string;
}

const postColumns = 'id, user_id, subject_id, author_name, title, body, created_at';
const replyColumns = 'id, post_id, user_id, author_name, body, created_at';

const contactBlockedMessage =
  'Pour protéger tout le monde, les numéros de téléphone, adresses e-mail, liens et noms de réseaux sociaux ne sont pas autorisés.';

export function formatHelpDate(iso: string): string {
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}

export function helpErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('contact_info_blocked')) return contactBlockedMessage;
  if (message.includes('profile_required')) return 'Votre profil doit être complété avant de publier.';
  return 'Une erreur est survenue. Réessayez dans un instant.';
}

export async function listPosts(subjectId: string | null): Promise<HelpPost[]> {
  let query = supabase
    .from('help_posts')
    .select(postColumns)
    .order('created_at', { ascending: false })
    .limit(50);
  if (subjectId) query = query.eq('subject_id', subjectId);

  const { data, error } = await query;
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function getPost(postId: string): Promise<HelpPost | null> {
  const { data, error } = await supabase
    .from('help_posts')
    .select(postColumns)
    .eq('id', postId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

export async function listReplies(postId: string): Promise<HelpReply[]> {
  const { data, error } = await supabase
    .from('help_replies')
    .select(replyColumns)
    .eq('post_id', postId)
    .order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function createPost(input: { subjectId: string; title: string; body: string }): Promise<HelpPost> {
  const { data, error } = await supabase
    .from('help_posts')
    .insert({ subject_id: input.subjectId, title: input.title, body: input.body })
    .select(postColumns)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error('Publication impossible.');
  return data;
}

export async function createReply(input: { postId: string; body: string }): Promise<HelpReply> {
  const { data, error } = await supabase
    .from('help_replies')
    .insert({ post_id: input.postId, body: input.body })
    .select(replyColumns)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error('Réponse impossible.');
  return data;
}

export async function deletePost(postId: string): Promise<void> {
  const { error } = await supabase.from('help_posts').delete().eq('id', postId);
  if (error) throw new Error(error.message);
}

export async function deleteReply(replyId: string): Promise<void> {
  const { error } = await supabase.from('help_replies').delete().eq('id', replyId);
  if (error) throw new Error(error.message);
}

export async function reportContent(type: 'post' | 'reply', id: string): Promise<void> {
  const { error } = await supabase.rpc('report_help_content', { p_type: type, p_id: id });
  if (error) throw new Error(error.message);
}
