import { supabase } from '@/lib/supabase';

export interface LessonContent {
  intro: string;
  sections: { heading: string; body: string }[];
  key_points: string[];
  exercises: { question: string; choices: string[] }[];
}

export interface Lesson {
  id: string;
  subject_id: string;
  level: string;
  topic: string;
  title: string;
  content: LessonContent;
  total: number;
  status: 'new' | 'done';
  score: number | null;
  xp_awarded: number;
  created_at: string;
  completed_at: string | null;
}

export interface LessonResult {
  score: number;
  total: number;
  xp: number;
  flames: number;
  results: { answer_index: number; explanation: string; correct: boolean }[];
}

const lessonColumns =
  'id, subject_id, level, topic, title, content, total, status, score, xp_awarded, created_at, completed_at';

export function lessonErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('daily_limit')) return "Tu as atteint la limite de leçons pour aujourd'hui. Reviens demain !";
  if (message.includes('ai_not_configured')) return "La génération de leçons n'est pas encore activée sur ce site.";
  if (message.includes('lesson_already_done')) return 'Cette leçon est déjà terminée.';
  if (message.includes('no_starter_lesson')) return "Pas encore de leçon disponible pour cette matière pendant la bêta. Réessaie bientôt !";
  return 'Une erreur est survenue. Réessaie dans un instant.';
}

export async function listLessons(): Promise<Lesson[]> {
  const { data, error } = await supabase
    .from('lessons')
    .select(lessonColumns)
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) throw new Error(error.message);
  return (data ?? []) as Lesson[];
}

export async function getLesson(id: string): Promise<Lesson | null> {
  const { data, error } = await supabase.from('lessons').select(lessonColumns).eq('id', id).maybeSingle();
  if (error) throw new Error(error.message);
  return data as Lesson | null;
}

async function invokeGenerator(subjectId: string, topic: string, mode: 'lesson' | 'practice'): Promise<string> {
  const { data, error } = await supabase.functions.invoke('generate-lesson', {
    body: { subject_id: subjectId, topic: topic.trim(), mode },
  });
  if (error) {
    // Edge Function errors carry the JSON body in `context`.
    let code = error.message;
    try {
      const body = await (error as { context?: Response }).context?.json();
      if (body?.error) code = body.error;
    } catch {
      /* keep message */
    }
    throw new Error(code);
  }
  if (!data?.id) throw new Error('generation_failed');
  return data.id as string;
}

async function startStarterLesson(subjectId: string): Promise<string> {
  const { data, error } = await supabase.rpc('start_starter_lesson', { p_subject: subjectId });
  if (error) throw new Error(error.message);
  return data as string;
}

// Errors that the starter library cannot fix: show them as they are.
const blockingCodes = ['daily_limit', 'not_authenticated', 'invalid_subject', 'profile_required'];

/**
 * Creates a lesson with the AI. If the AI is unavailable (not configured, not deployed, network or
 * provider error), a ready-made starter lesson is used instead so the student is never stuck.
 */
export async function generateLesson(
  subjectId: string,
  topic: string,
  mode: 'lesson' | 'practice' = 'lesson',
): Promise<string> {
  try {
    return await invokeGenerator(subjectId, topic, mode);
  } catch (error) {
    const message = error instanceof Error ? error.message : '';
    if (blockingCodes.some((code) => message.includes(code))) throw error;
    return startStarterLesson(subjectId);
  }
}

export async function submitLesson(lessonId: string, answers: number[]): Promise<LessonResult> {
  const { data, error } = await supabase.rpc('submit_lesson', { p_lesson_id: lessonId, p_answers: answers });
  if (error) throw new Error(error.message);
  return data as LessonResult;
}

export async function deleteLesson(id: string): Promise<void> {
  const { error } = await supabase.from('lessons').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

/** Subject with the fewest finished lessons, ties broken by the oldest activity. */
export function pickSuggestedSubject(lessons: Lesson[], subjectIds: string[]): string {
  const stats = new Map<string, { done: number; last: number }>();
  for (const id of subjectIds) stats.set(id, { done: 0, last: 0 });
  for (const lesson of lessons) {
    const entry = stats.get(lesson.subject_id);
    if (!entry) continue;
    if (lesson.status === 'done') entry.done += 1;
    entry.last = Math.max(entry.last, new Date(lesson.created_at).getTime());
  }
  return [...subjectIds].sort((a, b) => {
    const sa = stats.get(a)!;
    const sb = stats.get(b)!;
    return sa.last - sb.last || sa.done - sb.done;
  })[0];
}

export function countDoneBySubject(lessons: Lesson[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const lesson of lessons) {
    if (lesson.status === 'done') counts[lesson.subject_id] = (counts[lesson.subject_id] ?? 0) + 1;
  }
  return counts;
}
