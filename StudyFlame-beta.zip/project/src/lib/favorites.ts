import { supabase } from '@/lib/supabase';

export type FavoriteType = 'subject' | 'lesson';

export interface Favorite {
  item_type: FavoriteType;
  item_id: string;
}

export async function listFavorites(): Promise<Favorite[]> {
  const { data, error } = await supabase.from('favorites').select('item_type, item_id').order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Favorite[];
}

export async function addFavorite(type: FavoriteType, id: string): Promise<void> {
  const { error } = await supabase.from('favorites').insert({ item_type: type, item_id: id });
  if (error && !error.message.includes('duplicate')) throw new Error(error.message);
}

export async function removeFavorite(type: FavoriteType, id: string): Promise<void> {
  const { error } = await supabase.from('favorites').delete().eq('item_type', type).eq('item_id', id);
  if (error) throw new Error(error.message);
}
