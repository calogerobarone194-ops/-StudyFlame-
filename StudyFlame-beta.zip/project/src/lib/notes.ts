import { supabase } from '@/lib/supabase';

export interface Note {
  id: string;
  title: string;
  body: string;
  subject_id: string | null;
  updated_at: string;
  has_drawing: boolean;
}

export interface NoteInput {
  title: string;
  body: string;
  subject_id: string | null;
  /** undefined = leave the drawing as it is, null = remove it, string = PNG data URL. */
  drawing?: string | null;
}

const baseColumns = 'id, title, body, subject_id, updated_at';

export async function listNotes(): Promise<Note[]> {
  // `has_drawing` only exists once the drawing migration is applied: fall back so notes still load.
  const withDrawing = await supabase
    .from('notes')
    .select(`${baseColumns}, has_drawing`)
    .order('updated_at', { ascending: false })
    .limit(200);
  if (!withDrawing.error) return (withDrawing.data ?? []) as Note[];

  const plain = await supabase.from('notes').select(baseColumns).order('updated_at', { ascending: false }).limit(200);
  if (plain.error) throw new Error(plain.error.message);
  return ((plain.data ?? []) as Omit<Note, 'has_drawing'>[]).map((note) => ({ ...note, has_drawing: false }));
}

export async function getNoteDrawing(id: string): Promise<string | null> {
  const { data, error } = await supabase.from('notes').select('drawing').eq('id', id).maybeSingle();
  if (error) return null;
  return (data as { drawing: string | null } | null)?.drawing ?? null;
}

function toRow(input: NoteInput) {
  const row: Record<string, unknown> = { title: input.title, body: input.body, subject_id: input.subject_id };
  if (input.drawing !== undefined) row.drawing = input.drawing;
  return row;
}

export async function createNote(input: NoteInput): Promise<string> {
  const { data, error } = await supabase.from('notes').insert(toRow(input)).select('id').single();
  if (error) throw new Error(error.message);
  return (data as { id: string }).id;
}

export async function updateNote(id: string, input: NoteInput): Promise<void> {
  const { error } = await supabase.from('notes').update(toRow(input)).eq('id', id);
  if (error) throw new Error(error.message);
}

export async function deleteNote(id: string): Promise<void> {
  const { error } = await supabase.from('notes').delete().eq('id', id);
  if (error) throw new Error(error.message);
}
