import { supabase } from '@/lib/supabase';
import type { Lesson } from '@/lib/lessons';

export interface LeaderboardRow {
  rank: number;
  display_name: string;
  weekly_xp: number;
  is_me: boolean;
}

export async function getWeeklyLeaderboard(limit = 10): Promise<LeaderboardRow[]> {
  const { data, error } = await supabase.rpc('get_weekly_leaderboard', { p_limit: limit });
  if (error) throw new Error(error.message);
  return ((data ?? []) as LeaderboardRow[]).map((row) => ({
    ...row,
    rank: Number(row.rank),
    weekly_xp: Number(row.weekly_xp),
  }));
}

export interface Badge {
  id: string;
  label: string;
  description: string;
  unlocked: boolean;
  progress: string;
}

export function computeBadges(input: { xp: number; flames: number; lessons: Lesson[] }): Badge[] {
  const done = input.lessons.filter((lesson) => lesson.status === 'done');
  const perfect = done.filter((lesson) => lesson.score === lesson.total).length;
  const subjectsDone = new Set(done.map((lesson) => lesson.subject_id)).size;
  const defs: { id: string; label: string; description: string; value: number; goal: number }[] = [
    { id: 'first', label: 'Première étincelle', description: 'Terminer ta première leçon', value: done.length, goal: 1 },
    { id: 'five', label: 'Élève assidu', description: 'Terminer 5 leçons', value: done.length, goal: 5 },
    { id: 'twenty', label: 'Marathonien', description: 'Terminer 20 leçons', value: done.length, goal: 20 },
    { id: 'perfect', label: 'Sans faute', description: 'Réussir un quiz à 100 %', value: perfect, goal: 1 },
    { id: 'streak3', label: 'Flamme de 3 jours', description: 'Apprendre 3 jours de suite', value: input.flames, goal: 3 },
    { id: 'streak7', label: 'Flamme de 7 jours', description: 'Apprendre 7 jours de suite', value: input.flames, goal: 7 },
    { id: 'curious', label: 'Curieux', description: 'Terminer des leçons dans 3 matières', value: subjectsDone, goal: 3 },
    { id: 'xp500', label: '500 XP', description: 'Atteindre 500 XP', value: input.xp, goal: 500 },
  ];
  return defs.map((def) => ({
    id: def.id,
    label: def.label,
    description: def.description,
    unlocked: def.value >= def.goal,
    progress: `${Math.min(def.value, def.goal)} / ${def.goal}`,
  }));
}
