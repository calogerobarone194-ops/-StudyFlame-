import { supabase } from '@/lib/supabase';

export type PromoCode = {
  id: string;
  code: string;
  label: string;
  months_granted: number;
  organization_name: string | null;
  max_uses: number | null;
  expires_at: string | null;
  active: boolean;
  created_at: string;
};

export type PromoCodeWithStats = PromoCode & { uses: number };

export type PromoRedemption = {
  id: string;
  code_id: string;
  created_at: string;
  premium_until_granted: string;
  profiles: { display_name: string } | null;
};

const genericRedeemError =
  "Ce code n'est pas valide ou ne peut plus être utilisé.";

export function promoErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('code_already_used')) return 'Vous avez déjà utilisé ce code avec ce compte.';
  if (message.includes('code_expired')) return 'Ce code a expiré.';
  if (message.includes('code_inactive')) return 'Ce code a été désactivé.';
  if (message.includes('code_exhausted')) return 'Ce code a atteint sa limite d\'utilisations.';
  return genericRedeemError;
}

export async function redeemPromoCode(rawCode: string): Promise<string> {
  const code = rawCode.trim().toUpperCase();
  if (!code) throw new Error(genericRedeemError);

  const { data, error } = await supabase.rpc('redeem_promo_code', { p_code: code });
  if (error) throw new Error(error.message);
  return data as string;
}

export async function isAdmin(): Promise<boolean> {
  const { data, error } = await supabase.rpc('is_current_user_admin');
  if (error) return false;
  return data === true;
}

export async function listPromoCodes(): Promise<PromoCodeWithStats[]> {
  const { data: codes, error } = await supabase
    .from('promo_codes')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(promoErrorMessage(error));

  const { data: counts, error: countsError } = await supabase
    .from('promo_redemptions')
    .select('code_id');
  if (countsError) throw new Error(promoErrorMessage(countsError));

  const useCounts = new Map<string, number>();
  for (const row of counts ?? []) {
    useCounts.set(row.code_id, (useCounts.get(row.code_id) ?? 0) + 1);
  }

  return (codes ?? []).map((code) => ({ ...code, uses: useCounts.get(code.id) ?? 0 }));
}

export async function listRedemptions(codeId: string): Promise<PromoRedemption[]> {
  const { data, error } = await supabase
    .from('promo_redemptions')
    .select('id, code_id, created_at, premium_until_granted, profiles(display_name)')
    .eq('code_id', codeId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(promoErrorMessage(error));
  return (data ?? []) as unknown as PromoRedemption[];
}

export async function createPromoCode(input: {
  code: string;
  label: string;
  months: number;
  organization: string;
  maxUses: number | null;
  expiresAt: string | null;
}): Promise<PromoCodeWithStats> {
  const { data, error } = await supabase.rpc('create_promo_code', {
    p_code: input.code,
    p_label: input.label,
    p_months: input.months,
    p_organization: input.organization,
    p_max_uses: input.maxUses,
    p_expires_at: input.expiresAt,
  });
  if (error) {
    const message = error.message;
    if (message.includes('invalid_code')) throw new Error('Le code doit contenir entre 4 et 40 lettres majuscules ou chiffres, sans espace.');
    if (message.includes('invalid_months')) throw new Error("La durée d'avantage n'est pas valide.");
    if (message.includes('invalid_max_uses')) throw new Error("Le nombre d'utilisations doit être entre 1 et 100 000.");
    if (message.includes('duplicate key') || message.includes('already exists')) throw new Error('Ce code existe déjà.');
    if (message.includes('not_authorized')) throw new Error("Seul l'administrateur peut créer des codes.");
    throw new Error('Création impossible pour le moment.');
  }
  const created = Array.isArray(data) ? data[0] : data;
  return { ...(created as PromoCode), uses: 0 };
}

export async function setActivePromoCode(id: string, active: boolean): Promise<void> {
  const { error } = await supabase.rpc('update_promo_code', { p_id: id, p_active: active });
  if (error) throw new Error('Modification impossible pour le moment.');
}

export async function deletePromoCode(id: string): Promise<void> {
  const { error } = await supabase.rpc('delete_promo_code', { p_id: id });
  if (error) throw new Error('Suppression impossible pour le moment.');
}

export function randomPromoCode(): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 8; i += 1) {
    result += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return result;
}
