import { supabase } from '@/lib/supabase';

export interface CommunityPost {
  id: string;
  user_id: string;
  author_name: string;
  body: string;
  photo_path: string | null;
  created_at: string;
}

export interface CommunityComment {
  id: string;
  post_id: string;
  parent_comment_id: string | null;
  user_id: string;
  author_name: string;
  body: string;
  created_at: string;
}

export interface CommunityPostWithMeta extends CommunityPost {
  like_count: number;
  comment_count: number;
  liked_by_me: boolean;
}

const postColumns = 'id, user_id, author_name, body, photo_path, created_at';
const commentColumns = 'id, post_id, parent_comment_id, user_id, author_name, body, created_at';

export function communityErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (message.includes('contact_info_blocked')) {
    return 'Pour protéger tout le monde, les numéros, e-mails, liens et réseaux sociaux ne sont pas autorisés.';
  }
  return 'Une erreur est survenue. Réessayez dans un instant.';
}

export async function listPosts(): Promise<CommunityPostWithMeta[]> {
  const [postsResult, likesResult, commentsResult] = await Promise.all([
    supabase.from('community_posts').select(postColumns).order('created_at', { ascending: false }).limit(50),
    supabase.from('community_likes').select('post_id, user_id'),
    supabase.from('community_comments').select('post_id'),
  ]);

  if (postsResult.error) throw new Error(postsResult.error.message);
  if (likesResult.error) throw new Error(likesResult.error.message);
  if (commentsResult.error) throw new Error(commentsResult.error.message);

  const { data: sessionData } = await supabase.auth.getSession();
  const myId = sessionData.session?.user.id;

  const likeCounts = new Map<string, number>();
  const likedByMe = new Set<string>();
  for (const like of likesResult.data ?? []) {
    likeCounts.set(like.post_id, (likeCounts.get(like.post_id) ?? 0) + 1);
    if (myId && like.user_id === myId) likedByMe.add(like.post_id);
  }

  const commentCounts = new Map<string, number>();
  for (const comment of commentsResult.data ?? []) {
    commentCounts.set(comment.post_id, (commentCounts.get(comment.post_id) ?? 0) + 1);
  }

  return (postsResult.data ?? []).map((post) => ({
    ...post,
    like_count: likeCounts.get(post.id) ?? 0,
    comment_count: commentCounts.get(post.id) ?? 0,
    liked_by_me: likedByMe.has(post.id),
  }));
}

export async function createPost(input: { body: string; photoPath: string | null }): Promise<CommunityPost> {
  const { data, error } = await supabase
    .from('community_posts')
    .insert({ body: input.body, photo_path: input.photoPath })
    .select(postColumns)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error('Publication impossible.');
  return data;
}

export async function deletePost(postId: string, photoPath: string | null): Promise<void> {
  if (photoPath) {
    await supabase.storage.from('community-photos').remove([photoPath]);
  }
  const { error } = await supabase.from('community_posts').delete().eq('id', postId);
  if (error) throw new Error(error.message);
}

export async function listComments(postId: string): Promise<CommunityComment[]> {
  const { data, error } = await supabase
    .from('community_comments')
    .select(commentColumns)
    .eq('post_id', postId)
    .order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function createComment(input: { postId: string; parentCommentId: string | null; body: string }): Promise<CommunityComment> {
  const { data, error } = await supabase
    .from('community_comments')
    .insert({ post_id: input.postId, parent_comment_id: input.parentCommentId, body: input.body })
    .select(commentColumns)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error('Commentaire impossible.');
  return data;
}

export async function deleteComment(commentId: string): Promise<void> {
  const { error } = await supabase.from('community_comments').delete().eq('id', commentId);
  if (error) throw new Error(error.message);
}

export async function toggleLike(postId: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('toggle_post_like', { p_post_id: postId });
  if (error) throw new Error(error.message);
  return data as boolean;
}

export async function reportCommunityContent(type: 'post' | 'comment', id: string): Promise<void> {
  const { error } = await supabase.rpc('report_community_content', { p_type: type, p_id: id });
  if (error) throw new Error(error.message);
}

const MAX_PHOTO_BYTES = 5 * 1024 * 1024;
const ALLOWED_PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export async function uploadPostPhoto(file: File): Promise<string> {
  if (file.size > MAX_PHOTO_BYTES) throw new Error('La photo doit peser moins de 5 Mo.');
  if (!ALLOWED_PHOTO_TYPES.includes(file.type)) throw new Error('Formats acceptés : JPEG, PNG ou WebP.');

  const { data: sessionData } = await supabase.auth.getSession();
  const userId = sessionData.session?.user.id;
  if (!userId) throw new Error('Connectez-vous pour publier une photo.');

  const extension = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
  const path = `${userId}/${crypto.randomUUID()}.${extension}`;

  const { error } = await supabase.storage.from('community-photos').upload(path, file, {
    contentType: file.type,
    upsert: false,
  });
  if (error) throw new Error('Envoi de la photo impossible.');
  return path;
}

export async function getPhotoUrl(photoPath: string): Promise<string | null> {
  const { data, error } = await supabase.storage.from('community-photos').createSignedUrl(photoPath, 600);
  if (error) return null;
  return data?.signedUrl ?? null;
}
