import { supabase } from '@/lib/supabase';

export async function sendFeedback(message: string, page: string): Promise<void> {
  const { error } = await supabase.from('feedback').insert({ message: message.trim(), page });
  if (error) throw new Error(error.message);
}
