import { useState } from 'react';
import { Flame, Loader2 } from 'lucide-react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { FavoritesProvider } from '@/context/FavoritesContext';
import { useTheme } from '@/hooks/useTheme';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPage, type AuthMode } from '@/pages/AuthPage';
import { DashboardPage } from '@/pages/DashboardPage';
import type { SideView } from '@/components/layout/SideMenu';

type PublicView = { name: 'landing' } | { name: 'auth'; mode: AuthMode };

function AppContent() {
  const { user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [view, setView] = useState<PublicView>({ name: 'landing' });
  const [sideView, setSideView] = useState<SideView>({ name: 'accueil' });

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-4">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-lg shadow-orange-500/30">
            <Flame className="h-7 w-7 animate-flicker text-white" />
          </span>
          <Loader2 className="h-5 w-5 animate-spin text-slate-500" />
        </div>
      </div>
    );
  }

  if (user) {
    return <DashboardPage theme={theme} onToggleTheme={toggleTheme} sideView={sideView} onSideViewChange={setSideView} />;
  }

  if (view.name === 'auth') {
    return <AuthPage initialMode={view.mode} onBack={() => setView({ name: 'landing' })} />;
  }

  return (
    <LandingPage
      theme={theme}
      onToggleTheme={toggleTheme}
      onStart={() => {
        setSideView({ name: 'accueil' });
        setView({ name: 'auth', mode: 'signup' });
      }}
      onLogin={() => {
        setSideView({ name: 'accueil' });
        setView({ name: 'auth', mode: 'signin' });
      }}
    />
  );
}

function App() {
  return (
    <AuthProvider>
      <FavoritesProvider>
        <AppContent />
      </FavoritesProvider>
    </AuthProvider>
  );
}

export default App;
